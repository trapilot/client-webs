from django import template
from django.utils import timezone
from django.utils.safestring import mark_safe


register = template.Library()

class CopyRightsNode(template.Node):

    def __init__(self, start_year):
        self.start_year = start_year

    def render(self, context):
        try:
            start_year = int(self.start_year.resolve(context))
        except (TypeError, ValueError):
            start_year = timezone.now().year

        current_year = timezone.now().year

        if start_year < current_year:
            return mark_safe(f"© {start_year}-{current_year}")

        return mark_safe(f"© {current_year}")


@register.tag
def copy_rights(parser, token):
    """
    Usage:
        {% copy_rights 2000 %}
    """

    args = token.split_contents()

    if len(args) != 2:
        raise template.TemplateSyntaxError(
            "Usage: {% copy_rights 2000 %}"
        )

    start_year = parser.compile_filter(args[1])

    return CopyRightsNode(start_year)