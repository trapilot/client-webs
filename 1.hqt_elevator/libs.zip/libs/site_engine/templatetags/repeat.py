from django import template


register = template.Library()

class RepeatNode(template.Node):
    def __init__(self, nodelist, num, var=None):
        self.nodelist = nodelist
        self.num = template.Variable(num)
        self.var = var

    def render(self, context):
        try:
            num = int(self.num.resolve(context))
        except (TypeError, ValueError):
            num = 0
        output = ""
        for i in range(num):
            if self.var:
                context[self.var] = i
            output += self.nodelist.render(context)
        return output


@register.tag
def repeat(parser, token):
    """
    Repeats the containing text a certain number of times.

    Requires a single argument, an integer, to indicate the number of times to
    repeat the enclosing content.

    Example::

        {% repeat 3 %}foo{% endrepeat %}

    Yields::

        foofoofoo
    """
    bits = token.split_contents()
    try:
        fnctn = bits[0]
        num = bits[1]
    except IndexError:
        raise template.TemplateSyntaxError(
            '"repeat tag" requires syntax: repeat <num> [as <var>].')

    try:
        trash = bits[2]
        var = bits[3]
    except IndexError:
        trash = var = None

    if trash and trash != "as" or trash and not var:
        raise template.TemplateSyntaxError(
            '"%s" requires syntax: %s <num> [as <var>].' % (fnctn, fnctn))

    nodelist = parser.parse(('endrepeat',))
    parser.delete_first_token()
    
    return RepeatNode(nodelist, num, var)
