import textwrap

from django import template
from django.utils.safestring import mark_safe


register = template.Library()

class CompactNode(template.Node):
    def __init__(self, nodelist, indent=0):
        self.nodelist = nodelist
        self.indent = int(indent)

    def render(self, context):
        content = self.nodelist.render(context)

        # remove empty space around block
        content = content.strip()

        # normalize indentation
        content = textwrap.dedent(content)

        lines = []

        for line in content.splitlines():
            line = line.strip()
            
            if not line or  'content=""' in line:
                continue

            lines.append(('\t' * self.indent) + line)

        return mark_safe('\n'.join(lines))


@register.tag(name='compact')
def do_compact(parser, token):
    bits = token.split_contents()

    indent = bits[1] if len(bits) > 1 else 0

    nodelist = parser.parse(('endcompact',))
    parser.delete_first_token()

    return CompactNode(nodelist, indent)