from django import template


register = template.Library()

@register.filter
def get(item, key):
    u"""To access the contents of a dictionary using the key"""
    try:
        return item.get(key, '')
    except AttributeError:
        return getattr(item, key, '')


@register.filter(name='get_class')
def get_class(value):
    return value.__class__.__name__


@register.filter(name='get_region')
def get_region(value):
    u"""We return the region code for the search"""
    type = value.__class__.__name__
    return {
        'City': '#',
        'Province': '@',
        'Zone': '$',
    }.get(type, None)
