from django import template
from django.conf import settings
from django.urls import exceptions, reverse


register = template.Library()

class UrlCmsNode(template.Node):
    u"""
    To do a reverse of urls with multilanguage
    """
    def __init__(self, view_name, args):
        self.view_name = view_name
        self.args = args

    def render(self, context):
        args = [params.resolve(context) for params in self.args]
        request = context.get('request')
        
        if not request:
            return '#'
        
        site = request.site
        if not site:
            return '#'

        # As view name you can pass a plain name, or an attribute of a model.
        view_name = self.view_name.resolve(context)
        if not view_name or (not isinstance(view_name, str)):
            view_name = self.view_name.__str__()
        
        prefix = 'http'
        if request.META.get('HTTPS') or site.is_ssl:
            prefix = 'https'

        try:
            url_reverse = reverse(view_name, args=args)
        except exceptions.NoReverseMatch:
            page = site.page(view_name)
            if not page:
                return '#'
            
            if page.is_external:
                return page.url
                    
            url_reverse = page.reverse(args)

            # We check if the page requires SSL or not. For the prefix.
            prefix = 'https' if page.is_ssl or site.is_ssl else 'http'

        port = ''
        if ':' in request.get_host():
            port = ':%s' % request.get_host().split(':')[1]

        return '%s://%s%s%s' % (prefix, site.domain, port, url_reverse.replace('//', '/'))


@register.tag
def url_cms(parser, token):
    u"""
    This templatetag can be used to resolve both the urls
    added directly in the urls.py, with or without multilanguage, and the
    urls of the 'page' models of the site
    """

    args = token.split_contents()[1:]
    view_name = parser.compile_filter(args[0])
    params = []

    for param in args[1:]:
        params.append(parser.compile_filter(param))

    return UrlCmsNode(view_name, params)
