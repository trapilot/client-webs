from django import template
from django.conf import settings
from django.urls import exceptions, reverse


register = template.Library()

class UrlCmsNode(template.Node):
    u"""
    To do a reverse of urls with multilanguage
    """
    def __init__(self, view_name, args):
        self.view_name = view_name
        self.args = args

    def render(self, context):
        args = [params.resolve(context) for params in self.args]
        request = context.get('request')
        
        if not request:
            return '#'
        
        site = request.site
        if not site:
            return '#'

        # As view name you can pass a plain name, or an attribute of a model.
        view_name = self.view_name.resolve(context)
        if not view_name or (not isinstance(view_name, str)):
            view_name = self.view_name.__str__()
        
        try:
            url_reverse = reverse(view_name, args=args)
        except exceptions.NoReverseMatch:
            # If it crashes here, it is because the cms uses the new handler, so the url
            # is not in the urlpatterns, but is taken from the available urls
            # of the site itself.
            page = site.page(view_name)
            if not page:
                # if settings.DEBUG:
                #     raise Exception(u"Could not resolve page %s, "
                #         "with arguments %s" % (view_name, self.args))
                # We change the raise for an empty return so that the web does not crash when losing a link
                # simply the link will not link to anything
                return '#'
            
            if page.is_external:
                return page.url
                    
            url_reverse = page.reverse(args)

            # We check if the page requires SSL or not. For the prefix.
            prefix = 'https' if page.is_ssl else 'http'

        # For the domain, we take the one from the site in the corresponding language.
        domain = site.domain

        prefix = 'http'
        if request.META.get('HTTPS') or site.is_ssl:
            prefix = 'https'
        
        port = ''
        if ':' in request.get_host():
            port = ':%s' % request.get_host().split(':')[1]

        url = '%s://%s%s%s' % (prefix, domain, port, url_reverse.replace('//', '/'))

        return url


@register.tag
def url_cms(parser, token):
    u"""
    This templatetag can be used to resolve both the urls
    added directly in the urls.py, with or without multilanguage, and the
    urls of the 'page' models of the site
    """

    args = token.split_contents()[1:]
    view_name = parser.compile_filter(args[0])
    params = []

    for param in args[1:]:
        params.append(parser.compile_filter(param))

    return UrlCmsNode(view_name, params)
