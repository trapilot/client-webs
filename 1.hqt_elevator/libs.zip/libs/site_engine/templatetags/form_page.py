import re

from django import template
from django.conf import settings
from django.template import  Template
from django.template.defaultfilters import linebreaksbr


register = template.Library()
ALLOWED_LIST = {
    'heading': 'heading',
    'label': 'label',
    'title': 'title',
    'subtitle': 'subtitle',
    'description': 'description',
}

class FormNode(template.Node):
    def __init__(self, form_type, option):
        self._form_type = form_type
        self._option = option
        
        if option not in ALLOWED_LIST.keys():
            raise Exception(u'Invalid argument. Only allowed: %s' % ALLOWED_LIST.keys())

    def render(self, context):
        request = context.get('request')
        page = getattr(request, "page", None)
        
        if page is None:
            return ''
        
        try:
            valid = ALLOWED_LIST[self._option]
            formobj = getattr(page, self._form_type) or None
            if valid == 'heading':
                title = getattr(formobj, "title") or ""
                subtitle = getattr(formobj, "subtitle") or ""
                content = f"{title}<br>{subtitle}" if subtitle else title
            else:
                content = getattr(formobj, valid) or ""
            template = Template(content)
            return template.render(context)
        except Exception as ex:
            if settings.DEBUG:
                print(ex)
            return ""


@register.tag
def form_cta(parser, token):
    arg = token.split_contents()[1:][0]
    return FormNode('form_cta', arg)


@register.tag
def form_quote(parser, token):
    arg = token.split_contents()[1:][0]
    return FormNode('form_quote', arg)


@register.tag
def form_newsletter(parser, token):
    arg = token.split_contents()[1:][0]
    return FormNode('form_newsletter', arg)


@register.tag
def form_consultation(parser, token):
    arg = token.split_contents()[1:][0]
    return FormNode('form_consultation', arg)
