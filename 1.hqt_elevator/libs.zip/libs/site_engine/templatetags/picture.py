from pathlib import Path

from django import template
from django.utils.html import conditional_escape
from django.utils.safestring import mark_safe

from shared_engine.utils.file import build_fs_path, build_file_path
from shared_engine.transcode import (
  get_transcode_sizes,
  get_transcode_outputs,
)


register = template.Library()

PRESETS = {
    "default": {
        "sizes": "100vw",
        "loading": "lazy",
        "fetchpriority": None,
    },
    "card": {
        "sizes": "(max-width:768px) 100vw, 33vw",
        "loading": "lazy",
        "fetchpriority": None,
    },
    "hero": {
        "sizes": "100vw",
        "loading": "eager",
        "fetchpriority": "high",
    },
}


@register.simple_tag
def picture(
  image,
  alt="",
  preset="default",
  class_name="",
  id=None,
  sizes=None,
  loading=None,
  fetchpriority=None,
):
  """
  Usage:

  {% picture post.image %}

  {% picture
    post.image
    alt=post.title
    preset="card"
  %}

  {% picture
    page.banner
    alt=page.title
    preset="hero"
    class_name="w-full rounded-xl"
  %}
  """

  if not image:
    return ""

  preset_config = PRESETS.get(
    preset,
    PRESETS["default"]
  )

  sizes = sizes or preset_config["sizes"]
  loading = loading or preset_config["loading"]
  fetchpriority = (
    fetchpriority
    or preset_config["fetchpriority"]
  )

  path = Path(image.name)
  generated_base = (
    path.parent
    / "generated"
    / path.stem
  )

  transcode_sizes = get_transcode_sizes()
  transcode_outputs = get_transcode_outputs()
  source_tags = []
  for output_format in transcode_outputs:
    srcset_parts = []
    for size in transcode_sizes:
        relative_path = f"{generated_base}_{size}.{output_format}"
        fs_path = build_fs_path(relative_path)
        
        if not fs_path.exists():
          continue
        
        srcset_parts.append(f"{build_file_path(relative_path)} {size}w")

    if not srcset_parts:
      continue

    srcset = ", ".join(srcset_parts)

    source_tags.append(
        f"""
        <source
            type="image/{output_format}"
            srcset="{srcset}"
            sizes="{sizes}"
        >
        """
    )

  img_attrs = [
    f'src="{image.url}"',
    f'alt="{conditional_escape(alt or "")}"',
    'decoding="async"',
  ]  
  if class_name:
    img_attrs.append(f'class="{conditional_escape(class_name)}"')
  if id:
    img_attrs.append(f'id="{conditional_escape(id)}"')
  if loading:
    img_attrs.append(f'loading="{loading}"')
  if fetchpriority:
    img_attrs.append(f'fetchpriority="{fetchpriority}"')

  html = f"""
  <picture class="block w-full h-full">
    {''.join(source_tags)}
    <img {' '.join(img_attrs)}>
  </picture>
  """

  return mark_safe(html)