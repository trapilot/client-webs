from django import template


register = template.Library()

@register.filter
def imagepath(image):
    """
    usage:
        {{ obj.image|imagepath }}
    """

    try:
        return image.url
    except:
        return ""