from django import template
from django.apps import apps
from django.core.paginator import Paginator
from django.shortcuts import get_object_or_404


register = template.Library()

@register.simple_tag(takes_context=True)
def paginate(context, qs, per_page=10):
    request = context["request"]
    paginator = Paginator(qs, per_page)
    return paginator.get_page(request.GET.get("page"))


@register.simple_tag(takes_context=True)
def paginate_with_group(context, qs, per_page=10, group_size=2):
    request = context["request"]

    paginator = Paginator(qs, per_page)
    page_obj = paginator.get_page(request.GET.get("page"))

    grouped = []
    for i in range(0, len(page_obj), group_size):
        items = page_obj[i:i + group_size]
        grouped.append({
            "index": i // group_size,
            "items": items,
            "count": len(items),
        })

    return {
        "page": page_obj,
        "groups": grouped,
    }


@register.simple_tag
def object_or_404(app_label, model_name, **filters):
    model = apps.get_model(app_label, model_name)

    return get_object_or_404(
        model.objects.all(),
        **filters,
    )

@register.simple_tag
def object_related(object, limit=3):
    return object.get_related(limit)