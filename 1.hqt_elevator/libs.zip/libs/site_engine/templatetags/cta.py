import re

from django import template
from django.conf import settings
from django.template import  Template
from django.template.defaultfilters import linebreaksbr
from django.utils.safestring import mark_safe
from django.utils.html import format_html

from site_engine.utils import build_page_url

register = template.Library()

ALLOWED_LIST = {
    # 'label': 'cta_label',
    'title': 'cta_title',
    'subtitle': 'cta_subtitle',
    'description': 'cta_description',
}

class FormNode(template.Node):
    def __init__(self, option):
        self._option = option
        
        if option not in ALLOWED_LIST.keys():
            raise Exception(u'Invalid argument. Only allowed: %s' % ALLOWED_LIST.keys())

    def render(self, context):
        request = context.get('request')
        page = getattr(request, "page", None)
        
        if page is None:
            return ''
        
        try:
            valid = ALLOWED_LIST[self._option]
            content = getattr(page, valid) or ""

            template = Template(content)
            return template.render(context)
        except Exception as ex:
            if settings.DEBUG:
                print(ex)
            return ""


@register.tag
def cta(parser, token):
    arg = token.split_contents()[1:][0]
    return FormNode(arg)


@register.simple_tag(takes_context=True)
def cta_site(context):
    site = context.get("site")
    if not site:
        return ""
    return mark_safe(f'<input type="hidden" name="site_id" value="{site.id}">')


@register.simple_tag(takes_context=True)
def cta_page(context):
    page = context.get("page")
    if not page:
        return ""
    return mark_safe(f'<input type="hidden" name="page_id" value="{page.id}">')


@register.simple_tag(takes_context=True)
def cta_policy(context):
    site = context.get("site")
    if not site:
        return ""
    if not site.page_legal:
        return ""
    return format_html(
        '''
        <label class="privacy-policy">
            <input type="checkbox" name="privacy_policy" required>
            I agree to <a href="{}" target="_blank">Privacy Policy</a>
        </label>
        ''',
        build_page_url(site, site.page_legal)
    )