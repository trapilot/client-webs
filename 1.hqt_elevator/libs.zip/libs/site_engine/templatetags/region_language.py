from django import template
from django.conf import settings


from site_engine.defaults import LANGUAGE_REGIONS

register = template.Library()


class IncorrectParameters(Exception):
    pass


class LanguageNotAllowed(Exception):
    pass


class RegionLanguageNode(template.Node):
    def __init__(self, language):
        self.language = language

    def render(self, context):
        request = context.get('request')
        site = getattr(request, 'site', None)
        
        if site is None:
            return ''

        # We check if the site accepts that language
        language = self.language.resolve(context)
        if not language in site.languages:
            if settings.DEBUG:
                print(u'Language not allowed for this site: %s' % language)
            return ''

        try:
            return LANGUAGE_REGIONS[language]
        except:
            return ''

@register.tag
def region_language(parser, token):
    u"""
    How to use:
        {% region_language 'vi' %}
        {% region_language 'en' %}
        {% region_language language %}
    """

    args = token.split_contents()[1:]

    try:
        language = args[0]
    except IndexError:
        raise IncorrectParameters(u'You must indicate the language code')

    return RegionLanguageNode(parser.compile_filter(language))
