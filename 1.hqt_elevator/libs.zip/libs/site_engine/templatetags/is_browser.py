from django import template


register = template.Library()

class IsBrowserNode(template.Node):
    BROWSER_LIST = {
        'Chrome' : 'ch',
        'Firefox' : 'fx',
        'MSIE 8.0' : 'ie8',
        'MSIE 7.0' : 'ie7',
        'MSIE 9.0' : 'ie9',
        'MSIE 10.0' : 'ie10',
        'MSIE 11.0' : 'ie11'
    }

    def __init__(self, content, browser):
        self._content = content
        self._browser = browser

    def _detect_browser(self, useragent):
        u"""From the useragent we return the browser code."""

        for pattern, code in self.BROWSER_LIST.items():
            if pattern in useragent:
                return code
        return None

    def render(self, context):
        browser = self._browser.resolve(context)
        content = self._content.render(context)
        useragent = context.get('request').META.get('HTTP_USER_AGENT')

        if not useragent:
            return ''

        if browser == self._detect_browser(useragent):
            return content

        return ''

@register.tag
def blockIsBrowserNode(parser, token):
    u"""For browser detection.
    How to use:
    {% blockIsBrowserNode 'fx' %}
        <link rel="stylesheet" href="" type="text/css" />
    {% endblockIsBrowserNode %}
    """

    content = parser.parse(('endblockIsBrowserNode',))
    args = token.split_contents()[1:]
    browser = parser.compile_filter(args[0])

    parser.delete_first_token()
    return IsBrowserNode(content, browser)
