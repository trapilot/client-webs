from django import template

from site_engine.utils import build_page_url


register = template.Library()

class UrlLanguageNode(template.Node):
    u"""
    This TT generates a complete URL of the page where we are,
    but with the indicated language
    """

    def __init__(self, language, site=None):
        self._language = language
        self._site = site

    def render(self, context):
        site = self._site.resolve(context) if self._site else context['site']
        language = self._language.resolve(context)

        # We check if the site accepts said language
        if not language in site.languages:
            raise Exception(u'language not allowed for this site: %s' % language)

        try:
            page = context.get('page')
            return build_page_url(site, page, language, True)
        except:
            return ''

@register.tag
def url_language(parser, token):
    u"""
    How to use:
         {% url_language 'in' %}
         {% url_language 'en' %}
         {% url_language language %}
         {% url_language language site %}
    """
    args = token.split_contents()[1:]

    try:
        language = parser.compile_filter(args[0])
    except IndexError:
        raise Exception(u'You must indicate the language code')
    try:
        site = parser.compile_filter(args[1])
    except IndexError:
        site = None

    return UrlLanguageNode(language, site)
