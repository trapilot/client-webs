import os

from django.conf import settings
from django.utils.translation  import get_language, gettext_lazy as _

from shared_engine.transmeta import get_real_language, get_real_fieldname as __

# IMPORTANT: The script that collects the translations from excel online and the one
# that loads them in the sites follow the order of the languages as they are in this list.
# This list is obtained from: https://en.wikipedia.org/wiki/List_of_ISO_639-1_codes
TRANSMETA_LANGUAGES = (
    ('en', _('English')),
    ('vi', _('Vietnamese')),
    ('ja', _('Japanese')),
    ('zh', _('Chinese')),
    ('es', _('Spanish')),
    ('ca', _('Catala')),
    ('de', _('German')),
    ('it', _('Italian')),
    ('nl', _('Dutch')),
    ('fr', _('French')),
    ('pt', _('Portuguese')),
    ('ru', _('Russian')),
    ('sv', _('Swedish')),
    ('da', _('Danish')),
    ('ar', _('Arab')),
    ('id', _('Indonesian')),
    ('ko', _('Korean')),
    ('ms', _('Malay')),
    ('no', _('Norwegian')),
    ('tl', _('Tagalog')),
    ('th', _('Thai')),
    ('tr', _('Turkish')),
)

# We put the languages in a dictionary to be able to access
LANGUAGE_NAMES = {}
for language in TRANSMETA_LANGUAGES:
    LANGUAGE_NAMES[language[0]] = language[1]

# Add region codes, because it doesn't always match the language code
# http://www.iana.org/assignments/language-subtag-registry
# http://en.wikipedia.org/wiki/ISO_3166-1_alpha-2
LANGUAGE_REGIONS = {
    'en': 'GB',
    'vi': 'VN',
    'cn': 'CN',
    'jp': 'JP',
    'es': 'ES',
    'ca': 'ES',
    'de': 'DE',
    'it': 'IT',
    'nl': 'NL',
    'fr': 'FR',
    'pt': 'PT',
    'ru': 'RU',
    'sv': 'SV',
    'da': 'DK',
    'id': 'ID', # Indonesia
    'kp': 'KP', # North Korea
    'kr': 'KR', # South Korea
    'my': 'MY', # Malasya
    'no': 'NO', # Norway
    'th': 'TH', # Thailand
    'ph': 'PH', # Philippines
    'tr': 'TR', # Turkey
    'ar': 'AR', # Arabic
}


# Maps a language code (var REGIONS) to a language (var LANGUAGES)
MAPPING_LANGUAGE_CODE = {
    'en': 'en',
    'vi': 'vi',
    'es': 'es',
    'cat': 'ca',
    'ca': 'ca',
    'de': 'de',
    'it': 'it',
    'nl': 'nl',
    'fr': 'fr',
    'pt': 'pt',
    'ru': 'ru',
    'sv': 'sv',
    'da': 'da',
    'zh': 'zh', # Chinese
    'ja': 'ja', # Japanese
    'id': 'id', # Indonesian
    'kp': 'ko',
    'kr': 'ko',
    'ko': 'ko',
    'my': 'ms',
    'no': 'no',
    'th': 'th',
    'ph': 'tl',
    'tr': 'tr',
    'ar': 'ar',
}

MAPPING_LANGUAGE_DOMAIN = {
    '.vn': 'vi',
    '.co': 'en',
    '.uk': 'en',
    '.com': 'en',
    '.cat': 'ca',
    '.de': 'de',
    '.it': 'it',
    '.nl': 'nl',
    '.fr': 'fr',
    '.pt': 'pt',
    '.br': 'pt',
    '.pt': 'pt',
    '.ru': 'ru',
    '.sv': 'sv',
    '.da': 'da',
    '.ar': 'ar',
}

# Default currency for each language. The currency code must match the code
# used in the Currencies table (and in the fixtures from which the table is populated)
MAPPING_LANGUAGE_CURRENCY = {
    'en': 'GBP',
    'vi': 'VND',
    'es': 'EUR',
    'ca': 'EUR',
    'de': 'EUR',
    'it': 'EUR',
    'nl': 'EUR',
    'fr': 'EUR',
    'pt': 'EUR',
    'ru': 'EUR',
    'sv': 'EUR',
    'da': 'EUR',
    'zh': 'EUR',
    'ja': 'EUR',
    'da': 'EUR',
    'da': 'EUR',
    'id': 'EUR',
    'ko': 'EUR',
    'ms': 'EUR',
    'no': 'EUR',
    'tl': 'EUR',
    'th': 'EUR',
    'tr': 'EUR',
    'ar': 'EUR',
}

TRANSBASE = os.path.join(os.path.dirname(__file__), 'backoffice', 'tradsbase.csv')
DEFAULT_LANGUAGE = get_real_language(settings.LANGUAGE_CODE)
CURRENT_LANGUAGE = get_real_language(get_language())