import ast
import dateutil

from django.db import models
from django.conf import settings
from django.core.cache import cache
from django.db.models import ImageField
from django.template.defaultfilters import slugify
from django.utils.html import strip_tags
from django.utils.regex_helper import normalize
from django.utils.safestring import mark_safe
from django.utils.translation import get_language, gettext_lazy as _

from collections import defaultdict
from ckeditor.fields import RichTextField
from smart_selects.db_fields import ChainedForeignKey

from site_engine.defaults import DEFAULT_LANGUAGE, CURRENT_LANGUAGE, LANGUAGE_NAMES
from site_engine.managers import SiteManager
from site_engine.utils import default_site_code
from shared_engine.managers import GeneralManager, AvailabilityManager
from shared_engine.transmeta import TransMeta
from shared_engine.transcode import upload_to


class Site(models.Model, metaclass=TransMeta):
    objects = SiteManager()
    ADMIN_ORDER = 1

    class FeatureFlag(models.TextChoices):
        BLOG = 'BLOG', u'Feature Blog'
        PRODUCT = 'PRODUCT', u'Feature Product'
        PROJECT = 'PROJECT', u'Feature Project'
        SOLUTION = 'SOLUTION', u'Feature Solution'
        TARGET_FIELD = 'TARGET_FIELD', u'Target Field'
        TARGET_CATEGORY = 'TARGET_CATEGORY', u'Target Category'
        

    class MultilingualModes(models.IntegerChoices):
        """
        Available Types:
            0: No language detection
            1: Detected based on subdomain. If it starts with en., de., cat., .pt, etc, this is selected. Otherwise, it is considered EN.
            2: Detected based on the top level domain.
                .com is EN, .co.uk is EN, .pt is PT, etc. The "FORCE_DOM" field can be used to specify the language.
                Useful in those cases in which the corporate is of one type and the individual ones of another.
            3: It is detected based on the HTTP_HOST header and the domains that are set in the admin.
        """            
        NONE = 0, u'None'
        SUBDOMAIN_PREFIX = 1, u'Prefix in subdomain'
        GEOGRAPHIC_DOMAIN = 2, u'Geographic domain'
        MULTIPLE_DOMAINS = 3, u'Multiple domain'

    code = models.CharField(_(u'Code'), max_length=50, unique=True)
    name = models.CharField(_(u'Name'), max_length=100)
    slogan = models.CharField(_(u"Slogan"), max_length=150, blank=True, null=True)
    type = models.CharField(_(u'Type'), max_length=50, blank=True, null=True, default='BLOG')
    mode = models.IntegerField(_('Multilingual Mode'), choices=MultilingualModes.choices, default=MultilingualModes.NONE)
    language = models.CharField(_(u'Languages'), max_length=50, default='%s' % (DEFAULT_LANGUAGE))
    domain = models.CharField(
        _(u'Domain'), max_length=80, default='',
        help_text=_(u'Domain for each language. If the site works with language folders, always put the same domain. Do not add the port.'),
    )
    is_ssl = models.BooleanField(
        _(u'SSL'), blank=True, null=True, default=False,
        help_text=_(u'Indicate the domain that listens to the site under ssl'),
    )

    sitemap_extension = models.CharField(
        _(u'Sitemap context'), max_length=150, blank=True, null=True, default='',
        help_text=_(u'Returns a list of UrlSitemap objects that are added to the default sitemap.'),
    )
    robots_extra = models.TextField(
        _(u'Robots extra'), blank=True, null=True, default='',
        help_text=_(u'The cms itself already has a default robots, but if we want to add extra rules, they can be added here.'),
    )
    features_flag = models.JSONField(_('Features Flag'), default=list, blank=True, null=True)

    image404 = ImageField(
        _(u'Image 404'), blank=True, null=True,
        upload_to=upload_to('uploads/site'),
        help_text=_(u'Image that will be seen on the 404 error page of the site.'),
    )
    imageLogo = ImageField(
        _(u'Image logo'), blank=True, null=True,
        upload_to=upload_to('uploads/site'),
        help_text=_(u'Image logo of the site.'),
    )
    imageFavicon = ImageField(
        _(u'Image favicon'), blank=True, null=True,
        upload_to=upload_to('uploads/site'),
        help_text=_(u'Image favicon of the site.'),
    )

    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='user_created', null=True, blank=True)
    updated_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='user_updated', null=True, blank=True)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Site Setting')
        verbose_name_plural = _(u'Site Settings')
        translate = ('domain', 'slogan',)
        translate_inline = ('domain', 'slogan',)
        ordering = ('name',)

    def __str__(self):
        return self.name

    @property
    def pages(self):
        u"""
        We return a dictionary with the site pages,
        whose key is the page code. We keep this dictionary in the object itself,
        so we save ourselves a query next time.
        """
        if not hasattr(self, '_cache_pages'):
            pages = {}
            for page in self.page_set.filter(is_active=True):
                pages[page.code] = page
            self._cache_pages = pages
        return self._cache_pages

    @property
    def nested_pages(self):
        u"""
        We return a list with the site pages ordered in preorder.
        We will use it to create the sitemap as a tree listing page
        """
        if not hasattr(self, '_cache_nested_pages'):
            pages = self.page_set.filter(is_active=True, parent=None)
            preorder_list_pages = self._preorder_pages(pages)
            self._cache_nested_pages = preorder_list_pages
        return self._cache_nested_pages

    def _preorder_pages(self, pages, list=[]):
        u"""
        Build a list from a preorder traversal of the page tree.
        """
        for page in pages:
            list.append(page)
            page_childs = page.nested_set.filter(is_active=True)
            self._preorder_pages(page_childs, list)
        return list
    
    @property
    def page_home(self):
        for page in self.pages.values():
            if page.is_home:
                return page
        return None
    
    @property
    def page_tac(self):
        for page in self.pages.values():
            if page.is_tac:
                return page
        return None

    @property
    def page_legal(self):
        for page in self.pages.values():
            if page.is_ppl:
                return page
        return None

    @property
    def navigation(self):
        u"""
        We return the pages that fall within the navigation.
        """
        nav = []
        for page in self.pages.values():
            if page.is_top_menu or page.is_sub_menu:
                nav.append(page)
        return sorted(nav, key=lambda page: page.sorted)

    @property
    def navigation_primary(self):
        u"""
        We return the top navigation pages.
        """
        nav = []
        for page in self.pages.values():
            if page.is_top_menu:
                nav.append(page)
        return sorted(nav, key=lambda page: page.sorted)

    @property
    def navigation_second(self):
        u"""
        We return the sub navigation pages.
        """
        nav = []
        for page in self.pages.values():
            if page.is_sub_menu:
                nav.append(page)
        return sorted(nav, key=lambda page: page.sorted)

    @property
    def languages(self):
        u"""
        We return a list with the active languages of the site.
        """
        languages = self.language.split(',')
        valid_languages = []
        for language in languages:
            if language != '':
                valid_languages.append(language)
        return valid_languages

    @property
    def languages_dict(self):
        u"""
        Returns a dictionary with the active languages, as key there is the language code,
        and as value the name/description of the language
        """
        languages = {}
        for language in self.languages:
            languages[language] = LANGUAGE_NAMES[language]
        return languages
    
    @property
    def branch(self):
        if len(self.branches):
            return self.branches[0]
        return None
            
    @property
    def branches(self):
        if not hasattr(self, '_cache_branches'):
            self._cache_branches = list(self.branch_set.is_activated().order_by('is_root'))
        return self._cache_branches
            
    @property
    def licenses(self):
        if not hasattr(self, '_cache_licenses'):
            self._cache_licenses = list(self.license_set.is_activated())
        return self._cache_licenses

    @property
    def marketing_claims(self):
        if not hasattr(self, '_marketing_claims'):
            self._marketing_claims = list(self.marketing_claim_set.is_activated())
        return self._marketing_claims

    @property
    def social_networks(self):
        if not hasattr(self, '_social_networks'):
            self._social_networks = list(self.social_network_set.is_activated())
        return self._social_networks

    @property
    def operating_hours(self):
        if not hasattr(self, '_operating_hours'):
            self._operating_hours = list(self.operating_hour_set.all().order_by('weekday'))
        return self._operating_hours

    @property
    def operating_days(self):
        days = []
        grouped = []
        current_group = []

        for hour in self.operating_hours:
            if not current_group:
                current_group.append(hour)
                continue
            prev = current_group[-1]

            same_hours = (
                hour.since_hour == prev.since_hour and
                hour.until_hour == prev.until_hour
            )

            if same_hours:
                current_group.append(hour)
            else:
                grouped.append(current_group)
                current_group = [hour]

        if current_group:
            grouped.append(current_group)

        # build grouped days
        for group in grouped:
            first = group[0]
            last = group[-1]

            # label
            if len(group) == 1:
                label = first.get_weekday_display()
            else:
                label = '%s-%s' % (
                    first.get_weekday_display(),
                    last.get_weekday_display()
                )

            # hours
            if first.since_hour and first.until_hour:
                hours = '%s - %s' % (
                    first.since_hour.strftime('%H:%M'),
                    first.until_hour.strftime('%H:%M')
                )
            else:
                hours = _('Closed')

            days.append({
                'label': label,
                'closed': False,
                'day_number': first.weekday,
                'since_hour': first.since_hour,
                'until_hour': first.until_hour,
                'hour_text': hours
            })

        # closed days
        open_days = [hour.weekday for hour in self.operating_hours]
        for day_number, day_name in OperatingHour.WEEKDAYS:
            if day_number not in open_days:
                days.append({
                    'label': day_name,
                    'closed': True,
                    'day_number': day_number,
                    'since_hour': None,
                    'until_hour': None,
                    'hour_text': _('Closed')
                })

        days = sorted(days, key=lambda k: k['day_number'])

        return days
    
    @property
    def hotline(self):
        try:
            return self.branch.hotline
        except:
            return None

    @property
    def hotlines(self):
        return list({
            branch.hotline for branch in self.branches if branch.hotline
        })
    
    @property
    def phone(self):
        try:
            return self.branch.phone
        except:
            return None

    @property
    def phones(self):
        return list({
            branch.phone for branch in self.branches if branch.phone
        })

    @property
    def fax(self):
        try:
            return self.branch.fax
        except:
            return None

    @property
    def faxes(self):
        return list({
            branch.fax for branch in self.branches if branch.fax
        })

    @property
    def email(self):
        try:
            return self.branch.email
        except:
            return None

    @property
    def emails(self):
        return list({
            branch.fax for branch in self.branches if branch.email
        })

    @property
    def address(self):
        try:
            return self.branch.address
        except:
            return None

    @property
    def addresses(self):
        return list({
            branch.address for branch in self.branches if branch.address
        })

    @property
    def location(self):
        try:
            return {
                'lat': self.branch.geolat,
                'lng': self.branch.geolng,
                'zoom': self.branch.geozm,
            }
        except:
            return None

    @property
    def locations(self):
        return list({
            {
                'lat': branch.geolat,
                'lng': branch.geolng,
                'zoom': branch.geozm,
            }
            for branch in self.branches
            if branch.geolat and branch.geolng and branch.geozm
        })
        
    @property
    def banners(self):
        if not hasattr(self, '_cache_banners'):
            self._cache_banners = list(self.banner_set.is_activated(True))
        return self._cache_banners
    
    @property
    def highlights(self):
        if not hasattr(self, '_cache_highlights'):
            self._cache_highlights = list(self.highlight_set.is_activated())
        return self._cache_highlights
    
    @property
    def features(self):
        return sorted(
            filter(lambda x: x.type == Highlight.Type.FEATURE, self.highlights),
            key=lambda x: x.sorted_as,
        )
    
    @property
    def trusted_infos(self):
        return sorted(
            filter(lambda x: x.type == Highlight.Type.TRUSTED_INFO, self.highlights),
            key=lambda x: x.sorted_as,
        )
    
    @property
    def partner_brands(self):
        return sorted(
            filter(lambda x: x.type == Highlight.Type.PARTNER_BRAND, self.highlights),
            key=lambda x: x.sorted_as,
        )
    
    @property
    def testimonials(self):
        if not hasattr(self, '_cache_testimonials'):
            self._cache_testimonials = list(self.testimonial_set.is_activated())
        return self._cache_testimonials
    
    @property
    def brands(self):
        if not hasattr(self, '_cache_brands'):
            self._cache_brands = list(self.brand_set.is_activated())
        return self._cache_brands
    
    @property
    def dynamic_categories(self):
        grouped = defaultdict(list)
        for c in self.category_dynamic.is_activated():
            grouped[c.target_type].append(c)
        return grouped
    
    @property
    def home_categories(self):
        grouped = defaultdict(list)
        for c in self.category_dynamic.is_featured():
            grouped[c.target_type].append(c)
        return grouped
    
    @property
    def home_solutions(self):
        return sorted(
            filter(lambda x: x.is_homepage, self.solutions),
            key=lambda x: x.sorted_as,
        )
    
    @property
    def solutions(self):
        if not hasattr(self, '_cache_solutions'):
            try:
                self._cache_solutions = list(self.solution_set.is_activated())
            except:
                self._cache_solutions = []
        return self._cache_solutions
        
    @property
    def home_projects(self):
        return sorted(
            filter(lambda x: x.is_homepage, self.projects),
            key=lambda x: x.sorted_as,
        )
    
    @property
    def projects(self):
        if not hasattr(self, '_cache_projects'):
            try:
                self._cache_projects = list(self.project_set.is_activated())
            except:
                self._cache_projects = []
        return self._cache_projects

    def _load_constants(self):
        u"""
        We load all the constants of the site and save them
        in the __dict__ itself, as if it were one more attribute of the object
        """
        for constant in self.constant_set.all():
            try:
                self.__dict__[constant.name] = constant.type_value
            except Exception:
                pass
        self._constant_loaded = True
    
    def has_feature(self, feature):
        return feature in self.features_flag

    def constant(self, key, default=None):
        u"""
        Constants can be accessed through the __getter__
        of the object, that is by doing object.constant_name.
        But if, for example, we are interested in returning the constant,
        but if it does not exist, return the default.

        Example: site.constant('motor_plus', False)
        """
        # Check necessary because the _load_constants is only
        # called when saving a site or when going through
        # the site_engine.handler. This excludes any url served through a urls.py
        if not hasattr(self, '_constant_loaded'):
            self._load_constants()
        if not hasattr(self, key):
            return default
        return self.__dict__[key]

    def _load_page_urls(self, auto_detect=True):
        u"""
        We load the dictionary where with all the pages of the site,
        where the key is the regular expression of the url, and the value, the page object.
        We save this dictionary in the object itself, in the urls_pages attribute
        """
        self.page_urls = []
        pages = self.page_set.filter(is_active=True).order_by('reversed_as')
        for page in pages:
            if auto_detect:
                for language in self.languages:
                    group = (DEFAULT_LANGUAGE == language) # is default language
                    self.page_urls.append(
                        (page.pattern_url(expresion_r=True, language=language, group=group), page, language)
                    )
            else:
                self.page_urls.append(
                    (page.pattern_url(expresion_r=True), page, CURRENT_LANGUAGE)
                )

    def page(self, name):
        u"""
        Returns a site page, as long as the _pages have loaded
        """
        try:
            return self.pages[name]
        except KeyError:
            return None


class Branch(models.Model, metaclass=TransMeta):
    objects = GeneralManager()

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='branch_set',
        verbose_name=_(u'Site'),
    )
    name = models.CharField(_(u'Name'), max_length=150)
    address = models.CharField(_(u'Address'), blank=True, null=True, max_length=250)
    description = models.TextField(_(u'Description'), blank=True, null=True)
    email = models.CharField(_(u'Email'), max_length=100, null=True, blank=True)
    hotline = models.CharField(_(u'Hotline'), blank=True, null=True, max_length=30)
    phone = models.CharField(_(u'Phone'), blank=True, null=True, max_length=30)
    fax = models.CharField(_(u'Fax'), max_length=100, null=True, blank=True)
    geolat =models.CharField(_(u'Latitude'), blank=True, null=True, max_length=50)
    geolng = models.CharField(_(u'Longitude'), blank=True, null=True, max_length=50)
    geozm = models.CharField(_(u'Zoom'), blank=True, null=True, max_length=10)
    logo = models.ImageField(_(u'Logo'), null=True, blank=True, upload_to=upload_to('uploads/branch/logos'))
    
    icon_svg = models.TextField(_(u'Svg'), blank=True, null=True)
    icon_img = ImageField(_(u'Icon'), blank=True, null=True, upload_to=upload_to('uploads/branch/icons'))
    icon_name = models.CharField(_(u'Name'), max_length=150, blank=True, null=True)
    icon_code = models.CharField(_(u'Code'), max_length=30, blank=True, null=True,
        help_text=mark_safe("<a target='_blank' href='https://fontawesome.com/search?o=r&f=brands'>https://fontawesome.com/search?o=r&f=brands</a>"),
    )

    sorted_as = models.PositiveIntegerField(_(u'Sorting'), default=0)
    is_active = models.BooleanField(_(u'Active'), default=True)
    is_root= models.BooleanField(_(u'Root'), default=False)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Branch')
        verbose_name_plural = _(u'Branches')
        translate = ('name', 'address', 'description',)
        ordering = ('is_root', 'sorted_as', '-is_active',)

    def __str__(self):
        return self.name


class License(models.Model, metaclass=TransMeta):
    class LicenseType(models.TextChoices):
        BCT_NOTIFICATION = ('bct_notification', _(u'Ministry of Industry and Trade Website Notification'),)
        BCT_REGISTRATION = ('bct_registration', _(u'Ministry of Industry and Trade E-commerce Registration'),)
        BUSINESS_LICENSE = ('business_license',_(u'Business Registration Certificate'),)
        ICP_LICENSE = ('icp_license', _(u'ICP License'),)
        SOCIAL_NETWORK_LICENSE = ('social_network_license', _(u'Social Network License'),)
        TRADEMARK_CERTIFICATE = ('trademark_certificate', _(u'Trademark Certificate'),)
        COPYRIGHT_CERTIFICATE = ('copyright_certificate', _(u'Copyright Certificate'),)
        SSL_CERTIFICATE = ('ssl_certificate', _(u'SSL Certificate'),)
        OTHER = ('other', _(u'Other'),)

    objects = GeneralManager()

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='license_set',
        verbose_name=_(u'Site'),
    )
    type = models.CharField(max_length=50, choices=LicenseType.choices, default=LicenseType.OTHER, verbose_name=_(u'Type'))
    number = models.CharField(max_length=255, blank=True, verbose_name=_(u'Number'))
    link = models.CharField(max_length=255, blank=True, verbose_name=_(u'Link'))
    logo = ImageField(u'Logo', upload_to=upload_to('uploads/license/logos'), null=True, blank=True)
    issue_date = models.DateField(null=True, blank=True, verbose_name=_(u'Issue Date'))
    renewal_date = models.DateField(null=True, blank=True, verbose_name=_(u'Renewal Date'), help_text=_(u'Latest renewal date if applicable'))
    notes = models.TextField(blank=True, verbose_name=_(u'Notes'))

    sorted_as = models.PositiveIntegerField(_(u'Sorting'), default=0)
    is_active = models.BooleanField(_(u'Active'), default=True)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'License')
        verbose_name_plural = _(u'Licenses')
        ordering = ('type', 'sorted_as', '-is_active',)
        translate = ('notes',)
        unique_together = ('site', 'type')

    def __str__(self):
        return f'{self.number} - {self.license_date}'
    
    @property
    def license_date(self):
        return self.renewal_date or self.issue_date


class MarketingClaim(models.Model, metaclass=TransMeta):
    objects = GeneralManager()

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='marketing_claim_set',
        verbose_name=_(u'Site'),
    )

    code = models.CharField(_(u'Code'), max_length=10, blank=True, null=True, default='')
    label = models.CharField(_(u'Label'), max_length=100, blank=True, null=True)
    title = models.CharField(_(u'Title'), max_length=255, blank=True, null=True)
    subtitle = models.CharField(_(u'Sub-Title'), max_length=255, blank=True, null=True)
    description = models.TextField(_(u'Description'), blank=True, null=True)
    
    icon_svg = models.TextField(_(u'Svg'), blank=True, null=True)
    icon_img = ImageField(_(u'Icon'), blank=True, null=True, upload_to=upload_to('uploads/marketing-claim/icons'))
    icon_name = models.CharField(_(u'Name'), max_length=150, blank=True, null=True)
    icon_code = models.CharField(_(u'Code'), max_length=30, blank=True, null=True,
        help_text=mark_safe("<a target='_blank' href='https://fontawesome.com/search?o=r&f=brands'>https://fontawesome.com/search?o=r&f=brands</a>"),
    ) 
   
    button_text = models.CharField(_(u'Button Text'), max_length=100, blank=True, null=True)
    button_link = models.URLField(u'Button Link', null=True, blank=True)

    is_active = models.BooleanField(_(u'Active'), default=True)
    sorted_as = models.PositiveIntegerField(_(u'Sorting'), default=0)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Marketing claim')
        verbose_name_plural = _(u'Marketing claims')
        translate = ('label', 'title', 'subtitle', 'description', 'button_link', 'button_text',)
        ordering = ('sorted_as', '-is_active',)

    def __str__(self):
        return '(%s)' % (self.title)


class SocialNetwork(models.Model, metaclass=TransMeta):
    objects = GeneralManager()

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='social_network_set',
        verbose_name=_(u'Site'),
    )
    name = models.CharField(_(u'Name'), max_length=30)
    url = models.URLField(_(u'Url'), max_length=200, blank=True, null=True)
    
    icon_svg = models.TextField(_(u'Svg'), blank=True, null=True)
    icon_img = ImageField(_(u'Icon'), blank=True, null=True, upload_to=upload_to('uploads/social-network/icons'))
    icon_name = models.CharField(_(u'Name'), max_length=150, blank=True, null=True)
    icon_code = models.CharField(_(u'Code'), max_length=30, blank=True, null=True,
        help_text=mark_safe("<a target='_blank' href='https://fontawesome.com/search?o=r&f=brands'>https://fontawesome.com/search?o=r&f=brands</a>"),
    )

    is_active = models.BooleanField(_(u'Activate'), default=True)
    sorted_as = models.PositiveIntegerField(_(u'Sorting'), default=0)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Social network')
        verbose_name_plural = _(u'Social networks')
        # translate = ('name',)
        ordering = ('sorted_as', '-is_active',)

    def __str__(self):
        return '(%s)' % (self.name)
    

class OperatingHour(models.Model, metaclass=TransMeta):
    WEEKDAYS = [
      (1, _('Monday')),
      (2, _('Tuesday')),
      (3, _('Wednesday')),
      (4, _('Thursday')),
      (5, _('Friday')),
      (6, _('Saturday')),
      (7, _('Sunday')),
    ]
    
    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='operating_hour_set',
        verbose_name=_(u'Site'),
    )
    weekday = models.IntegerField(choices=WEEKDAYS)
    since_hour = models.TimeField(_(u'From Hour'))
    until_hour = models.TimeField(_(u'To Hour'))
    
    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Operating hour')
        verbose_name_plural = _(u'Operating hours')
        ordering = ('weekday', 'since_hour')
        unique_together = ('weekday', 'since_hour', 'until_hour')

    def __str__(self):
        return u'%s: %s - %s' % (self.get_weekday_display(), self.since_hour, self.until_hour)


class Constant(models.Model):
    TYPES = (
        ('STR', u'STRING'),
        ('INT', u'INTEGER'),
        ('LIST', u'LIST'),
        ('DICT', u'DICTIONARY'),
        ('BOOL', u'BOOLEAN'),
        ('DATE', u'DATETIME'),
    )

    OK_VALUES = frozenset(('ok', 'activated', 'yes', 'on', 'true', 'real', '1'))

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='constant_set',
        verbose_name=_(u'Site'),
    )
    name = models.CharField(
        _(u'Name'), max_length=30,
        help_text=_(u'Lowercase. As if it were an attribute of the site itself. It is accessed with a site __get__.'),
    )
    type = models.CharField(_(u'Type'), max_length=10, choices=TYPES, default='STR')
    type_value = models.TextField(_(u'Value'), blank=True, null=True,)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Constant')
        verbose_name_plural = _(u'Constants')

    def __str__(self):
        return '%s-%s' % (self.site.code, self.name)

    @property
    def value(self):
        u"""
        We return the type_value, but with the type specified in the model.
        For example, if the constant is a boolean and has a value of 1, we return a True
        """
        if self.type == 'STR':
            return self.type_value
        elif self.type == 'INT':
            return int(self.type_value, 10)
        elif self.type in ('LIST', 'DICT'):
            return ast.literal_eval(self.type_value)
        elif self.type == 'BOOL':
            try:
                return bool(int(self.type_value))
            except ValueError:
                return self.type_value in self.OK_VALUES
        elif self.type == 'DATE':
            return dateutil.parser.parse(self.type_value)
        else:
            return None


class Page(models.Model, metaclass=TransMeta):
    objects = GeneralManager()
    ADMIN_ORDER = 2

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='page_set',
        verbose_name=_(u'Site'),
    )
    parent = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name='nested_set',
        verbose_name=_(u'Parent'),
        help_text=_(u'Parent page. It is used to create nested lists in the sitemap'),
    )

    code = models.CharField(
        _(u'Code'), max_length=25,
        help_text=_(u'Identifier code of the page. It is usually a text string, written in lowercase'),
    )
    icon = ImageField(_(u'Icon'), blank=True, null=True, upload_to=upload_to('uploads/page/icons'))
    is_active = models.BooleanField(_(u'Active'), default=False)
    is_external = models.BooleanField(
        _(u'External'), default=False,
        help_text=_(u'Indicates if the link on this page redirects to an external website'),
    )
    is_internal = models.BooleanField(
        _(u'Internal'), default=False,
        help_text=_(u'Indicates if the link on this page link to an internal articles'),
    )
    is_ssl = models.BooleanField(
        _(u'SSL'), default=False,
        help_text=_(u'Indicates if this page use https'),
    )

    is_index = models.BooleanField(_(u'Index'), default=True)
    is_follow = models.BooleanField(_(u'Follow'), default=True)
    is_archive = models.BooleanField(_(u'Archive'), default=True)
    is_snippet = models.BooleanField(_(u'Snippet'), default=True)

    is_home = models.BooleanField(_(u'Home'), default=False, help_text=_(u'Indicates if this page is the home'))
    is_tac = models.BooleanField(_(u'Terms of Use'), default=False, help_text=_(u'Indicates the Terms of Use page'))
    is_ppl = models.BooleanField(_(u'Privacy Policy'), default=False, help_text=_(u'Indicates the Privacy Policy page'))
    is_top_menu = models.BooleanField(_(u'Top Menu'), default=False)
    is_sub_menu = models.BooleanField(_(u'Sub Menu'), default=False)

    top_menu_row = models.IntegerField(_(u'Row'), blank=True, null=True, default=0)
    top_menu_col = models.IntegerField(_(u'Column'), blank=True, null=True, default=0)
    sub_menu_row = models.IntegerField(_(u'Row'), blank=True, null=True, default=0)
    sub_menu_col = models.IntegerField(_(u'Column'), blank=True, null=True, default=0)

    reversed_as = models.IntegerField(_(u'Order Url'), default=0, help_text=_(u'Order for when a url-reverse is done'))
    name = models.CharField(_(u'Name'), max_length=150, default='')
    url = models.CharField(
        _(u'Url'), max_length=150, blank=True, null=True,
        help_text=_(u'If no URL is specified, it is built from the page name plus the .htm extension. Otherwise, add the full regular expression.'),
    )
    content = RichTextField(_(u'Content'), blank=True, null=True)


    meta_title = models.CharField(_(u'Meta Title'), max_length=255, blank=True, null=True)
    meta_description = models.CharField(_(u'Meta Description'), max_length=255, blank=True, null=True)
    meta_keywords = models.CharField(_(u'Meta Keywords'), max_length=255, blank=True, null=True)
    meta_type = models.CharField(_(u'Meta Type'), max_length=60, blank=True, null=True)
    meta_card = models.CharField(_(u'Meta Card'), max_length=255, blank=True, null=True)
    meta_image = models.CharField(_(u'Meta Image'), max_length=255, blank=True, null=True)
    meta_schema = models.TextField(_(u'Meta Schema'), blank=True, null=True)
    
    cta_enable = models.BooleanField(_(u'Enable'), null=True, default=False)
    cta_title = models.CharField(_(u'Title'), max_length=255, blank=True, null=True)
    cta_subtitle = models.CharField(_(u'Subtitle'), max_length=255, blank=True, null=True)
    cta_description = models.TextField(_(u'Description'), blank=True, null=True)
    cta_image = ImageField(_(u'Image'), blank=True, null=True, upload_to=upload_to('uploads/page/ctas'))

    view = models.CharField(
        _(u'Template View'), max_length=150, default="CmsEngineView.as_view(template_name='home.html')", # default="CmsEngineView.as_view(template_name='%s/home.html')" % default_site_code,
        help_text=_(u'By default we use the generic views of the CMS, but it can be replaced by any other.'),
    )
    context = models.CharField(
        _(u'Context'), max_length=100, default='', blank=True, null=True,
        help_text=_(u'A method that returns a dictionary can be specified to pass a custom context to your view.'),
    )
    cache_context = models.BooleanField(
        _(u'Cache context'), default=False,
        help_text=_(u'If enabled, the system will automatically cache the entire context to save time.'),
    )

    content_type = models.CharField(_(u'Context type'), max_length=50, blank=True, null=True)
    context_name = models.CharField(_(u'Context name'), max_length=50, blank=True, null=True, default="object")
    lookup_field = models.CharField(_(u'Lookup field'), max_length=50, blank=True, null=True, default="slug")

    # H...
    h1 = models.CharField(_(u'H1'), max_length=255, blank=True, null=True, default='')
    h2 = models.CharField(_(u'H2'), max_length=255, blank=True, null=True, default='')
    h3 = models.CharField(_(u'H3'), max_length=255, blank=True, null=True, default='')

    # Sitemap
    FREQUENCIES = (
        ('always', _(u'always')),
        ('hourly', _(u'hourly')),
        ('daily', _(u'daily')),
        ('weekly', _(u'weekly')),
        ('monthly', _(u'monthly')),
        ('yearly', _(u'yearly')),
        ('never', _(u'never')),
    )
    PRIORITIES = (
        ('0.1', '0.1'),
        ('0.2', '0.2'),
        ('0.3', '0.3'),
        ('0.4', '0.4'),
        ('0.5', '0.5'),
        ('0.6', '0.6'),
        ('0.7', '0.7'),
        ('0.8', '0.8'),
        ('0.9', '0.9'),
        ('1.0', '1.0'),
    )
    changefreq = models.CharField(_(u'Frequency'), max_length=10, default='monthly', choices=FREQUENCIES)
    priority = models.CharField(_(u'Priority'), max_length=4, default='0.5', choices=PRIORITIES)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Page Setting')
        verbose_name_plural = _(u'Page Settings')
        translate = (
            'name', 'url', 'content',
            'meta_title', 'meta_description', 'meta_keywords',
            'h1', 'h2', 'h3',
            'cta_enable', 'cta_image', 'cta_title', 'cta_subtitle', 'cta_description',
        )
        ordering = (
            'site','parent_id', '-is_home',
            '-is_top_menu', 'top_menu_row', 'top_menu_col',
            '-is_sub_menu', 'sub_menu_row', 'sub_menu_col',
        )

    def __str__(self):
        if self.parent:
            return '%s => %s' %(self.parent, self.name)
        return self.name

    @property
    def banners(self):
        if not hasattr(self, '_cache_banners'):
            self._cache_banners = list(self.banner_set.is_activated(True))
        return self._cache_banners
    
    @property
    def sliders(self):
        return [b for b in self.banners if b.type == Banner.BannerType.SLIDER]
    
    @property
    def popups(self):
        return [b for b in self.banners if b.type == Banner.BannerType.POPUP]
    
    @property
    def promos(self):
        return [b for b in self.banners if b.type == Banner.BannerType.PROMO]
    
    @property
    def backgrounds(self):
        return [b for b in self.banners if b.type == Banner.BannerType.HERO]
    
    @property
    def background(self):
        if len(self.backgrounds):
            return self.backgrounds[0]
        return None
    
    @property
    def highlights(self):
        if not hasattr(self, '_cache_highlights'):
            self._cache_highlights = list(self.highlight_set.is_activated())
        return self._cache_highlights
    
    @property
    def features(self):
        return sorted(
            filter(lambda x: x.type == Highlight.Type.FEATURE, self.highlights),
            key=lambda x: x.sorted_as,
        )
    
    @property
    def trusted_infos(self):
        return sorted(
            filter(lambda x: x.type == Highlight.Type.TRUSTED_INFO, self.highlights),
            key=lambda x: x.sorted_as,
        )
    
    @property
    def testimonials(self):
        if not hasattr(self, '_cache_testimonials'):
            self._cache_testimonials = list(self.testimonial_set.is_activated())
        return self._cache_testimonials
    
    @property
    def brands(self):
        if not hasattr(self, '_cache_brands'):
            self._cache_brands = list(self.brand_set.is_activated())
        return self._cache_brands
    
    @property
    def robots(self):
        return ",".join(filter(None, [
            "noindex" if not self.is_index else "index",
            "nofollow" if not self.is_follow else "follow",
            "noarchive" if  not self.is_archive else None,
            "nosnippet" if not self.is_snippet else None,
        ]))
    
    @property
    def level(self):
        if not self.parent:
            return 0
        return 1 + self.parent.level
    
    @property
    def sorted(self):
        return self.top_menu_col * 1000 + self.top_menu_row * 100 + self.sub_menu_col * 10 + self.sub_menu_row
    
    @property
    def nested_pages(self):
        return self.nested_set.filter(is_active=True)

    @property
    def view_callback(self):
        u"""
        Returns the view object
        """
        def _return_view_path(view):
            u"""
            Data a view url of the type
                project.apps.views.View.as_view(...)
            we return the project.apps.views
            """
            routes = []
            for item in view.split('.'):
                routes.append(item)
                if item == 'views':
                    break
            return '.'.join(routes)

        def _return_views(view):
            u"""
            Given project.apps.views.View.as_view(...), we return the View
            """
            parts = view.split('.')
            return [parts[parts.index('views')+1]]

        def _return_asview(view):
            u"""
            We return the as_view
            """
            return view[view.find('.as_view'):]

        view_exc = {}
        try:
            exec('view = %s' % self.view, globals(), view_exc)
        except NameError:
            # We must perform the import of the object.
            module = __import__(
                _return_view_path(self.view),
                fromlist=_return_views(self.view)
            )

            try:
                view_exc['view'] = getattr(module, _return_views(self.view)[0])
            except AttributeError:
                raise Exception(_(u'There is no view: %s') % self.view)

            exec('view = view%s' % _return_asview(self.view), globals(), view_exc)

        return view_exc['view']
    
    def pattern_url(self, language=None, expresion_r=True, group=True, domain='', reversed=False):
        u"""
        We return the pattern of the url. This can be used in the construction
        of the urls dispatcher, or to have the url when building the sitemap.
        """
        if not language:
            language = get_language().split('-')[0]

        url = getattr(self, 'url_' + language)

        # First we check if we have the url, if not, we build it with
        # the page name slug
        if not url:
            # we remove the html tags from the name before getting the slug
            name = getattr(self, 'name_' + language)
            name = strip_tags(name)
            url = slugify(name) + '.htm'

        # The pattern of the home page differs from that of the other pages
        if getattr(settings, 'CMS_FUTURE', False):
            pattern = domain + url
        else:
            pattern = domain + ('' if (self.is_home and group) else url)

        if self.is_internal and not reversed and not self.is_home:
            # pattern = pattern + '(?P<pk>\d+/?)?'
            if '<slug>' not in pattern or '(?P<slug>' not in pattern:
                pattern = pattern + r'(?P<pk>\d+/?)?'

        if expresion_r and not '^' in pattern:
            pattern = r'^' + pattern + '$'

        return pattern

    def reverse(self, params=[], language=None, **kwargs):
        u"""
        We perform the reverse of the url
        """
        if self.is_home:
            return '/'

        # If in the url field there is a complete url, with http, we return this
        if self.url:
            if 'http://' in self.url or 'https://' in self.url:
                return self.url

        urlp, fields = normalize(self.pattern_url(expresion_r=True, language=language, reversed=True))[0]

        subst = dict(zip(fields, params))

        if not len(subst) and len(kwargs):
            subst = kwargs

        try:
            if getattr(settings, 'CMS_FUTURE', False):
                return urlp % subst
            else:
                return '/' + urlp % subst
        except KeyError:
            return '/'

    def save(self, **kwargs):
        u"""
        We verify that the url in the different languages ends in '/', if not, we add it.
        """
        if getattr(settings, 'CMS_FUTURE', False):
            # The new dispatcher delegates a lot of work to the database, so
            # that we need to leave the ground well prepared
            if self.is_home:
                for language_code, n in settings.LANGUAGES:
                    setattr(self, 'url_' + language_code, "/")
            else:
                for language_code, n in settings.LANGUAGES:
                    try:
                        url = getattr(self, 'url_' + language_code).strip()
                    except AttributeError:
                        url = ""
                    if url:
                        if not url.startswith('/'):
                            url = '/' + url
                        if not url.endswith(('.htm', '.html', '/')):
                            url += '/'
                    else:
                        try:
                            name = getattr(self, 'name_' + language_code).strip()
                        except AttributeError:
                            name = ''
                        if name:
                            url = '/%s.htm' % slugify(strip_tags(name))
                    setattr(self, 'url_' + language_code, url)
        else:
            for language_code, _ in settings.LANGUAGES:
                url = getattr(self, 'url_' + language_code)
                if url:
                    if len(url) > 100:
                        raise ValueError(u'URL too long, the CMS cannot be upgraded')
                    if not url.endswith('.htm') and not url.endswith('.html'):
                        setattr(self, 'url_' + language_code, getattr(self, 'url_' + language_code).rstrip('/') + '/')

        super(Page, self).save(**kwargs)

class MetaObject(models.Model, metaclass=TransMeta):
    page = models.ForeignKey(Page, on_delete=models.CASCADE, verbose_name=_(u'Page'))
    object = models.CharField(
        _(u'Object'), max_length=25,
        help_text=_(u'Name of the object that is passed in the context of the page'),
    )
    field = models.CharField(_(u'Field'), max_length=25, help_text=_(u'Model field to match the value'))
    value = models.CharField(_(u'Value'), max_length=30)
    meta_title = models.CharField(_(u'Meta title'), max_length=255, blank=True, null=True)
    meta_description = models.CharField(_(u'Meta description'), max_length=255, blank=True, null=True)
    meta_keywords = models.CharField(_(u'Meta keywords'), max_length=255, blank=True, null=True)

    class Meta:
        verbose_name = _(u'Meta Object')
        verbose_name_plural = _(u'Meta Objects')
        translate = ('meta_title', 'meta_description', 'meta_keywords',)


class Redirection(models.Model):
    ADMIN_ORDER = 7
    
    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='redirection_set',
        verbose_name=_(u'Site'),
    )
    old_url = models.CharField(
        _(u'Url old'), max_length=200,
        help_text=_(u'Without the domain name. Only from the domain name. For example: /reviews.htm')
    )
    new_url = models.CharField(
        _(u'Url new'), max_length=200,
        help_text=_(u'The complete url, with the domain, where it will be redirected. If this field is blank, the system does a 410 redirect (Gone away)'),
    )

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'URL Redirect')
        verbose_name_plural = _(u'URL Redirects')

    def __str__(self):
        return "%s ---> %s" % (self.old_url, self.new_url)


class Translation(models.Model, metaclass=TransMeta):
    ADMIN_ORDER = 6

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='translation_set',
        blank=True,
        null=True,
        verbose_name=_(u'Site'),
        help_text=_(u'If a site is specified, common for all pages of the site'),
    )
    page = ChainedForeignKey(
        Page,
        on_delete=models.CASCADE,
        related_name='translation_set',
        chained_field='site',
        chained_model_field='site',
        verbose_name=_(u'Page'),
        show_all=False,
        auto_choose=False,
        blank=True,
        null=True,
        help_text=_(u'If a page is specified, only for the specified page'),
    )
    identifier = models.TextField(_(u'Identifier'))
    value = models.TextField(_(u'Value'), blank=True, null=True, default='')
    exists = models.BooleanField(
        _(u'Exists'), default=True,
        help_text=_(u'Indicates if the translation exists in any of the templates. There is a command that performs this check.'),
    )

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Translation')
        verbose_name_plural = _(u'Translations')
        translate = ('value',)

    def __str__(self):
        return self.identifier

    def clear_cache(self):
        u"""
        We remove this translation from the cache so that it will be generated again next time
        """
        try:
            site = self.site if self.site else self.page.site
            cache_key = 'cache_site_translation__%s' % (site.code)
            cache_data = cache.get(cache_key)
            if cache_data:
                try:
                    del cache_data[self.identifier]
                except KeyError:
                    pass
                else:
                    cache.set(cache_key, cache_data)
        except:
            pass


class Banner(models.Model, metaclass=TransMeta):
    objects = AvailabilityManager()
    ADMIN_ORDER = 3
    
    class BannerType(models.IntegerChoices):
        HERO = 1, _(u"Hero")
        POPUP = 2, _(u"Popup")
        SLIDER = 3, _(u"Slider")
        PROMO = 4, _(u"Promo")

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='banner_set',
        blank=True,
        null=True,
        verbose_name=_(u'Site'),
        help_text=_(u'If a site is specified, common for all banners of the site'),
    )
    page = ChainedForeignKey(
        Page,
        on_delete=models.CASCADE,
        related_name='banner_set',
        chained_field='site',
        chained_model_field='site',
        verbose_name=_(u'Page'),
        show_all=False,
        auto_choose=False,
        blank=True,
        null=True,
        help_text=_(u'If a page is specified, only for the specified page'),
    )

    type = models.IntegerField(_(u'Type'), choices=BannerType.choices)
    status = models.BooleanField(_(u'Status'), null=True, default=True)
    image = ImageField(_(u'Image'), null=True, blank=True, upload_to=upload_to('uploads/banner/images'))
    video = models.FileField(_(u'Video'), null=True, blank=True, upload_to=upload_to('uploads/banner/videos'))
    label = models.CharField(_(u'Label'), max_length=100, blank=True, null=True)
    title = models.CharField(_(u'Title'), max_length=255, blank=True, null=True)
    subtitle = models.CharField(_(u'Sub-Title'), max_length=255, blank=True, null=True)
    description = models.TextField(_(u'Description'), blank=True, null=True)
    button_text = models.CharField(_(u'Button Text'), max_length=100, blank=True, null=True)
    button_link = models.URLField(u'Button Link', null=True, blank=True)

    since_date = models.DateTimeField(_(u'Since Date'), null=True, blank=True)
    until_date = models.DateTimeField(_(u'Until Date'), null=True, blank=True)

    is_active = models.BooleanField(_(u'Active'), default=True)
    sorted_as = models.PositiveIntegerField(_(u'Sorting'), default=0)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Page Banner')
        verbose_name_plural = _(u'Page Banners')
        translate = ('status', 'image', 'video', 'title', 'subtitle', 'label', 'description', 'button_link', 'button_text',)
        ordering = ('sorted_as', 'created_at')

    def __str__(self):
        return f"{self.type} - {self.title}"


class Highlight(models.Model, metaclass=TransMeta):
    objects = GeneralManager()
    ADMIN_ORDER = 5

    class Type(models.TextChoices):
        FEATURE = "FEATURE", _(u"Feature")
        TRUSTED_INFO = "TRUSTED_INFO", _(u"Trusted Info")
        WORKFLOW = "WORKFLOW", _(u"Workflow")
        PARTNER_BRAND = "PARTNER_BRAND", _(u"Partner Brand")
        THINGS_NEED_TO_KNOW = "THINGS_NEED_TO_KNOW", _(u"Things Need to Know")

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='highlight_set',
        blank=True,
        null=True,
        verbose_name=_(u'Site'),
        help_text=_(u'If a site is specified, common for all highlights of the site'),
    )
    page = ChainedForeignKey(
        Page,
        on_delete=models.CASCADE,
        related_name='highlight_set',
        chained_field='site',
        chained_model_field='site',
        verbose_name=_(u'Page'),
        show_all=False,
        auto_choose=False,
        blank=True,
        null=True,
        help_text=_(u'If a page is specified, only for the specified page'),
    )

    type = models.CharField(max_length=30, choices=Type.choices, default=Type.FEATURE)
    code = models.SlugField(_(u'Code'), max_length=50, blank=True, null=True)
    label = models.CharField(_(u'Label'), max_length=100, blank=True, null=True)
    title = models.CharField(_(u'Title'), max_length=255, blank=True, null=True)
    subtitle = models.CharField(_(u'Sub-Title'), max_length=255, blank=True, null=True)
    description = models.TextField(_(u'Description'), blank=True, null=True)

    button_text = models.CharField(_(u'Button Text'), max_length=100, blank=True, null=True)
    button_link = models.URLField(u'Button Link', null=True, blank=True)    
    
    icon_svg = models.TextField(_(u'Svg'), blank=True, null=True)
    icon_img = ImageField(_(u'Icon'), blank=True, null=True, upload_to=upload_to('uploads/service-highlight/icons'))
    icon_name = models.CharField(_(u'Name'), max_length=150, blank=True, null=True)
    icon_code = models.CharField(_(u'Code'), max_length=30, blank=True, null=True,
        help_text=mark_safe("<a target='_blank' href='https://fontawesome.com/search?o=r&f=brands'>https://fontawesome.com/search?o=r&f=brands</a>"),
    )

    is_active = models.BooleanField(_(u'Active'), default=True)
    sorted_as = models.PositiveIntegerField(_(u'Sorting'), default=0)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Service Highlight')
        verbose_name_plural = _(u'Service Highlights')
        translate = ('label', 'title', 'subtitle', 'description', 'button_link', 'button_text',)
        ordering = ('site', 'page', 'type', 'sorted_as', 'is_active', 'created_at')

    def __str__(self):
        return self.label


class Testimonial(models.Model, metaclass=TransMeta):
    objects = GeneralManager()
    ADMIN_ORDER = 6

    RATING_CHOICES = (
        (1, f'1 {_(u'Star')}'),
        (2, f'2 {_(u'Stars')}'),
        (3, f'3 {_(u'Stars')}'),
        (4, f'4 {_(u'Stars')}'),
        (5, f'5 {_(u'Stars')}'),
    )

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='testimonial_set',
        verbose_name=_(u'Site'),
    )
    page = ChainedForeignKey(
        Page,
        on_delete=models.CASCADE,
        related_name='testimonial_set',
        chained_field='site',
        chained_model_field='site',
        verbose_name=_(u'Page'),
        show_all=False,
        auto_choose=False,
        blank=True,
        null=True,
        help_text=_(u'If a page is specified, only for the specified page'),
    )

    customer_name = models.CharField(_(u'Name'), max_length=200)
    customer_title = models.CharField(_(u'Title'), max_length=200, blank=True)
    customer_address = models.CharField(_(u'Address'), max_length=200, blank=True) 
    company_name = models.CharField(_(u'Company'), max_length=200, blank=True)
    avatar = models.ImageField(_(u'Avatar'), upload_to=upload_to('uploads/testimonial/avatars'), blank=True)  
    comment = models.TextField(_(u'Comment'))    
    rating = models.PositiveSmallIntegerField(choices=RATING_CHOICES, default=5, null=True, blank=True, verbose_name=_(u'Rating'))
    
    is_active = models.BooleanField(_(u'Active'), default=True)
    sorted_as = models.PositiveIntegerField(_(u'Sorting'), default=0)
    
    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Testimonial')
        verbose_name_plural = _(u'Testimonials')
        translate = ('customer_name', 'customer_title', 'customer_address', 'company_name', 'comment',)
        ordering = ['-rating', 'sorted_as']

    def __str__(self):
        return f"{self.customer_name} - {self.rating}★"



# DO NOT REMOVE: CmsEngineView is used indirectly,
# for example in the _return_views methods
from site_engine.views import CmsEngineView
from site_engine.signals import *
