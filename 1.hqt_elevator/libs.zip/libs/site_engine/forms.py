
from django import forms
from django.apps import apps
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _

# from captcha.fields import CaptchaField

from site_engine.models import Site

class SiteAdminForm(forms.ModelForm):

    features_flag = forms.MultipleChoiceField(
        choices=Site.FeatureFlag.choices,
        widget=forms.CheckboxSelectMultiple,
        required=False,
    )

    class Meta:
        model = Site
        fields = "__all__"


class PageAdminForm(forms.ModelForm):
    content_type = forms.ChoiceField(
        choices=[],
        required=False,
    )
    
    def clean_code(self):
        u"""
        Until we can use the "unique_together" directive, we prevent
        page code repeat
        """
        
        # there is no need to check if it exists as it is a required field and already checked automatically
        code = self.cleaned_data['code']
        site = self.cleaned_data['site']
        page = self.instance

        if site.page_set.is_activated(code=code).exclude(id=page.id).exists():
            raise ValidationError(_(u'Code exists.'))

        return self.cleaned_data['code']

    def clean_context(self):
        u"""
        We check that the method specified in the context really exists
        """
        context = self.cleaned_data['context']
        if context:
            path = context.split('.')
            try:
                module = __import__('.'.join(path[:-1]), fromlist=path[-1:])
                getattr(module, path[-1])
            except (ImportError, AttributeError):
                raise ValidationError(_(u'Context invalid format'))

        return self.cleaned_data['context']

    def _clean(self, field, lang):
        u"""
        For multilanguage fields, no two values must be the same in two
        different pages for that same language (in different languages yes
        can be. Eg the url "photos" would be the same in Spanish and Catalan)
        """
        site = self.cleaned_data['site']
        page = self.instance

        value = self.cleaned_data['%s_%s' % (field, lang)]
        kwargs = {
            '%s_%s' % (field, lang): value
        }
        if site.page_set.is_activated(**kwargs).exclude(id=page.id).exists():
            raise ValidationError(_(u'Repeated value'))

        return self.cleaned_data['%s_%s' % (field, lang)]

    def __init__(self, *args, **kwargs):
        super(PageAdminForm, self).__init__(*args, **kwargs)

        choices = [("", "---------")]

        for model in apps.get_models():
            if getattr(model, "INTERNAL_SET", False):
                choices.append(
                    (
                        f"{model._meta.app_label}.{model.__name__}",
                        f"{model._meta.app_label} -> {model._meta.verbose_name.title()}",
                    )
                )

        self.fields["content_type"].choices = choices
        
        from functools import partial
        try:
            if hasattr(self.fields, 'site'):
                site = self.fields['site']._queryset[0]
                fields = ['url',]
                for field in fields:
                    for lang in site.languages:
                        # self._clean(field, lang)
                        setattr(self, '%s_%s' % (field, lang), partial(self._clean, field, lang))
                        # does not work properly
                        # lambda: self._clean(field, lang))
        except IndexError:
            pass
