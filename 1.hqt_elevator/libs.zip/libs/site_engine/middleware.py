from importlib import import_module

from django import http
from django.conf import settings
from django.core import management
from django.core.cache import cache
from django.utils import translation
from django.urls import resolve, Resolver404

from site_engine.defaults import MAPPING_LANGUAGE_CODE, MAPPING_LANGUAGE_DOMAIN
from site_engine.models import Site
from shared_engine.transmeta import get_real_language, get_real_fieldname as __


class ResolverMiddleware:
    """
    Resolve site + language early in request lifecycle.
    Keep it lightweight, no DB-heavy operations if possible.
    """

    EXCLUDED_PREFIXES = (
        # "/admin/",
        "/grappelli/",
        "/chaining/",
        "/static/",
        "/media/",
        "/debug/",
        "/__debug__/",
        "/.well-known/",
        "/api/",
        "/health/",
    )

    EXCLUDED_NAMESPACES = {
        # "admin",
        "grappelli",
        "chaining",
        "debug_toolbar",
    }

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        request.site = None
        request.lang = None

        if self._is_excluded(request):
            return self.get_response(request)
        
        self._prev_process(request)
        self._resolve_site(request)
        self._resolve_language(request)        
        return self.get_response(request)

    def _is_excluded(self, request):
        path = request.path_info

        # 1. fast reject (no resolve)
        if path.startswith(self.EXCLUDED_PREFIXES):
            return True

        # 2. optional deeper resolve check
        try:
            match = resolve(path)
        except Resolver404:
            return True

        if match.namespace in self.EXCLUDED_NAMESPACES:
            return True

        return False

    def _prev_process(self, request):
        # We add a functionalized one to clear cache through the url.
        if request.GET.get('t', 0) == '1':
            management.call_command('reload_base_translations', verbosity=0, interactive=False)
            cache.clear()
        elif request.GET.get('c', 0) == '1':
            cache.clear()

        # Another parameter that we can receive is the session, through 's'
        # It's important that this is here. An attempt has been made to place it in the cms handler, but it doesn't work.
        if request.GET.get('s') and request.GET.get('s') != 'None':
            engine = import_module(settings.SESSION_ENGINE)
            session_key = request.GET['s']
            request.session = engine.SessionStore(session_key)
            request.session.modified = True

    def _resolve_site(self, request):
        if hasattr(request, "site") and request.site:
            return request.site

        code = settings.SITE_CODE

        cache_key = f"cache_site__{code}"
        site = cache.get(cache_key) or None
        
        if site is None:
            site = self._fetch_site(code)
            if site:
                site._load_constants()
                site._load_page_urls()
                cache.set(cache_key, site, 300)

        request.site = site
        return site

    def _fetch_site(self, code):
        try:
            return Site.objects.with_all().get(code=code)
        except Site.DoesNotExist:
            return None

    def _resolve_language(self, request):
        deflang = get_real_language(settings.LANGUAGE_CODE)
        reqlang = request.GET.get('lang', None)
        
        if reqlang and reqlang in MAPPING_LANGUAGE_CODE:
            language = reqlang
        else:
            language = deflang

        if hasattr(request, "site") and request.site:
            """
            Available Types:
                0: No language detection
                1: Detected based on subdomain. If it starts with en., de., cat., .pt, etc, this is selected. Otherwise, it is considered EN.
                2: Detected based on the top level domain.
                    .com is ES, .co.uk is EN, .pt is PT, etc. The "FORCE_DOM" field can be used to specify the language.
                    Useful in those cases in which the corporate is of one type and the individual ones of another.
                3: It is detected based on the HTTP_HOST header and the domains that are set in the admin.
            """
            MULTILINGUAL_MODE = request.site.mode

            if MULTILINGUAL_MODE == 0:
                pass

            # type 1: depends on the prefix used in the subdomain (en.example.com, fr.example.com, etc)
            elif MULTILINGUAL_MODE == 1:
                codelang = request.get_host().split(".", 1)[0]
                if codelang in MAPPING_LANGUAGE_CODE:
                    language = codelang

            # type 2: depends on the geographic domain (ex: .com, .co.uk, .fr)
            # those domains whose extension does not match must be specified
            # with the language (eg en.example.com: 'en', instead of 'es')
            elif MULTILINGUAL_MODE == 2:
                host = request.get_host()
                for domain, maplang in MAPPING_LANGUAGE_DOMAIN.items():
                    if host.endswith(domain):
                        language = maplang
                        break
                if len(settings.LANGUAGE_MAPPING_DOMAIN):
                    try:
                        applang = settings.LANGUAGE_MAPPING_DOMAIN[host]
                        language = applang
                    except KeyError:
                        pass

            # type 3: we take the language according to the domain that has been put in admin > sites
            elif MULTILINGUAL_MODE == 3:
                host = request.get_host()
                site = self._resolve_site(request)
                if host and site:
                    for sitelang in site.languages:
                        if host == getattr(site, __('domain', sitelang)):
                            language = sitelang
                            break

        if settings.DEBUG and request.path_info == '/admin/': # --> admin dashboard
                language = 'en'
        
        translation.activate(MAPPING_LANGUAGE_CODE[language])
        
        request.lang = language
        return language


class RedirectionMiddleware:
    u"""Middleware for managing redirects."""
    
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)

        return self.process_response(request, response)
        
    def process_response(self, request, response):
        site = getattr(request, 'site', None)
        if not site:
            return response

        cache_key = 'cache_site_redirection__%s' % site.code
        redirection = cache.get(cache_key)

        # The first time we load the redirection in the cache
        if redirection is None:
            redirection = {}
            for redirect in site.redirection_set.all():
                key = redirect.old_url.strip()
                if key.startswith('http'):
                    key = key.split('//')[1]
                redirection[key] = redirect.new_url.strip()
            cache.set(cache_key, redirection)
        
        try:
            new_url = redirection[request.get_full_path()]
        except KeyError:
            try:
                new_url = redirection[request.get_host() + request.get_full_path()]
            except KeyError:
                pass
            else:
                return self.redirect(new_url)
        else:
            return self.redirect(new_url)
        return response

    def redirect(self, new_url):
        if new_url == '':
            return http.HttpResponseGone()
        return http.HttpResponsePermanentRedirect(new_url)


class MultipleProxyMiddleware:
    FORWARDED_FOR_FIELDS = [
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_FORWARDED_HOST',
        'HTTP_X_FORWARDED_SERVER',
    ]

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        """
        Rewrites the proxy headers so that only the most
        recent proxy is used.
        """
        for field in self.FORWARDED_FOR_FIELDS:
            if field in request.META:
                if ',' in request.META[field]:
                    parts = request.META[field].split(',')
                    request.META[field] = parts[-1].strip()
        return self.get_response(request)


class P3PHeaderMiddleware(object):
    # Middleware for IE to accept cookies through an iframe

    def process_response(self, request, response):
        P3P_COMPACT = 'policyref="http://www.example.com/p3p.xml", CP="IDC DSP COR ADM DEVi TAIi PSA PSD IVAi IVDi CONi HIS OUR IND CNT"'

        response['P3P'] = P3P_COMPACT
        return response
