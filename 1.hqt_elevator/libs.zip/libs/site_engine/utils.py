import os
import re


from django.apps import apps
from django.conf import settings
from django.db.models import F
from django.shortcuts import get_object_or_404
from django.utils.http import urlencode
from django.template.loaders.app_directories import Loader

from shared_engine.transmeta import get_real_fieldname


def default_site_code():
    u"""
    Returns the code of the last site created as the default value
    for the path of the templates in the Page view.
    """
    try:
        from site_engine.models import Site
        
        if hasattr(settings, 'SITE_CODE'):
            site = Site.objects.get(code=settings.SITE_CODE)
        elif hasattr(settings, 'SITE_ID'):
            site = Site.objects.get(pk=settings.SITE_ID)
        else:
            return None
    except:
        return None
    else:
        return site
   

def build_page_url(site, page, language, return_parent=False, **kwargs):
    u"""
    We generate the url of a page according to the indicated language.
    This method is used for language change. For example, if we are on the page of offers
    in Vietnam and it changes to English, we return the url of this page in English
    """
    
    url = build_domain_url(site, language)
    if not page:
        return url
    
    if return_parent and page.parent and not page.is_home:
        url += page.parent.reverse(language=language)
    else:
        url += page.reverse(language=language, **kwargs)
    return url


def build_domain_url(site, language):
    u"""
    We return the domain of a page according to the indicated language. This method is used for language change.
    """
    prefix = 'https://' if site.is_ssl else 'http://'
    return prefix + getattr(site, 'domain_%s' % language)


def normalize_path(path: str) -> str:
    """
    Normalize path:
    - ensure leading slash
    - remove trailing slash except root
    """
    if path.endswith('/'):
        return path[:-1]
    return path + '/'


def resolve_page(site, path):
    """
    Resolve page from path.
    Returns:
        (page, language, view_args)
    """
    if path is not None and site:
        for reg, pag, lang in site.page_urls:
            regex = re.compile(reg)
            match = regex.match(path)

            if not match:
                match = regex.match(normalize_path(path))

            if match:
                view_kwargs = {}
                pattern = pag.pattern_url(lang)
                if pattern:
                    view_match = re.match(pattern, path)
                    if view_match:
                        view_kwargs = view_match.groupdict()
                return pag, lang, view_kwargs
    return None, None, {}


def resolve_object(page, kwargs):
    if not page.content_type:
        return None

    lookup_value = kwargs.get(page.lookup_field)
    if not lookup_value:
        return None

    try:
        app_label, model_name = page.content_type.split(".", 1)
        model = apps.get_model(app_label, model_name)

        field_names = {f.name for f in model._meta.get_fields()}

        localized_key = get_real_fieldname(page.lookup_field)
        
        normalized_filters = {}
        if localized_key in field_names:
            normalized_filters[localized_key] = lookup_value
        else:
            normalized_filters[page.lookup_field] = lookup_value
        
        queryset = model.objects.all()
        if hasattr(model, "auto_prefetch_related"):
            queryset = queryset.prefetch_related(
                *model.auto_prefetch_related()
            )

        obj = get_object_or_404(queryset, **normalized_filters)
        for attr_name in dir(obj):
            if attr_name.startswith("_auto_load"):
                method = getattr(obj, attr_name)
                if callable(method):
                    method()

        if hasattr(obj, "visited_as"):
            obj.__class__.objects.filter(pk=obj.pk).update(
                visited_as=F("visited_as") + 1
            )
            obj.refresh_from_db(fields=["visited_as"])
        
        return obj
    except Exception as ex:
        if settings.DEBUG:
            raise ex
            # print(f"[E] Wrong resolve_object: {ex}")
    return None


def get_parameters(request, skip=()):
    copy = request.GET.copy()
    for k in skip:
        del copy[k]
    return ("?" + urlencode(copy)) if copy else ""

def delete_file(path):
    try:
        os.remove(path)
    except OSError:
        pass

class AppTemplateExtender(Loader):
    def get_template_sources(self, template_name, template_dirs=None):
        if template_name.startswith("apps:"):
            return super(AppTemplateExtender, self).get_template_sources(template_name[5:], template_dirs)
        return ()
