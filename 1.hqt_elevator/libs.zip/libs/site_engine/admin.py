from django.conf import settings
from django.contrib import admin
from django.utils.html import format_html
from django.utils.translation import gettext_lazy as _

from shared_engine.transmeta import get_real_fieldname as __, get_lable_language as ___
from shared_engine.admin import AdminBase, AdminTabularInline, AdminStackedInline
from site_engine.utils import default_site_code
from site_engine.forms import SiteAdminForm, PageAdminForm
from site_engine.models import (
    Constant,
    Branch,
    License,
    MarketingClaim,
    SocialNetwork,
    OperatingHour,
    MetaObject,
    Form,
    Page,
    Site,
    Redirection,
    Translation,
    Banner,
    Highlight,
    Testimonial,
)


class ConstantAdmin(AdminTabularInline):
    model = Constant


class MarketingClaimAdmin(AdminStackedInline):
    model = MarketingClaim

    fieldsets = [
        [_(u'General'), {
            'fields': ('code', ('sorted_as', 'is_active'),)
        }],
        [_(u'Icon'), {
            'fields': (
                'icon_img',
                ('icon_code', 'icon_name',),
                'icon_svg',
            )
        }],
    ]

    for code, name in settings.LANGUAGES:
        fieldsets.append(
            [___('Content', name), {
                'classes': ('grp-collapse',),
                'fields': model.append_lang_fields(code)
            }]
        )


class SocialNetworkAdmin(AdminStackedInline):
    model = SocialNetwork

    fieldsets = [
        [_(u'General'), {
            'fields': (
                ('name', 'url'),
                ('sorted_as', 'is_active'),
            )
        }],
        [_(u'Icon'), {
            'fields': (
                'icon_img',
                ('icon_code', 'icon_name',),
                'icon_svg',
            )
        }],
    ]

class OperatingHourAdmin(AdminStackedInline):
    model = OperatingHour

    fieldsets = [
        [_(u'General'), {
            'fields': ('weekday', ('since_hour', 'until_hour'),)
        }]
    ]

class BranchAdmin(AdminStackedInline):
    model = Branch

    fieldsets = [
        [_(u'General'), {
            'fields': (
                'logo',
                'email', 'fax',
                ('hotline', 'phone',),
                ('geolat', 'geolng', 'geozm'),
                ('sorted_as', 'is_active', 'is_root',),
            )
        }],
        [_(u'Icon'), {
            'fields': (
                'icon_img',
                ('icon_code', 'icon_name',),
                'icon_svg',
            )
        }],
    ]

    for code, name in settings.LANGUAGES:
        fieldsets.append(
            [___('Content', name), {
                'classes': ('grp-collapse',),
                'fields': model.append_lang_fields(code)
            }]
        )

class LicenseAdmin(AdminStackedInline):
    model = License

    fieldsets = [
        [_(u'General'), {
            'fields': (
                'site',
                'type',
                'number',
                'link',
                'logo',
                'issue_date',
                'renewal_date',
                ('sorted_as', 'is_active',),
            )
        }],
    ]

    for code, name in settings.LANGUAGES:
        fieldsets.append(
            [___('Content', name), {
                'classes': ('grp-collapse',),
                'fields': model.append_lang_fields(code)
            }]
        )


class SiteAdmin(AdminBase):
    form = SiteAdminForm
    list_display = ('code', 'name', 'language', 'domain', 'sitemap_extension', 'is_ssl',)
    search_fields = ['name', 'code',]
    # list_editable = ('is_ssl',)

    inlines = [
        ConstantAdmin,
        BranchAdmin,
        LicenseAdmin,
        OperatingHourAdmin,
        SocialNetworkAdmin,
        MarketingClaimAdmin,
    ]
    fieldsets = [
        [_(u'General'), {
            'fields': [
                'code',
                'name',
                'is_ssl',
                'imageLogo',
                'imageFavicon',
                'image404',
                'language',
                'sitemap_extension',
                'robots_extra',
                'features_flag',
            ]
        }],
        [_(u'Slogan'), {
            'fields': []
        }],
        [_(u'Domains'), {
            'fields': []
        }],
    ]

    for code, name in settings.LANGUAGES:
        fieldsets[1][1]['fields'].append(__('slogan', code))
        fieldsets[2][1]['fields'].append(__('domain', code))

    def get_readonly_fields(self, request, obj=None):
        if obj is None:
            return []
        return ['code',]
admin.site.register(Site, SiteAdmin)


class MetaObjectAdmin(AdminStackedInline):
    model = MetaObject
    fieldsets = [
        [_(u'General'), {
            'fields': [
                'page',
                ('object', 'field', 'value',),
            ]
        }]
    ]
    for code, name in settings.LANGUAGES:
        fieldsets.append(
            (___('Content', name), {
                'fields': MetaObject.append_lang_fields(code)
            })
        )

class FormAdmin(AdminStackedInline):
    model = Form
    fieldsets = [
        [_(u'General'), {
            'fields': (
                'page', 'type',
                'since_date', 'until_date',
                ('sorted_as', 'is_active',),
            )
        }]
    ]

    for code, name in settings.LANGUAGES:
        fieldsets.append(
            (___('Content', name), {
                'fields': Form.append_lang_fields(code)
            })
        )

class PageAdmin(AdminBase):
    form = PageAdminForm
    inlines = [FormAdmin, MetaObjectAdmin]

    list_display = (
        __('name'), 'site', 'parent', 'url', 'is_home', 'is_top_menu', 'is_sub_menu',
        'is_active', 'is_ssl', 'cache_context',
    )
    list_filter = ('site', 'code',)
    list_editable = ('is_active', 'is_ssl', 'cache_context',)
    fieldsets = [
        [_(u'General'), {
            'fields': (
                'site', 'code', 'parent', 'icon', 'is_active', 'is_ssl', 'is_external', 'is_internal',
                ('reversed_as',),
            )
        }],
        [_(u'Menu'), {
            'fields': (
                ('is_top_menu', 'top_menu_col', 'top_menu_row',),
                ('is_sub_menu', 'sub_menu_col', 'sub_menu_row',),
            )
        }],
        [_(u'Type'), {
            'fields': (
                ('is_home', 'is_tac', 'is_ppl',),
            )
        }],
        [_(u'Robots'), {
            'fields': (('is_index', 'is_follow', 'is_archive', 'is_snippet',),)
        }],
        [_(u'Sitemap'), {
            'fields': (('changefreq', 'priority',),)
        }],
        [_(u'Template'), {
            'fields': ('view', 'context', 'cache_context', 'content_type', 'context_name', 'lookup_field',)
        }],
        [_(u'Metadata'), {
            'fields': (
                'meta_type', 'meta_card', 'meta_image', 'meta_schema',
            )
        }],
    ]
    search_fields = ['code',]
    lang_search_fields = ('name', 'url', 'content',)

    for code, name in settings.LANGUAGES:
        fieldsets.append(
            (___('Content', name), {
                'fields': Page.append_lang_fields(code)
            })
        )

        search_fields.extend([
            __((field for field in lang_search_fields), code)
        ])
    
    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        u"""
        We restrict the options of the 'parent' field to the pages of the same site
        """
        if db_field.name == 'parent':
            site_code = request.META.get('CMS_PROJECT_CODE')
            if not site_code:
                site = default_site_code()
                site_code = site.code
            kwargs['queryset'] = Page.objects.filter(
                site__code=site_code).order_by('-parent', __('name'))
        return super(PageAdmin, self).formfield_for_foreignkey(db_field, request, **kwargs)
admin.site.register(Page, PageAdmin)


class TranslationAdmin(AdminBase):
    list_display = ('site', 'page', 'identifier', 'exists',)
    list_filter = ('site', 'page__code', 'exists',)
    search_fields = ['identifier',]
    # readonly_fields = ('site', 'page',)
    lang_search_fields = ('value',)
    list_display_links = ('identifier',)

    fieldsets = [[
        _(u'General'), {
            'fields': ('identifier', 'exists',)
        }],
        [_(u'Content'), {
            'fields': []
        }],
    ]

    for code, name in settings.LANGUAGES:
        fieldsets[1][1]['fields'].append(__('value', code))
admin.site.register(Translation, TranslationAdmin)


class RedirectionAdmin(AdminBase):
    list_display = ('site', 'old_url', 'new_url',)
    search_fields = ('old_url',)
    list_filter = ('site',)
admin.site.register(Redirection, RedirectionAdmin)


class BannerAdmin(AdminBase):
    list_display = (
        'page', 'title_display', 'type', 'site', 'sorted_as', 'since_date', 'until_date',
    )
    # list_editable = ('sorted_as','since_date', 'until_date',)
    fieldsets = [
        [_(u'General'), {
            'fields': (
                'site', 'page', 'type',
                'since_date', 'until_date',
                ('sorted_as', 'is_active',),
            )
        }]
    ]

    for code, name in settings.LANGUAGES:
        fieldsets.append(
            (___('Content', name), {
                'fields': Banner.append_lang_fields(code)
            })
        )
    
    def title_display(self, obj):
        if obj.subtitle:
            return f"{obj.title} {obj.subtitle}"
        return obj.title
    title_display.short_description = _(u'Title')
admin.site.register(Banner, BannerAdmin)


class HighlightAdmin(AdminBase):
    list_display = (
        'label', 'title', 'code', 'site', 'page', 'type', 'is_active', 'sorted_as',
    )
    list_editable = ('is_active', 'sorted_as',)
    list_filter = ('type',)
    fieldsets = [
        [_(u'General'), {
            'fields': (
                'site', 'page', 'type', 'code',
                ('sorted_as', 'is_active',),
            )
        }],
        [_(u'Icon'), {
            'fields': (
                'icon_img',
                ('icon_code', 'icon_name',),
                'icon_svg',
            )
        }],
    ]

    for code, name in settings.LANGUAGES:
        fieldsets.append(
            (___('Content', name), {
                'fields': Highlight.append_lang_fields(code)
            })
        )
admin.site.register(Highlight, HighlightAdmin)


class TestimonialAdmin(AdminBase):
    list_display = ('customer_name', 'site', 'page', 'company_name', 'rating_stars', 'is_active', 'sorted_as')
    list_filter = ('rating', 'is_active', 'created_at')
    readonly_fields = ('created_at', 'updated_at')
    ordering = ('sorted_as', '-is_active', '-created_at')
    
    fieldsets = [
        (_(u'General'), {
            'fields': (
                'site',
                'page',
                ('sorted_as', 'is_active',),
            )}
        ),
        (_(u'Customer'), {
            'fields': (
                'avatar',
                'rating',
            )
        }),
    ]

    for code, name in settings.LANGUAGES:
        fieldsets.append(
            (___('Content', name), {
                'fields': Testimonial.append_lang_fields(code)
            })
        )


    def rating_stars(self, obj):
        stars = '★' * obj.rating + '☆' * (5 - obj.rating)
        return format_html(
            '<span style="color: #FFB81C; font-size: 14px;"><b>{}</b></span>',
            stars
        )
    rating_stars.short_description = _(u'Rating')
admin.site.register(Testimonial, TestimonialAdmin)


from django.contrib.auth.admin import UserAdmin
UserAdmin.filter_horizontal = ('user_permissions', 'groups')
