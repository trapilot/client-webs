from functools import wraps

from django import http
from django.urls import reverse

from site_engine.backoffice import defaults


def check_authorization(request):
    u"""
    Returns a bool indicating whether the user has sufficient authorization
    to access the back office
    """

    if request.user.is_anonymous:
        return False

    if not any(group.name in defaults.GROUP_PERMISSIONS for group in request.user.groups.all()):
        return False

    return True


def has_authorization(method):
    u"""
    Decorator to check that the user is logged in and has sufficient permissions to access the backoffice
    """
    @wraps(method)
    def decorador(request, *args, **kwargs):
        if not check_authorization(request):
            # We prepare the redirection to where the user was going
            r = '?r=' + request.META['PATH_INFO']
            return http.HttpResponseRedirect(reverse('bo_login') + r)
        return method(request, *args, **kwargs)
    return decorador
