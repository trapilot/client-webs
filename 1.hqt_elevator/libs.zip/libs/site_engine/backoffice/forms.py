import xlrd

from django import forms, VERSION
from django.contrib.auth.forms import AuthenticationForm
from django.forms.widgets import CheckboxSelectMultiple
from django.utils.safestring import mark_safe
from django.utils.translation import gettext_lazy as _

from site_engine.defaults import TRANSMETA_LANGUAGES
from site_engine.backoffice import defaults
from site_engine.models import Redirection, Site


__all__ = (
    'LoginForm', 'RedirectionCreateForm', 'RedirectionEditForm',
    'RedirectionRemoveForm', 'RedirectionImportForm', 'TranslationForm',
    'TransferTranslationForm', 'ContentUploadExcelForm',
)
    
DJANGO_NUEVO = VERSION[:2] >= (1, 8)


class LoginForm(AuthenticationForm):
    u"""
    Authentication form
    """

    def clean(self):
        super(LoginForm, self).clean()

        if not self.get_user():
            return self.cleaned_data

        # We must check that the user is inside of groups allowed
        if not any(
            group.name in defaults.GROUP_PERMISSIONS
                for group in self.get_user().groups.all()):
                    raise forms.ValidationError(
                        _(u'This user does not have sufficient permissions to access the cms')
                    )

        return self.cleaned_data


class RedirectionEditForm(forms.ModelForm):
    class Meta:
        model = Redirection
        if DJANGO_NUEVO:
            fields = '__all__'
        widgets = {
            'site': forms.HiddenInput
        }


class RedirectionCreateForm(RedirectionEditForm):
    pass


class RedirectionRemoveForm(forms.Form):
    confirmation = forms.BooleanField(
        label=_(u'Confirmation'),
        help_text=_(u'Check this box to confirm the removal of the redirection'))
    redirection = forms.ModelChoiceField(queryset=Redirection.objects.all(), widget=forms.HiddenInput)


class RedirectionImportForm(forms.Form):
    file = forms.FileField(
        label=_(u'File'),
        help_text=_(u'Select the excel file that contains the '
                u'redirects. Only the two will be taken into account. '
                u'first columns, where the first is the old url and '
                u'the second the new url. The old url is due '
                u'specify without the domain name. For example: '
                u'/content.html . The new url can be specified complete.'),
    )

    def clean_file(self):
        u"""
        We will check that all the urls of the file are correct,
        and that the file format also
        """
        file = self.cleaned_data['file']

        # We check that the file is not .xlsx
        if file.name.endswith('.xlsx'):
            raise forms.ValidationError(_(u'The format must be in .xls format'))

        book = xlrd.open_workbook(file_contents=file.read())
        sheet = book.sheet_by_index(0)

        self.valid_redirections = []

        for lineno in range(sheet.nrows):
            contents = sheet.row_values(lineno)

            # If we don't have two columns of information, it's useless.
            if content[0] == '' or content[1] == '':
                raise forms.ValidationError(
                    _(u'Error on line %d. Does not contain the old url or the new url.') % (lineno+1))

            # In column 1, we must always have an http://
            if not 'http://' in contents[1]:
                raise forms.ValidationError(
                    _(u'Error on line %d. The destination url does not start with http://') % (lineno+1))

            self.valid_redirections.append(content)

        return self.valid_redirections


class TranslationForm(forms.Form):
    u"""
    We generate the form to edit the translations in
    a single list window
    """

    def __init__(self, queryset, active_language, *args, **kwargs):
        super(TranslationForm, self).__init__(*args, **kwargs)

        self.translations = {}
        for translation in queryset:
            field = forms.CharField(
                label=translation.identifier,
                widget=forms.Textarea(attrs={'rows': '1'}),
                initial=getattr(translation, 'value_%s' % active_language),
                required=False)
            field.id_trad = translation.id

            self.fields['translation_%d' % translation.id] = field
            self.translations['translation_%d' % translation.id] = translation

    def save(self, language_code):
        cleaned_data = self.cleaned_data

        for k, v in cleaned_data.items():
            setattr(self.translations[k], 'value_' + language_code, v)
            self.translations[k].save()


class TransferTranslationForm(forms.Form):
    sites = forms.MultipleChoiceField(widget=CheckboxSelectMultiple)

    def __init__(self, site_actual, *args, **kwargs):
        super(TransferTranslationForm, self).__init__(*args, **kwargs)

        sites = []
        self.sites = {}
        for site in Site.objects.all():
            if site != site_actual:
                name = mark_safe(
                    u'%s (<b>%s</b>)' % (site.name, site.code))
                sites.append((site.code, name))
                self.sites[site.code] = site
        self.fields['sites'].choices = sites

    def clean_sites(self):
        sites = []
        for site in self.cleaned_data['sites']:
            try:
                sites.append(self.sites[site])
            except KeyError:
                continue
        return sites


class SeoForm(forms.Form):
    title = forms.CharField(label=_(u'Title'))
    description = forms.CharField(label=_(u'Description'))
    keywords = forms.CharField(label=_(u'Keywords'))
    content = forms.CharField(label=_(u'Content'), widget=forms.Textarea())
    h1 = forms.CharField(label=_(u'H1'))
    h2 = forms.CharField(label=_(u'H2'))
    h3 = forms.CharField(label=_(u'H3'))


class UploadSeoRulesForm(forms.Form):

    file = forms.FileField(label=_(u'File'))

    MAPPING_LANGUAGE_LIST = [code for code, name in TRANSMETA_LANGUAGES]

    def clean_file(self):
        u"""
        We check that the excel is valid and return a dictionary with all the information
        """

        file = self.cleaned_data['file']

        # We check that the file is not .xlsx
        if file.name.endswith('.xlsx'):
            raise forms.ValidationError(_(u'The format must be in .xls format'))

        rules = {}
        book = xlrd.open_workbook(file_contents=file.read())

        for sheet in book.sheets():
            rules[sheet.name] = {}

            for row in range(1, sheet.nrows):
                for col in range(0, sheet.ncols):
                    cell = sheet.cell(row, col)

                    if col == 0:
                        clave = cell.value
                        rules[sheet.name][clave] = {}
                    else:
                        rules[sheet.name][clave][self.MAPPING_LANGUAGE_LIST[col-1]] = cell.value

        return rules


class ContentUploadExcelForm(forms.Form):

    hotel = forms.ChoiceField(label=_(u'Hotel'))
    file = forms.FileField(label=_(u'File'))

    def __init__(self, user, *args, **kwargs):
        super(ContentUploadExcelForm, self).__init__(*args, **kwargs)

        items = [('', '----')]
        self.hotel_list = {}

        for group in user.groups.all():
            if hasattr(group, 'grupohotelesadmin_set'):
                for grouphotels in group.grupohotelesadmin_set.all():

                    chain = grouphotels.chain
                    if chain:
                        hotels = []
                        for hotel in chain.hotel_set.all():
                            hotels.append((hotel.code, hotel.name))
                            self.hotel_list[hotel.code] = hotel

                        items.append(
                            ('%s - %s' % (
                                group, chain.name.lower()), hotels))
                    else:
                        hotels = []
                        for hotel in grouphotels.hotels.all():
                            hotels.append((hotel.code, hotel.name))
                            self.hotel_list[hotel.code] = hotel
                        items.append((group, hotels))

        self.fields['hotel'].choices = items

    def clean_hotel(self):
        return self.hotel_list[self.cleaned_data['hotel']]

    def clean_file(self):
        u"""
        We check that the file is correct. In such a case, we return
        a dictionary with all the necessary information. If not, we expel
        a ValidationError
        """

        file = self.cleaned_data['file']

        # We check that the file is not .xlsx
        if file.name.endswith('.xlsx'):
            raise forms.ValidationError(_(u'The format must be in .xls format'))

        book = xlrd.open_workbook(file_contents=file.read())
        result = {}

        # Basic data
        sheet = book.sheet_by_index(0)
        result['data'] = {
            'name': [],
            'description': []
        }

        for nc in range(1, sheet.ncols):
            name = sheet.cell(2, nc).value
            lang = sheet.cell(1, nc).value
            description = sheet.cell(6, nc).value

            result['data']['name'].append({
                'lang': lang,
                'name': name
            })

            result['data']['description'].append({
                'lang': lang,
                'description': description
            })

        result['data']['address'] = sheet.cell(3, 1).value
        result['data']['category'] = sheet.cell(4, 1).value.split('@')[0]
        result['data']['coordinates'] = {
            'longitud': float(sheet.cell(5, 1).value),
            'latitud': float(sheet.cell(5, 3).value)
        }

        # Contact information
        sheet = book.sheet_by_index(1)
        result['contact'] = []

        for nr in range(2, sheet.nrows):
            data = {
                'code': sheet.cell(nr, 0).value,
                'value': str(sheet.cell(nr, 1).value),
                'description': []
            }

            for nc in range(2, sheet.ncols):
                data['description'].append({
                    'lang': sheet.cell(1, nc).value,
                    'description': sheet.cell(nr, nc).value
                })

            result['contact'].append(data)

        # Social networks
        sheet = book.sheet_by_index(2)
        result['networks'] = []

        for nr in range(2, sheet.nrows):
            result['networks'].append({
                'code': sheet.cell(nr, 0).value.split('@')[0],
                'url': sheet.cell(nr, 1).value
            })

        # Puntos de interés
        sheet = book.sheet_by_index(3)
        result['interest_points'] = []

        for nr in range(2, sheet.nrows):
            datos = {
                'longitud': float(sheet.cell(nr, 0).value),
                'latitud': float(sheet.cell(nr, 1).value),
                'name': []
            }

            for nc in range(2, sheet.ncols):
                datos['name'].append({
                    'idioma': sheet.cell(1, nc).value,
                    'name': sheet.cell(nr, nc).value
                })
            result['interest_points'].append(datos)

        # Services
        sheet = book.sheet_by_index(4)
        result['services'] = []

        for nr in range(2, sheet.nrows):
            result['services'].append(sheet.cell(nr, 0).value.split('@')[0])

        return result
