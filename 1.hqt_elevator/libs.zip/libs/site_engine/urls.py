from django.conf import settings
from django.urls import include, path, re_path

from site_engine.backoffice import urls as backoffice_urls
from site_engine.robots import RobotsView
from site_engine.sitemap import SitemapView
from site_engine.views import view_dispatcher, CmsStaticView, ExternalRequestView

urlpatterns = [
    path('sitemap.xml', SitemapView.as_view()),
    path('robots.txt', RobotsView.as_view()),
    path('cms-view/', include(backoffice_urls)),
    path('cms-external-rq', ExternalRequestView.as_view(), name='cms_external'),
    re_path(r'cms-static/(?P<type>(css|js|less))/', CmsStaticView.as_view(), name='cms_static'),
]

if settings.SITE_DEBUG:
    urlpatterns += [re_path(r"^__debug__/", include("debug_toolbar.urls"))]
urlpatterns += [re_path(r"^(?!(landing|lp|api|form|forms)/)(?P<path>.*)$", view_dispatcher)]