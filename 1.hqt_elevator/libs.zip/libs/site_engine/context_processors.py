from django.conf import settings

from site_engine.backoffice import defaults
from shared_engine.utils import urls
from site_engine.defaults import CURRENT_LANGUAGE, LANGUAGE_REGIONS

def session(request):
    u"""
    The site can be accessed in the templates via
    request.session.site, but for reasons of comfort, better pass site.
    """
    
    context = {
        'site' : getattr(request, 'site', None),
        'page' : getattr(request, 'page', None),
        'http_lang' : getattr(request, 'lang', CURRENT_LANGUAGE),
        'http_host' : getattr(request, 'host', None),
        'language_pages': None,
        'language_domains': None,
        'REGION_CODE': LANGUAGE_REGIONS[CURRENT_LANGUAGE],
        'LANGUAGE_CODE': CURRENT_LANGUAGE,
    }

    # Another useful thing that we are going to pass in the templates
    # is the HTTP_REQUEST, with the http:// in front. If we are in
    # safe mode, we put https.
    try:
        parser = urls.parse(request)
        context['http_host'] = parser['http_host'] or parser['http_server']
    except:
        pass
    
    try:
        if len(settings.LANGUAGES) > 1:
            site = context['site']
            page = context['page']
            
            lang_codes = []
            for code, _name in settings.LANGUAGES:
                lang_codes.append(code)

            lang_pages = { lang: getattr(page, 'url_%s' % lang) for lang in lang_codes if getattr(page, 'url_%s' % lang) and not page.is_internal }
            lang_domains = { lang: getattr(site, 'domain_%s' % lang) for lang in lang_codes if getattr(site, 'domain_%s' % lang) }
            
            context['language_pages'] = lang_pages
            context['language_domains'] = lang_domains
    except Exception:
        pass
    return context


def backoffice(request):
    u"""
    Context for administration. We only charge it when
    """
    context = {}
    if '/cms-view/' in getattr(request.META, 'REQUEST_URI', request.META['PATH_INFO']):

        if 'cms_superuser' in [g.name for g in request.user.groups.all()]:
            request.user.cms_superuser = True

        context = {
            'copyright' : defaults.COPYRIGHT,
            'version' : defaults.VERSION,
            'option_menus' : option_menus()
        }

    return context


def option_menus():
    u"""
    We check which applications have a back office and which menu options we should add in the cms navigation
    """
    options = {}

    for app in settings.INSTALLED_APPS:
        try:
            backapp = __import__(
                "%s.backoffice" % app, fromlist=['backoffice'])
        except ImportError:
            continue

        options = dict(options.items() | getattr(backapp, 'OPTION_MENUS', {}).items())

    return options
