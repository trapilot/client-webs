from django.apps import AppConfig
from django.utils.translation import gettext_lazy as _

class RecruitmentEngineConfig(AppConfig):
    name = 'recruitment_engine'
    verbose_name = _(u'Recruitment')