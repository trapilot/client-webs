from django.conf import settings
from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from django.utils.html import format_html

from shared_engine.admin import AdminBase, AdminFileExtraMixin, AdminReadOnlyMixin
from shared_engine.transmeta import get_real_fieldname as __, get_lable_language as ___
from recruitment_engine.models import (
    Department,
    Applicant,
    Job,
)

class DepartmentAdmin(AdminBase):
    list_display = ('title', 'branch', 'project', 'sorted_as', 'is_active',)

    fieldsets = [
        [_(u'General'), {
            'fields': (
                ('branch', 'project',),
                'code',
                'email',
                'phone',
                ('sorted_as', 'is_active',),
            )
        }]
    ]

    for code, name in settings.LANGUAGES:
        fieldsets.append(
            (___('Content', name), {
                'fields': Department.append_lang_fields(code)
            })
        )
admin.site.register(Department, DepartmentAdmin)


class JobAdmin(AdminFileExtraMixin, AdminBase):
    list_display = ('title', 'branch', 'department', 'file_link', 'published_from', 'published_to', 'sorted_as', 'is_active',)

    fieldsets = [
        [_(u'General'), {
            'fields': (
                'branch',
                'department',
                'type',
                'mode',
                'file',
                ('sorted_as', 'is_active',),
                ('published_from', 'published_to',),
            )
        }]
    ]

    for code, name in settings.LANGUAGES:
        fieldsets.append(
            (___('Content', name), {
                'fields': Job.append_lang_fields(code)
            })
        )
    
    def file_link(self, obj):
        if obj.file:
            return format_html('<a href="{}" download>📄 {}</a>', obj.file.url, obj.file.name.split('/')[-1])
        return '-'
    file_link.short_description = 'File'
admin.site.register(Job, JobAdmin)


class ApplicantAdmin(AdminFileExtraMixin, AdminReadOnlyMixin, AdminBase):
    list_display = ('name', 'email', 'phone', 'referer', 'job', 'file_link', 'created_at')

    fieldsets = [
        [_(u'General'), {
            'fields': (
                'job', 'email', 'phone', 'name', 'referer', 'file_link', 'message',
            )
        }]
    ]
    
    def file_link(self, obj):
        if obj.file:
            return format_html('<a href="{}" download>📄 {}</a>', obj.file.url, obj.file.name.split('/')[-1])
        return '-'
    file_link.short_description = 'CV'
admin.site.register(Applicant, ApplicantAdmin)
