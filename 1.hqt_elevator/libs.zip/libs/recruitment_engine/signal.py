from django.db.models.signals import post_delete
from django.dispatch import receiver

from cms_engine.utils import delete_file
from recruitment_engine.models import Applicant, Job


@receiver(post_delete, sender=Applicant)
def post_delete_file(sender, instance=None, **kwargs):
    if instance.file:
        delete_file(instance.file.path)


@receiver(post_delete, sender=Job)
def post_delete_file(sender, instance=None, **kwargs):
    if instance.file:
        delete_file(instance.file.path)