from django import forms
from django.core.validators import validate_email
from django.utils.translation import gettext_lazy as _

from recruitment_engine.models import Applicant


class JobApplicationForm(forms.ModelForm):
    job_id = forms.IntegerField(widget=forms.HiddenInput())

    class Meta:
        model = Applicant
        fields = ['name', 'email', 'phone', 'referer', 'file', 'message']

    def clean_file(self):
        cv = self.cleaned_data.get('file')
        if cv:
            ext = cv.name.split('.')[-1].lower()
            valid_extensions = ['pdf', 'doc', 'docx']
            if ext not in valid_extensions:
                raise forms.ValidationError(_(u'Only PDF, DOC, or DOCX files are accepted'))           
            max_size = 5 * 1024 * 1024 # 5M
            if cv.size > max_size:
                raise forms.ValidationError(_(u'The file size has exceeded the 5MB limit'))
        return cv
    
    def clean_email(self):
        email = self.cleaned_data['email']
        try:
            validate_email(email)
        except (forms.ValidationError, UnicodeDecodeError):
            raise forms.ValidationError(_(u'The email entered is not valid'))
        return email