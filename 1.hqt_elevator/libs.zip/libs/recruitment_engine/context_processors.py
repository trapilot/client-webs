from django import http
from django.conf import settings

from recruitment_engine.models import Branch


def recruitment(request):
    context = {
        'branches': None,
    }

    site = getattr(request, 'site', None)
    if site:
        branches = Branch.objects.filter(site=site)
        context = {
            'branches': branches,
        }
    
    return context
