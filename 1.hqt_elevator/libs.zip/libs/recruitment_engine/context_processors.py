from django import http
from django.conf import settings

from recruitment_engine.models import Branch


def recruitment(request):
    context = {
        'branches': None,
    }

    project = getattr(request, 'project', None)
    if project:
        branches = Branch.objects.filter(project=project)
        context = {
            'branches': branches,
        }
    
    return context
