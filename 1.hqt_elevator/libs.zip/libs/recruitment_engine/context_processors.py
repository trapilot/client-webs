from recruitment_engine.models import Branch


def recruitment(request):
    context = {
        'branches': None,
    }

    site = getattr(request, 'site', None)
    if site:
        context['branches'] = Branch.objects.is_activated(site=site)
    
    return context
