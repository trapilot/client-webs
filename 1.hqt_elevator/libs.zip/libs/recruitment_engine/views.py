from django.shortcuts import redirect, get_object_or_404
from django.contrib import messages
from django.views.decorators.http import require_POST
from django.utils.translation import gettext_lazy as _

from recruitment_engine.models import Job
from recruitment_engine.forms import JobApplicationForm

@require_POST
def submit_application(request):
    """
    The endpoint URL corresponds to 'submit_application_url' in the HTML action.
    """
    form = JobApplicationForm(request.POST, request.FILES)
    
    if form.is_valid():
        job_id = form.cleaned_data.get('job_id')
        job_instance = get_object_or_404(Job, id=job_id)
        
        application = form.save(commit=False)
        
        application.job = job_instance
        application.save()
        
        messages.success(request, _(u'Your application has been submitted successfully! Our HR team will contact you soon'))
        
    else:
        for field, errors in form.errors.items():
            for error in errors:
                messages.error(request, f"{_(u'Error')}: {field} {error}")

    return redirect(request.META.get('HTTP_REFERER'))