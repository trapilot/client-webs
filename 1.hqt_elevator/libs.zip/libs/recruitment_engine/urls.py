from django.urls import path
from recruitment_engine import views

urlpatterns = [
    path('submit-application/', views.submit_application, name='submit_application'),
]
