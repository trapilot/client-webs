from django.db import models
from django.utils.translation import gettext_lazy as _

from cms_engine.models import Project, Branch
from cms_engine.utils import default_project_code
from shared_engine.transmeta import TransMeta
from shared_engine.managers import GeneralManager

from smart_selects.db_fields import ChainedForeignKey
from ckeditor.fields import RichTextField
       

class Department(models.Model, metaclass=TransMeta):
    objects = GeneralManager()
    
    project = models.ForeignKey(
        Project,
        on_delete=models.CASCADE,
        default=default_project_code(),
        related_name='department_set',
        verbose_name=_(u'Project'),
    )
    branch = ChainedForeignKey(
        Branch,
        on_delete=models.CASCADE,
        related_name='branch_set',
        chained_field='project',
        chained_model_field='project',
        verbose_name=_(u'Branch'),
        show_all=False,
        auto_choose=False,
        blank=True,
        null=True,
    )
    code = models.CharField(_(u'Code'), max_length=50, unique=True)
    title = models.CharField(_(u'Name'), max_length=150, blank=True, null=True, default='')
    summary = models.CharField(_(u'Summary'), max_length=250, blank=True, null=True)
    description = models.TextField(_(u'Description'), blank=True, null=True)
    email = models.CharField(_(u'Email'), max_length=100, null=True, blank=True)
    phone = models.CharField(_(u'Phone'), blank=True, null=True, max_length=30)
    
    sorted_as = models.PositiveIntegerField(_(u'Order'), default=0)
    is_active = models.BooleanField(_(u'Active'), default=True)
    
    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)
    
    class Meta:
        verbose_name = _(u'Department')
        verbose_name_plural = _(u'Departments')
        translate = ('title', 'summary', 'description',)
        ordering = ('sorted_as', '-is_active',)

    def __str__(self):
        return self.title


class Job(models.Model, metaclass=TransMeta):
    class EmploymentType(models.TextChoices):
        FULL_TIME = 'full_time', _('Full time')
        PART_TIME = 'part_time', _('Part time')
        CONTRACT = 'contract', _('Contract')
        FREELANCE = 'freelance', _('Freelance')
        INTERNSHIP = 'internship', _('Internship')
        TEMPORARY = 'temporary', _('Temporary')


    class WorkMode(models.TextChoices):
        ONSITE = 'onsite', _('Onsite')
        REMOTE = 'remote', _('Remote')
        HYBRID = 'hybrid', _('Hybrid')

    objects = GeneralManager()
    branch = models.ForeignKey(
        Branch,
        on_delete=models.CASCADE,
        related_name='job_set',
        verbose_name=_(u'Branch'),
    )
    department = ChainedForeignKey(
        Department,
        on_delete=models.CASCADE,
        related_name='department_set',
        chained_field='branch',
        chained_model_field='branch',
        verbose_name=_(u'Department'),
        show_all=False,
        auto_choose=False,
    )
    type = models.CharField(_(u'Job Type'), max_length=20, choices=EmploymentType.choices, default=EmploymentType.FULL_TIME)
    mode = models.CharField(_(u'Job Mode'), max_length=20, choices=WorkMode.choices, default=WorkMode.ONSITE)
    title = models.CharField(_(u'Name'), max_length=150)
    salary = models.CharField(_(u'Salary'), blank=True, null=True, max_length=250)
    address = models.CharField(_(u'Address'), blank=True, null=True, max_length=250)
    summary = models.CharField(_(u'Summary'), max_length=250, blank=True, null=True)
    description = models.TextField(_(u'Description'), blank=True, null=True)
    requirement = RichTextField(_(u'Requirement'), blank=True, null=True)
    benefit = RichTextField(_(u'Benefit'), blank=True, null=True)
    file = models.FileField(_(u'File'), null=True, blank=True, upload_to='uploads/recruitment/jobs')
    
    published_from = models.DateTimeField(u'Available From', null=True, blank=True)
    published_to = models.DateTimeField(u'Available To', null=True, blank=True)
    
    sorted_as = models.PositiveIntegerField(_(u'Order'), default=0)
    is_active = models.BooleanField(_(u'Active'), default=True)
    
    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Job')
        verbose_name_plural = _(u'Jobs')
        translate = ('title', 'address', 'salary', 'summary', 'description', 'requirement', 'benefit',)
        ordering = ('sorted_as', '-is_active', '-created_at',)

    def __str__(self):
        return self.title
    
    @property
    def type_display(self):
        return _(self.get_type_display()) if self.type else ''
    
    @property
    def mode_display(self):
        return _(self.get_mode_display()) if self.mode else ''
    
    @property
    def address_display(self):
        if self.address:
            return self.address
        if self.department and self.department.branch:
            return self.department.branch.address
        return ''
    
    @property
    def address_raw(self):
        if self.address:
            return self.address
        return ''


class Applicant(models.Model):
    job = models.ForeignKey(
        Job,
        on_delete=models.CASCADE,
        related_name='applicant_set',
        verbose_name=_(u'Job'),
    )
    name = models.CharField(_(u'Name'), max_length=100)
    phone = models.CharField(_(u'Phone'), max_length=100)
    email = models.CharField(_(u'Email'), max_length=100)
    referer = models.TextField(_(u'Referer'), blank=True, null=True)
    file = models.FileField(_(u'Curriculum Vitae'), upload_to='uploads/recruitment/applicants')
    message = models.TextField(_(u'Message'), null=True, blank=True)
    
    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Applicant')
        verbose_name_plural = _(u'Applicants')

    def __str__(self):
        return '[%s] %s' % (self.job, self.name)


from recruitment_engine.signal import *