import datetime
from django.core.exceptions import ObjectDoesNotExist
from django.db import models
from django.db.models import Q
from django.utils import translation


class GeneralManager(models.Manager):
    def is_activated(self, **kwargs):
        return self.filter(is_active=True, **kwargs)


class ArticleManager(models.Manager):
    def is_activated(self, **kwargs):
        now = datetime.datetime.now()
        return self.filter(is_active=True, **kwargs).exclude(published_at__gt=now)
        

class BackgroundManager(models.Manager):
    def is_activated(self, **kwargs):
        return self.filter(is_active=True, **kwargs)

    def is_activated_from_now(self, **kwargs):
        now = datetime.datetime.now()
        return self.filter(is_active=True, **kwargs).exclude(
                                Q(published_at__isnull=False) &
                                Q(published_at__gt=now)).exclude(
                                Q(unpublished_at__isnull=False) &
                                Q(unpublished_at__lte=now))


class PopupManager(models.Manager):
    def is_activated(self, **kwargs):
        lang = translation.get_language()
        kwargs = {'is_active_%s' % lang : True}
        return self.filter(**kwargs)
