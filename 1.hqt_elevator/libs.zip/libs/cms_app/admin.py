# -*- coding: utf-8 -*-
from django import forms
from django.conf import settings
from django.contrib import admin
from django.core.exceptions import ValidationError
from django.utils import translation
from django.utils.html import format_html
from django.utils.translation import get_language, gettext_lazy as _, gettext

from sorl.thumbnail import get_thumbnail
from sorl.thumbnail.admin import AdminImageMixin

from cms_app.models import (
    Article, Tag, Category,
    Inquiry,
    FAQ, FAQAnswer,
)
from shared_engine.admin import (
    AdminBase,
    AdminImageMixin,
    AdminTagMixin,
    AdminCategoryMixin,
    AdminImageMixin,
    AdminTabularInline,
    AdminStackedInline,
    AdminReadOnlyMixin,
)
from shared_engine.forms import AdminImageRequireForm, AdminImageOptionalForm, AdminFileRequireForm
from shared_engine.transmeta import get_real_fieldname as __, get_lable_language as ___


class CategoryAdmin(AdminBase):
    list_display = (__('name'), 'code', 'site', 'is_featured', 'is_active', 'sorted_as',)
    list_editable = ('is_featured', 'is_active', 'sorted_as',)
    fieldsets = [
        [_(u'General'), {
            'fields': (
                'site', 'code', 'parent', 'page',
                'icon', 'image',
                ('color_bg', 'color_text',),
                ('sorted_as', 'is_active', 'is_featured',),
            )
        }]
    ]

    for code, name in settings.LANGUAGES:
        fieldsets.append(
            (___('Content', name), {
                'fields': Category.append_lang_fields(code)
            })
        )
admin.site.register(Category, CategoryAdmin)


class TagAdmin(AdminBase):
    list_display = ('code', __('name'), 'site', 'sorted_as', 'is_active')
    fieldsets = [
        [_(u'General'), {
            'fields': (
                'site', 'code', 'icon',
                ('sorted_as', 'is_active',),
            )
        }]
    ]

    for code, name in settings.LANGUAGES:
        fieldsets.append(
            (___('Content', name), {
                'fields': Tag.append_lang_fields(code)
            })
        )
admin.site.register(Tag, TagAdmin)


class ArticleAdmin(AdminTagMixin, AdminCategoryMixin, AdminBase):
    list_display = ('title', 'site', 'author', 'category', 'tag', 'is_active', 'published_at', 'sorted_as',)
    list_display_links = ('title',)
    list_editable = ('is_active', 'published_at', 'sorted_as',)
    list_filter = ('is_active',)
    search_fields = ['author',]
    lang_search_fields = ('title', 'summary', 'content',)
    preserve_filters = True

    for code, name in settings.LANGUAGES:
        search_fields.extend([
            __((field for field in lang_search_fields), code)
        ])

    fieldsets = [
        [_(u'General'), {
            'fields': (
                'site',
                ('categories', 'tags',),
                'image', 'icon',
                ('published_at',),
                ('author', 'sorted_as', 'visited_as',),
                ('is_active',),
            )
        }]
    ]

    prepopulated_fields = {}
    for code, name in settings.LANGUAGES:
        prepopulated_fields[__('slug', code)] = (__('title', code),)
        fieldsets.append(
            (___('Content', name), {
                'fields': Article.append_lang_fields(code)
            })
        )
admin.site.register(Article, ArticleAdmin)

@admin.register(Inquiry)
class InquiryAdmin(admin.ModelAdmin):
    list_display = ('subject', 'site', 'name', 'email', 'address', 'phone', 'status', 'created_at')
    list_filter = ('email', 'created_at')
    search_fields = ('email', 'name', 'phone',)
    readonly_fields = ('email', 'site', 'name', 'phone', 'address', 'subject_link', 'comment', 'created_at',)

    fieldsets = [
        (_(u'General'), {
            'fields': (
                'site',
                'name',
                'email',
                'phone',
                'address',
                'subject_link',
                'comment',
                ('status', 'note',),
            )}
        )
    ]

    def subject_link(self, obj):
        if obj.subject and (
            obj.subject.startswith('http://') or
            obj.subject.startswith('https://')
        ):
            return format_html(
                '<a href="{}" target="_blank">{}</a>',
                obj.subject,
                obj.subject,
            )
        return obj.subject or '-'
    subject_link.short_description = _(u'Subject')


# class FAQAnswerAdmin(AdminStackedInline):
#     model = FAQAnswer
#     extra = 1
#     fields = ['sorted_as']

#     for code, name in settings.LANGUAGES:
#         fields += FAQAnswer.append_lang_fields(code)

# class FAQAdmin(AdminBase):
#     inlines = [FAQAnswerAdmin]

#     list_display = (___('question'), 'site', 'category', 'is_active', 'visited_as', 'sorted_as')
#     list_filter = ('is_active', 'category', 'created_at')
#     readonly_fields = ('visited_as', 'created_at', 'updated_at')
#     ordering = ('sorted_as', '-visited_as')
    
#     fieldsets = [
#         (_(u'General'), {
#             'fields': (
#                 'site',
#                 'category',
#                 'is_active',
#                 'sorted_as',
#                 'visited_as',
#             )
#         }),
#     ]


#     for code, name in settings.LANGUAGES:
#         fieldsets.append(
#             (___('Content', name), {
#                 'fields': FAQ.append_lang_fields(code)
#             })
#         )

#     def question_short(self, obj):
#         lang = get_language()
#         question = getattr(obj, f'question_{lang}', '') or ''
#         return question[:80] + '...' if len(question) > 80 else question
#     question_short.short_description = _(u'Question')
# admin.site.register(FAQ, FAQAdmin)

