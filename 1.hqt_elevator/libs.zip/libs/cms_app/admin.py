# -*- coding: utf-8 -*-
from django import forms
from django.conf import settings
from django.contrib import admin
from django.core.exceptions import ValidationError
from django.utils import translation
from django.utils.html import format_html
from django.utils.translation import get_language, gettext_lazy as _, gettext

from sorl.thumbnail import get_thumbnail
from sorl.thumbnail.admin import AdminImageMixin

from cms_app.models import (
    Background, InnerBackground, Popup,
    Article, Tag, Category,
    Testimonial,
    Partner,
    Newsletter,
    FAQ, FAQAnswer,
)
from shared_engine.admin import (
    AdminBase,
    AdminImageMixin,
    AdminTagMixin,
    AdminCategoryMixin,
    AdminImageMixin,
    AdminTabularInline,
    AdminStackedInline,
)
from shared_engine.forms import AdminImageForm, AdminImageExtraForm, AdminArchiveForm
from shared_engine.transmeta import get_real_fieldname as __, get_lable_language as ___


class CategoryAdmin(AdminBase):
    list_display = ('code', 'project', 'sorted_as', 'is_active', 'is_featured',)
    fieldsets = [
        [_(u'General'), {
            'fields': (
                'project', 'code', 'parent', 'page',
                'icon', 'image',
                ('sorted_as', 'is_active', 'is_featured',),
            )
        }]
    ]

    for code, name in settings.LANGUAGES:
        fieldsets.append(
            (___('Content', name), {
                'fields': Category.append_lang_fields(code)
            })
        )
admin.site.register(Category, CategoryAdmin)


class TagAdmin(AdminBase):
    list_display = ('code', __('name'), 'project', 'sorted_as', 'is_active')
    fieldsets = [
        [_(u'General'), {
            'fields': (
                'project', 'code', 'icon',
                ('sorted_as', 'is_active',),
            )
        }]
    ]

    for code, name in settings.LANGUAGES:
        fieldsets.append(
            (___('Content', name), {
                'fields': Tag.append_lang_fields(code)
            })
        )
admin.site.register(Tag, TagAdmin)


class ArticleAdmin(AdminTagMixin, AdminCategoryMixin, AdminBase):
    list_display = ('title', 'project', 'author', 'category', 'tag', 'published_at', 'sorted_as', 'is_active',)
    list_display_links = ('title',)
    list_editable = ('published_at', 'sorted_as', 'is_active',)
    list_filter = ('is_active',)
    search_fields = ['author',]
    lang_search_fields = ('title', 'summary', 'content',)
    preserve_filters = True

    for code, name in settings.LANGUAGES:
        search_fields.extend([
            __((field for field in lang_search_fields), code)
        ])

    fieldsets = [
        [_(u'General'), {
            'fields': (
                'project',
                ('categories', 'tags',),
                'image', 'icon',
                ('published_at', 'author',),
                ('sorted_as', 'is_active',),
            )
        }]
    ]

    prepopulated_fields = {}
    for code, name in settings.LANGUAGES:
        prepopulated_fields[__('slug', code)] = (__('title', code),)
        fieldsets.append(
            (___('Content', name), {
                'fields': Article.append_lang_fields(code)
            })
        )
admin.site.register(Article, ArticleAdmin)


class BackgroundAdmin(AdminImageMixin, AdminBase):
    list_display = (
        'title', 'thumbnail', 'project', 'page',
        'offer_code', 'sorted_as', 'is_active','published_from', 'published_to',
    )
    list_display_links = ('title',)
    list_editable = ('project', 'sorted_as', 'is_active','published_from', 'published_to',)
    list_filter = ('project', 'is_active',)
    search_fields = ['page', 'offer_code',]
    lang_search_fields = ('title',)
    fieldsets = [
        [_(u'General'), {
            'fields': (
                'project', 'page', 'offer_code',
                ('sorted_as', 'is_active',),
                ('published_from', 'published_to',),
            )
        }]
    ]

    for code, name in settings.LANGUAGES:
        search_fields.extend([
            __((field for field in lang_search_fields), code)
        ])

        fieldsets.append(
            (___('Content', name), {
                'fields': Background.append_lang_fields(code)
            })
        )
admin.site.register(Background, BackgroundAdmin)


class InnerBackgroundAdmin(AdminImageMixin, AdminBase):
    list_display = ('title', 'thumbnail', 'project', 'page', 'sorted_as', 'is_active',)
    list_display_links = ('title', 'thumbnail',)
    list_editable = ('sorted_as', 'is_active',)
    list_filter = ('page', 'is_active',)
    search_fields = []
    lang_search_fields = ('title',)
    fieldsets = [
        [_(u'General'), {
            'fields': (
                'project', 'page',
                ('sorted_as', 'is_active',),
            )
        }]
    ]

    for code, name in settings.LANGUAGES:
        search_fields.extend([
            __((field for field in lang_search_fields), code)
        ])

        fieldsets.append(
            (___('Content', name), {
                'fields': InnerBackground.append_lang_fields(code)
            })
        )
admin.site.register(InnerBackground, InnerBackgroundAdmin)


class PopupAdmin(AdminBase):
    list_display = ('is_active', 'is_newsletter', 'page', 'pk',)
    list_display_links = ('pk',)
    list_editable = ()
    list_filter = ('page',)
    fieldsets = [
        (_(u'General'), {
            'fields': (
                ('project', 'page'),
                'image_background',
                'is_newsletter',
                'is_active',
                ('published_from', 'published_to'),
            )}
        )
    ]

    for code, name in settings.LANGUAGES:
        fieldsets.append(
            (___('Content', name), {
                'fields': Popup.append_lang_fields(code)
            })
        )
admin.site.register(Popup, PopupAdmin)


class TestimonialAdmin(AdminBase):
    list_display = ('customer_name', 'project', 'rating_stars', 'is_featured', 'sorted_as', 'is_active')
    list_filter = ('rating', 'is_featured', 'is_active', 'created_at')
    search_fields = ('customer_name', 'content')
    readonly_fields = ('created_at', 'updated_at')
    ordering = ('sorted_as', '-created_at')
    
    fieldsets = [
        (_(u'General'), {
            'fields': (
                ('project'),
                'is_featured',
                'is_active',
                'sorted_as',
            )}
        ),
        (_(u'Customer'), {
            'fields': (
                'customer_name',
                'customer_title',
                'customer_image',
                'rating',
                'content',
            )
        }),
    ]


    def rating_stars(self, obj):
        stars = '★' * obj.rating + '☆' * (5 - obj.rating)
        return format_html(
            '<span style="color: #FFB81C; font-size: 14px;"><b>{}</b></span>',
            stars
        )
    rating_stars.short_description = _(u'Rating')
admin.site.register(Testimonial, TestimonialAdmin)


class PartnerAdmin(AdminBase):
    list_display = ('name', 'project', 'logo_thumbnail', 'website_link', 'is_active', 'is_featured', 'sorted_as')
    list_filter = ('is_active', 'created_at')
    search_fields = ('name', 'website')
    ordering = ('sorted_as', 'name')
    
    fieldsets = [
        (_(u'General'), {
            'fields': (
                ('project'),
                'is_active',
                'is_featured',
                'sorted_as',
            )}
        ),
        (_(u'Partner'), {
            'fields': (
                'name',
                'logo',
                'website',
            )
        }),
    ]

    def logo_thumbnail(self, obj):
        if obj.logo:
            return format_html(
                '<img src="{}" width="50" height="50" style="object-fit: contain;" />',
                obj.logo.url
            )
        return ""
    logo_thumbnail.short_description = 'Logo'

    def website_link(self, obj):
        if obj.website:
            return format_html(
                '<a href="{}" target="_blank" style="color: #0066cc;">Link</a>',
                obj.website
            )
        return ""
    website_link.short_description = 'Website'
admin.site.register(Partner, PartnerAdmin)


@admin.register(Newsletter)
class NewsletterAdmin(admin.ModelAdmin):
    list_display = ('email', 'name', 'is_active', 'created_at')
    list_filter = ('is_active', 'created_at')
    search_fields = ('email', 'name')
    readonly_fields = ('created_at',)
    actions = ['activate', 'deactivate']

    fieldsets = [
        (_(u'General'), {
            'fields': (
                'project',
                'email',
                'name',
                'is_active',
            )}
        )
    ]

    def activate(self, request, queryset):
        updated = queryset.update(is_active=True)
        self.message_user(request, f'✓ {updated} activated')
    activate.short_description = 'Activated'

    def deactivate(self, request, queryset):
        updated = queryset.update(is_active=False)
        self.message_user(request, f'✓ {updated} deactivated')
    deactivate.short_description = 'Deactivated'

class FAQAnswerAdmin(AdminStackedInline):
    model = FAQAnswer
    extra = 1
    fields = ['sorted_as']

    for code, name in settings.LANGUAGES:
        fields += FAQAnswer.append_lang_fields(code)

class FAQAdmin(AdminBase):
    inlines = [FAQAnswerAdmin]

    list_display = (___('question'), 'project', 'category', 'is_active', 'visited_as', 'sorted_as')
    list_filter = ('is_active', 'category', 'created_at')
    readonly_fields = ('visited_as', 'created_at', 'updated_at')
    ordering = ('sorted_as', '-visited_as')
    
    fieldsets = [
        (_(u'General'), {
            'fields': (
                'project',
                'category',
                'is_active',
                'sorted_as',
                'visited_as',
            )
        }),
    ]


    for code, name in settings.LANGUAGES:
        fieldsets.append(
            (___('Content', name), {
                'fields': FAQ.append_lang_fields(code)
            })
        )

    def question_short(self, obj):
        lang = get_language()
        question = getattr(obj, f'question_{lang}', '') or ''
        return question[:80] + '...' if len(question) > 80 else question
    question_short.short_description = _(u'Question')
admin.site.register(FAQ, FAQAdmin)

