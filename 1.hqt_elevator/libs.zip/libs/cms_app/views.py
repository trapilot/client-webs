from django.http import JsonResponse, HttpResponseNotAllowed
from django.shortcuts import redirect
from django.views.generic import CreateView

from urllib.parse import urlparse, parse_qsl, urlencode, urlunparse

from cms_app.models import Inquiry
from cms_app.forms import InquiryForm


class InquiryView(CreateView):
    model = Inquiry
    form_class = InquiryForm

    # toggle policy
    with_policy = False

    def get(self, request, *args, **kwargs):
        return HttpResponseNotAllowed(['POST'])

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()

        with_policy = getattr(self, 'with_policy', False)
        kwargs.update({
            'individual': True,
            'with_policy': with_policy,
            'policy_label': self.get_policy_label() if hasattr(self, 'get_policy_label') else None,
        })

        return kwargs

    def form_valid(self, form):
        self.object = form.save()

        if self.is_ajax_req():
            return JsonResponse({
                'success': True,
            })

        return redirect(
            self.request.META.get('HTTP_REFERER', '/') + '?msg=ok'
        )

    def form_invalid(self, form):
        if self.is_ajax_req():
            return JsonResponse({
                'success': False,
                'errors': form.errors
            }, status=400)

        referer = self.request.META.get('HTTP_REFERER', '/')
        parsed = urlparse(referer)
        
        query_params = dict(parse_qsl(parsed.query))
        query_items = [('msg', 'error')] + [
            (k, v) for k, v in query_params.items() if k != 'msg'
        ]

        new_url = urlunparse((
            parsed.scheme,
            parsed.netloc,
            parsed.path,
            parsed.params,
            urlencode(query_items),
            parsed.fragment
        ))

        return redirect(new_url)
    
    def is_ajax_req(self):
        return self.request.headers.get('x-requested-with') == 'XMLHttpRequest'
    
class InquiryPolicyView(InquiryView):
    with_policy = True
