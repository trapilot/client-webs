from django.apps import AppConfig
from django.utils.translation import gettext_lazy as _


class CmsAppsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cms_app'
    verbose_name = _("Content Management")
