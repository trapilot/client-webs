import datetime

from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils.translation import gettext_lazy as _

from sorl.thumbnail import ImageField
from ckeditor.fields import RichTextField
from smart_selects.db_fields import ChainedForeignKey, ChainedManyToManyField

from cms_engine.models import Site, Page
from cms_engine.utils import default_site_code
from shared_engine.transmeta import TransMeta
from shared_engine.managers import (
    GeneralManager,
    ArticleManager,
    BackgroundManager,
    PopupManager
)


class Category(models.Model, metaclass=TransMeta):
    objects = GeneralManager()

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='category_set',
        verbose_name=_(u'Site'),
    )
    page = ChainedForeignKey(
        Page,
        on_delete=models.CASCADE,
        related_name='category_set',
        chained_field='site',
        chained_model_field='site',
        verbose_name=_(u'Page'),
        show_all=False,
        auto_choose=False,
        blank=True,
        null=True,
        help_text=_(u'Useful for if want to be related with a special page.'),
    )
    parent = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name='nested_set',
        verbose_name=_(u'Parent'),
        help_text=_(u'It is used to create nested lists.'),
    )
    
    code = models.CharField(_(u'Code'), max_length=50)
    icon = ImageField(_(u'Icon'), blank=True, null=True, upload_to='uploads/cms/categories/icons')
    image = ImageField(_(u'Image'), blank=True, null=True, upload_to='uploads/cms/categories/images')
    color_bg = models.CharField(_(u'Background Color'), blank=True, null=True, max_length=150)
    color_text = models.CharField(_(u'Text Color'), blank=True, null=True, max_length=150)
    name = models.CharField(_(u'Name'), max_length=150, blank=True, null=True)
    summary = models.TextField(_(u'Summary'), max_length=250, blank=True, null=True)
    content = RichTextField(_(u'Content'), blank=True, null=True)
    value = models.IntegerField(
        _(u'Value'), default=0, blank=True, null=True,
        help_text=_(u'Value that the category has, for example that of rating or star'),
    )

    sorted_as = models.PositiveIntegerField(_(u'Order'), default=0)
    is_active = models.BooleanField(_(u'Active'), default=True)
    is_featured = models.BooleanField(_(u'Featured'), default=True)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Article Category')
        verbose_name_plural = _(u'Article Categories')
        translate = ('name', 'summary', 'content',)
        ordering = ('sorted_as', '-is_active',)

    def __str__(self):
        return self.code

    @property
    def articles(self):
        return self.category_set.filter(is_active=True)


class Tag(models.Model, metaclass=TransMeta):
    objects = GeneralManager()

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='tag_set',
        verbose_name=_(u'Site'),
    )
    code = models.CharField(_(u'Code'), max_length=50)
    icon = ImageField(_(u'Icon'), blank=True, null=True, upload_to='uploads/cms/tags/icons')
    name = models.CharField(_(u'Name'), max_length=150, blank=True, null=True)
    ctx_bg = models.CharField(_(u'Background Color'), blank=True, null=True, max_length=150)
    ctx_color = models.CharField(_(u'Text Color'), blank=True, null=True, max_length=150)

    sorted_as = models.PositiveIntegerField(_(u'Order'), default=0)
    is_active = models.BooleanField(_(u'Active'), default=True)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Article Tag')
        verbose_name_plural = _(u'Article Tags')
        translate = ('name',)
        ordering = ('sorted_as', '-is_active',)

    def __str__(self):
        return self.code

    @property
    def articles(self):
        return self.tag_set.filter(is_active=True)


class Article(models.Model, metaclass=TransMeta):
    objects = ArticleManager()

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='article_set',
        verbose_name=_(u'Site'),
    )
    categories = ChainedManyToManyField(
        Category,
        related_name='category_set',
        chained_field='site',
        chained_model_field='site',
        verbose_name=_(u'Article Categories'),
        auto_choose=True,
        blank=True,
    )
    tags = ChainedManyToManyField(
        Tag,
        related_name='tag_set',
        chained_field='site',
        chained_model_field='site',
        verbose_name=_(u'Article Tags'),
        auto_choose=True,
        blank=True,
    )
    title = models.CharField(_(u'Title'), max_length=150, null=True, default='')
    summary = models.TextField(_(u'Summary'), blank=True, null=True)
    content = RichTextField(_(u'Content'), blank=True, null=True)
    slug = models.SlugField(_(u'Slug'), blank=True, null=True)
    icon = ImageField(_(u'Icon'), blank=True, null=True, upload_to='uploads/cms/articles/icons')
    image = ImageField(_(u'Image'), blank=True, null=True, upload_to='uploads/cms/articles/images')
    visited_as = models.PositiveIntegerField(_(u'View Count'), default=0)
    sorted_as = models.PositiveIntegerField(_(u'Order'), default=0)
    is_active = models.BooleanField(_(u'Active'), default=True)
    author = models.CharField(_(u'Author'), max_length=150, blank=True, null=True, default='')
    published_at = models.DateField(
        _(u'Publish'), blank=True, null=True,
        help_text=_(u'Date on which the post will be activated on the web.')
    )

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Article')
        verbose_name_plural = _(u'Articles')
        translate = ('title', 'slug', 'summary', 'content',)
        ordering = ('-published_at', 'sorted_as', 'visited_as',)

    def __str__(self):
        return self.title


class Testimonial(models.Model, metaclass=TransMeta):
    objects = GeneralManager()

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='testimonial_set',
        verbose_name=_(u'Site'),
    )

    customer_name = models.CharField(_(u'Customer Name'), max_length=200)
    customer_title = models.CharField(_(u'Customer Title'), max_length=200, blank=True)
    customer_image = models.ImageField(_(u'Customer Avatar'), upload_to='uploads/cms/testimonials/', blank=True)  
    customer_address = models.CharField(_(u'Customer Address'), max_length=200, blank=True)  
    content = models.TextField(_(u'Content'))    
    rating = models.IntegerField(_(u'Rating'), validators=[MinValueValidator(1), MaxValueValidator(5)])    
    is_featured = models.BooleanField(_(u'Featured'), default=False)
    is_active = models.BooleanField(_(u'Active'), default=True)
    sorted_as = models.PositiveIntegerField(_(u'Order'), default=0)
    
    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = 'Testimonial'
        verbose_name_plural = 'Testimonials'
        ordering = ['-is_featured', '-rating', 'sorted_as']

    def __str__(self):
        return f"{self.customer_name} - {self.rating}★"


class Partner(models.Model, metaclass=TransMeta):
    objects = GeneralManager()

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='partner_set',
        verbose_name=_(u'Site'),
    )
    
    name = models.CharField(_(u'Partner Name'), max_length=200)
    logo = models.ImageField(_(u'Partner Logo'), null=True, blank=True, upload_to='uploads/cms/partners/')
    website = models.URLField(_(u'Partner Website'), null=True, blank=True)
    
    visited_as = models.PositiveIntegerField(_(u'View Count'), default=0)
    sorted_as = models.PositiveIntegerField(_(u'Order'), default=0)
    is_active = models.BooleanField(_(u'Active'), default=True)
    is_featured = models.BooleanField(_(u'Featured'), default=False)
    
    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = 'Partner'
        verbose_name_plural = 'Partners'
        ordering = ['sorted_as', 'name']

    def __str__(self):
        return self.name


class Inquiry(models.Model):
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('contacted', 'Contacted'),
        ('processing', 'Processing'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    )

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='inquiry_set',
        verbose_name=_(u'Site'),
    )

    name = models.CharField(_(u'Name'), max_length=100)
    email = models.EmailField(_(u'Email'), max_length=60)
    phone = models.CharField(_(u'Phone'), max_length=20)
    address = models.TextField(_(u'Address'), max_length=100, null=True, blank=True)
    subject = models.TextField(_(u'Subject'), max_length=150, null=True, blank=True)
    comment = models.TextField(_(u'Comment'), max_length=3000, null=True, blank=True)
    note = models.TextField(_(u'Note'), max_length=3000, null=True, blank=True)
    status = models.CharField(_(u'Status'), max_length=10, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)

    class Meta:
        verbose_name = _(u'Contact Inquiry')
        verbose_name_plural = _(u'Contact Inquiries')
        ordering = ['status', '-created_at']

    def __str__(self):
        return f"{self.email} - {self.name}"


class FAQ(models.Model, metaclass=TransMeta):
    objects = GeneralManager()

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='faq_set',
        verbose_name=_(u'Site'),
    )
    
    
    question = models.CharField(_(u'Question'), max_length=255)
    category = models.SlugField(_(u'Category'), max_length=100, null=True, blank=True)
    
    visited_as = models.PositiveIntegerField(_(u'View Count'), default=0)
    sorted_as = models.PositiveIntegerField(_(u'Order'), default=0)
    is_active = models.BooleanField(_(u'Active'), default=True)
    
    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = 'FAQ'
        verbose_name_plural = 'FAQs'
        translate = ('question',)
        ordering = ['sorted_as', '-visited_as']

    def __str__(self):
        return self.question[:100]
    
    @property
    def answers(self):
        return [a.answer for a in self.answer_set.all()]
    
class FAQAnswer(models.Model, metaclass=TransMeta):
    faq = models.ForeignKey(
        FAQ,
        on_delete=models.CASCADE,
        related_name='answer_set'
    )

    answer = models.TextField(_(u'Answer'), blank=True)
    sorted_as = models.PositiveIntegerField(_(u'Order'), default=0)

    class Meta:
        translate = ('answer',)
        ordering = ['sorted_as']

    # def __str__(self):
    #     return self.answer[:100]

from cms_app.signals import *
