from django.urls import path

from cms_app.views import (
    InquiryView,
    InquiryPolicyView,
)

urlpatterns = [
    path(
        'submit-inquiry/simple/',
        InquiryView.as_view(),
        name='submit_inquiry',
    ),

    path(
        'submit-inquiry/policy/',
        InquiryPolicyView.as_view(),
        name='submit_inquiry_policy',
    ),
]