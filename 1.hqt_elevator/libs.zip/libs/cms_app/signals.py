from django.db.models.signals import post_delete
from django.dispatch import receiver

from cms_engine.utils import delete_file
from cms_app.models import (
    Article,
)


@receiver(post_delete, sender=Article)
def post_delete_image(sender, instance=None, **kwargs):
    if instance.image:
        delete_file(instance.image.path)