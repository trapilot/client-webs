from django.urls import path, re_path

from marketing_engine.views import LandingView, InquiryView, InquiryPolicyView


urlpatterns = [
    path('form/api/contact/', InquiryView.as_view(), name='cms_contact'),
    path('form/api/contact/', InquiryPolicyView.as_view(), name='cms_contact_policy'),
    re_path(r'lp/(?P<slug>[-\w]+)/', LandingView.as_view(), name='cms_landing'),
]