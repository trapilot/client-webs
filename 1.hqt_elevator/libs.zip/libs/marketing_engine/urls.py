from django.urls import path, re_path

from marketing_engine.views import (
    LandingView,
    QuoteInquiryView, QuoteInquiryPolicyView,
    ConsultationInquiryView, ConsultationInquiryPolicyView,
    ContactInquiryView, ContactInquiryPolicyView,
)

urlpatterns = [
    path('api/inquiry/quote/', QuoteInquiryView.as_view(), name='form_quote'),
    path('api/inquiry/quote_policy/', QuoteInquiryPolicyView.as_view(), name='form_quote_policy'),
    path('api/inquiry/consultation/', ConsultationInquiryView.as_view(), name='form_consultation'),
    path('api/inquiry/consultation_policy/', ConsultationInquiryPolicyView.as_view(), name='form_consultation_policy'),
    path('api/inquiry/contact/', ContactInquiryView.as_view(), name='form_contact'),
    path('api/inquiry/contact_policy/', ContactInquiryPolicyView.as_view(), name='form_contact_policy'),

    re_path(r'lp/(?P<slug>[-\w]+)/', LandingView.as_view(), name='cms_landing'),
]