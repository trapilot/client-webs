from django.conf import settings
from django.contrib import admin
from django.urls import reverse
from django.utils.html import format_html
from django.utils.translation import gettext_lazy as _

from shared_engine.transmeta import get_real_fieldname as __, get_lable_language as ___
from shared_engine.admin import AdminBase
from marketing_engine.models import (
    Landing,
    Campaign,
    Inquiry,
)


class CampaignAdmin(AdminBase):
    list_display = ('code', 'site', __('name'), 'since_date', 'until_date', 'visited_as', 'is_active',)
    fieldsets = [
        (u'General', {
            'fields': (
                'site',
                'code',
                'since_date',
                'until_date',
                ('is_active',),
            )
        }),
    ]


    for code, name in settings.LANGUAGES:
        fieldsets.append(
            (___('Content', name), {
                'fields': Campaign.append_lang_fields(code)
            })
        )
admin.site.register(Campaign, CampaignAdmin)


class LandingAdmin(AdminBase):
    list_display = ('slug', 'site', 'campaign', 'since_date', 'until_date', 'visited_as', 'is_active', 'show_url',)
    # inlines = (NoticeLandingAdmin, OfferLandingAdmin)
    # actions = [General]
    list_filter = ('campaign',)
    fieldsets = [
        (u'General', {
            'fields': (
                'site',
                'campaign',
                'since_date',
                'until_date',
                ('is_active',),
            )
        }),
        (u'Images', {
            'fields': (
                'logo', 'background',
            )
        }),
    ]

    prepopulated_fields = {}

    def show_url(self, obj):
        try:
            slug = getattr(obj, __('slug'))
            qs = f"?test=1&utm_source=admin-cms"
            url = f"{reverse('cms_landing', kwargs={'slug': slug})}{qs}"
            return format_html('<a href="{}" target="_blank">{}</a>', url, slug)
        except Exception as e:
            return ''
    show_url.allow_tags = True
    show_url.short_description = 'Preview'

    for code, name in settings.LANGUAGES:
        fieldsets.append(
            (___('Content', name), {
                'fields': Landing.append_lang_fields(code)
            })
        )
        # readonly_fields.append(__('html', code))
        prepopulated_fields[__('slug', code)] = (__('label', code),)
admin.site.register(Landing, LandingAdmin)


@admin.register(Inquiry)
class InquiryAdmin(admin.ModelAdmin):
    list_display = ('type', 'subject', 'site', 'name', 'email', 'address', 'phone', 'status', 'created_at')
    list_filter = ('type', 'email', 'phone', 'created_at')
    search_fields = ('email', 'name', 'phone',)
    # readonly_fields = ('email', 'site', 'name', 'phone', 'address', 'subject_link', 'comment', 'created_at',)
    readonly_fields = ('type', 'created_at',)

    fieldsets = [
        (_(u'General'), {
            'fields': (
                'site',
                'type',
                'name',
                'email',
                'phone',
                'address',
                'comment',
                ('status', 'note',),
            )}
        )
    ]

    def subject_link(self, obj):
        if obj.subject and (
            obj.subject.startswith('http://') or
            obj.subject.startswith('https://')
        ):
            return format_html(
                '<a href="{}" target="_blank">{}</a>',
                obj.subject,
                obj.subject,
            )
        return obj.subject or '-'
    subject_link.short_description = _(u'Subject')

