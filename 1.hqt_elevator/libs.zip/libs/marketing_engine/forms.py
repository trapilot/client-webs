
from django import forms
from django.core.validators import validate_email
from django.utils.translation import gettext_lazy as _
from django.utils.safestring import mark_safe

# from captcha.fields import CaptchaField

from marketing_engine.models import Inquiry


class InquiryForm(forms.ModelForm):
    # captcha = CaptchaField(label=_(u'Repeat this code'))

    class Meta:
        model = Inquiry
        fields = ('name', 'email', 'phone', 'subject', 'comment')
        widgets = {
            'site': forms.HiddenInput
        }
        
    def __init__(self, *args, individual=False, with_policy=False, policy_label=None, inquiry_type=None, **kwargs):
        self.inquiry_type = inquiry_type
        self.individual = individual
        
        super().__init__(*args, **kwargs)
        
        # policy field optional
        if with_policy:
            self.fields['privacy_policy'] = forms.BooleanField(
                required=True,
                label=mark_safe(policy_label or _(u'Accept Privacy Policy'))
            )

    def clean_email(self):
        email = self.cleaned_data['email']
        if email:
            try:
                validate_email(email)
            except (forms.ValidationError, UnicodeDecodeError):
                raise forms.ValidationError(
                    _('The email entered is not valid')
                )

        return email
    
    def clean(self):
        cleaned_data = super().clean()

        email = cleaned_data.get('email')
        phone = cleaned_data.get('phone')

        if not email and not phone:
            raise forms.ValidationError(
                _('Please provide either an email or phone number.')
            )

        return cleaned_data
    
    def save(self, commit=True):
        instance = super().save(commit=False)

        if self.inquiry_type:
            instance.type = self.inquiry_type

        if commit:
            instance.save()

        return instance
