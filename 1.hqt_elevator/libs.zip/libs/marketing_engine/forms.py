
from django import forms
from django.core.validators import validate_email
from django.utils.translation import gettext_lazy as _
from django.utils.safestring import mark_safe

# from captcha.fields import CaptchaField

from marketing_engine.models import Inquiry

class InquiryForm(forms.ModelForm):
    # captcha = CaptchaField(label=_(u'Repeat this code'))

    class Meta:
        model = Inquiry
        fields = ('name', 'email', 'phone', 'subject', 'comment')
        widgets = {
            'site': forms.HiddenInput
        }

    def clean_email(self):
        email = self.cleaned_data['email']
        try:
            validate_email(email)
        except (forms.ValidationError, UnicodeDecodeError):
            raise forms.ValidationError(_(u'The email entered is not valid'))
        return email
    
    def __init__(self, *args, individual=False, with_policy=False, policy_label=None, **kwargs):
        super().__init__(*args, **kwargs)

        self.individual = individual

        # policy field optional
        if with_policy:
            self.fields['privacy_policy'] = forms.BooleanField(
                required=True,
                label=mark_safe(policy_label or _(u'Accept Privacy Policy'))
            )

