from django.apps import AppConfig
from django.utils.translation import gettext_lazy as _


class MarketingEngineConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'marketing_engine'
    verbose_name = _("Marketing")
