from django.db import models
from django.db.models import ImageField
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _

from ckeditor.fields import RichTextField
from smart_selects.db_fields import ChainedForeignKey

from shared_engine.managers import GeneralManager
from shared_engine.transmeta import TransMeta
from shared_engine.transcode import upload_to
from site_engine.utils import default_site_code
from site_engine.models import Site, Form


class Campaign(models.Model, metaclass=TransMeta):
    objects = GeneralManager()
    ADMIN_ORDER = 1

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='campaign_set',
        verbose_name=_(u'Site'),
    )

    code = models.SlugField(_(u'Code'), max_length=50, unique=True)
    name = models.CharField(_(u'Name'), max_length=255, null=True, blank=True)
    description = models.TextField(_(u'Description'), blank=True, null=True)

    since_date = models.DateTimeField(_(u'Since Date'))
    until_date = models.DateTimeField(_(u'Until Date'))

    is_active = models.BooleanField(_(u'Active'), default=True)
    visited_as = models.PositiveIntegerField(_(u'View Count'), default=0)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Campaign')
        verbose_name_plural = _(u'Campaigns')
        translate = ('name', 'description',)
        ordering = ('-since_date', '-created_at',)
        indexes = [
            models.Index(fields=['site', 'is_active']),
            models.Index(fields=['since_date']),
            models.Index(fields=['until_date']),
        ]

    def clean(self):
        if self.until_date <= self.since_date:
            raise ValidationError(
                _(u'until_date must be greater than since_date')
            )
        
    def __str__(self):
        return self.name or self.code
    

class Landing(models.Model, metaclass=TransMeta):
    objects = GeneralManager()
    ADMIN_ORDER = 2

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        verbose_name=_(u'Site'),
        related_name='landing_set',
    )
    campaign = ChainedForeignKey(
        Campaign,
        on_delete=models.SET_NULL,
        related_name='landing_set',
        chained_field='site',
        chained_model_field='site',
        verbose_name=_(u'Campaign'),
        show_all=False,
        auto_choose=False,
        blank=True,
        null=True,
        help_text=_(u'If a campaign is specified, only for the specified campaign'),
    )
    
    slug = models.SlugField(u'Slug', max_length=255, help_text=_(u'Public URL path'), default='')
    logo = ImageField(u'Logo', upload_to=upload_to('uploads/landing/logos'), null=True, blank=True)
    background = ImageField(u'Background',upload_to=upload_to('uploads/landing/backgrounds'), null=True, blank=True)
    label = models.CharField(_(u'Label'), max_length=255, blank=True, null=True)
    title = models.CharField(_(u'Title'), max_length=255, blank=True, null=True)
    subtitle = models.CharField(_(u'Sub-Title'), max_length=255, blank=True, null=True)
    description = models.TextField(_(u'Description'), blank=True, null=True)
    html = RichTextField(u'Content', blank = True, null=True)

    taxes = models.CharField(_(u'taxes'), max_length = 200, default='Taxes', help_text=u'Translation: Taxes')
    click = models.CharField(_(u'Text click'), max_length = 200,  default='Click here', help_text=u'Translation: Click here')
    policies = models.CharField(_(u'Political text'), max_length = 200,  default='See privacy policies', help_text=u'Translation: See privacy policies')
    unsubscribe = models.CharField(_(u'Unsubscribe text'), max_length = 200,  default='Unsubscribe', help_text=u'Translation: Unsubscribe')
    concerns = models.CharField(_(u'Text concerns'), max_length = 200,  default='If you have concerns', help_text=u'Translation: If you have concerns')
    header = models.CharField(_(u'Header text'), max_length = 200,  default='If you can\'t read this e-mail', help_text=u'Translation: if you can\'t read this e-mail')
    specials = models.CharField(_(u'Special offers'), max_length = 200,  default='Special offers', help_text=u'Translation: Special offers')
    
    button_text = models.CharField(_(u'Button Text'), max_length=100, blank=True, null=True, default='Read more', help_text=u'Translation: Read more')
    button_link = models.URLField(_(u'Button Link'), null=True, blank=True)
    
    is_active = models.BooleanField(_(u'Active'), default = True)
    visited_as = models.PositiveIntegerField(_(u'View Count'), default=0)
    
    since_date = models.DateTimeField(_(u'Since Date'), null=True, blank=True)
    until_date = models.DateTimeField(_(u'Until Date'), null=True, blank=True)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Landing Page')
        verbose_name_plural = _(u'Landing Pages')
        ordering = ('-campaign', '-since_date', '-created_at',)
        translate = (
            'slug', 'label', 'title', 'subtitle', 'button_link', 'button_text', 'html',
            'taxes', 'click', 'policies', 'unsubscribe', 'concerns', 'header', 'specials'
        )
        indexes = [
            models.Index(fields=['site', 'is_active']),
            models.Index(fields=['since_date']),
            models.Index(fields=['until_date']),
        ]
        # constraints = [
        #     models.UniqueConstraint(
        #         fields=['site', 'slug'],
        #         name='landing_site_slug_unique'
        #     )
        # ]

    def clean(self):
        if self.since_date and self.until_date and self.until_date <= self.since_date:
            raise ValidationError(
                _('Until date must be greater than since date')
            )
        
    def __str__(self):
        return self.label or self.title


class LandingAction(models.Model, metaclass=TransMeta):
    objects = GeneralManager()

    class ActionType(models.TextChoices):
        URL = 'url', _('URL')
        PHONE = 'phone', _('Phone')
        EMAIL = 'email', _('Email')
        FORM = 'form', _('Form')

    landing = models.ForeignKey(
        Landing,
        on_delete=models.CASCADE,
        related_name='action_set'
    )

    label = models.CharField(_(u'Label'), max_length=100)
    action_type = models.CharField(_(u'Action Type'), max_length=20, choices=ActionType.choices, default=ActionType.URL)
    value = models.CharField(_(u'Value'), max_length=500)
    
    is_active = models.BooleanField(_(u'Active'), default = True)
    visited_as = models.PositiveIntegerField(_(u'View Count'), default=0)

    class Meta:
        ordering = ('visited_as', 'is_active',)

    def __str__(self):
        return self.label
    

class LandingVisit(models.Model, metaclass=TransMeta):
    objects = GeneralManager()

    landing = models.ForeignKey(
        Landing,
        on_delete=models.CASCADE,
        related_name='visit_set'
    )

    campaign = models.ForeignKey(
        Campaign,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='visit_set'
    )

    ip_address = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.TextField(blank=True)
    referer = models.URLField(blank=True)
    utm_data = models.JSONField(default=dict, blank=True)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)

    class Meta:
        ordering = ('-created_at',)


class Inquiry(models.Model, metaclass=TransMeta):
    objects = GeneralManager()
    ADMIN_ORDER = 3

    class InquiryStatus(models.TextChoices):
        NEW = 'NEW', _(u'New')
        IN_PROGRESS = 'IN_PROGRESS', _(u'In Progress')
        AWAITING = 'AWAITING', _(u'Awaiting Response')
        RESOLVED = 'RESOLVED', _(u'Resolved')
        CLOSED = 'CLOSED', _(u'Closed')
        SPAM = 'SPAM', _(u'Spam')

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='inquiry_set',
        verbose_name=_(u'Site'),
    )

    campaign = models.ForeignKey(
        Campaign,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='inquiry_set'
    )

    landing = models.ForeignKey(
        Landing,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='inquiry_set'
    )

    name = models.CharField(_(u'Name'), max_length=100)
    email = models.EmailField(_(u'Email'), max_length=60)
    phone = models.CharField(_(u'Phone'), max_length=20)
    address = models.CharField(_(u'Address'), max_length=100, null=True, blank=True)
    subject = models.CharField(_(u'Subject'), max_length=150, null=True, blank=True)
    comment = models.TextField(_(u'Comment'), max_length=3000, null=True, blank=True)
    note = models.TextField(_(u'Note'), max_length=3000, null=True, blank=True)
    type = models.CharField(_(u'Type'), max_length=30, null=True, blank=True)
    status = models.CharField(_(u'Status'), max_length=30, choices=InquiryStatus.choices, default=InquiryStatus.NEW)
    
    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Contact Inquiry')
        verbose_name_plural = _(u'Contact Inquiries')
        ordering = ['status', '-created_at']

    def __str__(self):
        return f"{self.email} - {self.name}"


from marketing_engine.signals import *
