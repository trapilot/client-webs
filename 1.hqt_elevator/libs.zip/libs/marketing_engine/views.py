from django.urls import reverse
from django.db.models import F, Q
from django.views.generic.base import TemplateView
from django.utils import timezone
from django.http import Http404, JsonResponse, HttpResponseNotAllowed
from django.shortcuts import redirect
from django.views.generic import CreateView


from urllib.parse import urlparse, parse_qsl, urlencode, urlunparse
from ipware import get_client_ip

from marketing_engine.models import Campaign, Landing, LandingVisit, Inquiry
from marketing_engine.forms import InquiryForm


class LandingView(TemplateView):
    template_name = 'landing.html'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        site = self.request.site
                
        landing = None
        matched_lang = None
        now = timezone.now()
        
        for lang in site.languages:            
            try:
                landing = Landing.objects.filter(
                    site=site,
                    is_active=True,
                ).filter(
                    Q(since_date__isnull=True) | Q(since_date__lte=now),
                    Q(until_date__isnull=True) | Q(until_date__gte=now),
                ).filter(
                    Q(campaign__isnull=True) |
                    (
                        Q(campaign__is_active=True) &
                        (Q(campaign__since_date__isnull=True) | Q(campaign__since_date__lte=now)) &
                        (Q(campaign__until_date__isnull=True) | Q(campaign__until_date__gte=now))
                    )
                ).get(**{
                    'site': site,
                    'slug_%s' % lang: kwargs['slug']
                })

                if landing:
                    matched_lang = lang

                    is_testing = self.request.GET.get("test") == "1"
                    if not is_testing:
                        Landing.objects.filter(id=landing.id).update(
                            visited_as=F('visited_as') + 1
                        )
                        if landing.campaign_id:
                            Campaign.objects.filter(pk=landing.campaign_id).update(
                                visited_as=F('visited_as') + 1
                            )

                            ip, _is_routable = get_client_ip(self.request)
                            utm_data = {
                                k: v
                                for k, v in self.request.GET.items()
                                if k.startswith('utm_')
                            }
                            LandingVisit.objects.create(
                                landing=landing,
                                campaign=landing.campaign,
                                ip_address=ip,
                                user_agent=self.request.META.get('HTTP_USER_AGENT', ''),
                                referer=self.request.META.get('HTTP_REFERER', ''),
                                utm_data=utm_data,
                            )
                    break
            except:
                pass

        if not landing:
            raise Http404()

        active_urls = {}
        for lang in site.languages:
            slug = getattr(landing, 'slug_%s' % lang, None)
            if slug:
                active_urls[lang] = reverse(
                    'cms_landing',
                    kwargs={'slug': slug}
                )

        ctx['landing'] = landing
        ctx['active_lang'] = matched_lang
        ctx['active_urls'] = active_urls

        return ctx


class InquiryView(CreateView):
    model = Inquiry
    form_class = InquiryForm

    # toggle policy
    with_policy = False

    def get(self, request, *args, **kwargs):
        return HttpResponseNotAllowed(['POST'])

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()

        with_policy = getattr(self, 'with_policy', False)
        kwargs.update({
            'individual': True,
            'with_policy': with_policy,
            'policy_label': self.get_policy_label() if hasattr(self, 'get_policy_label') else None,
        })

        return kwargs

    def form_valid(self, form):
        self.object = form.save()

        if self.is_ajax_req():
            return JsonResponse({
                'success': True,
            })

        return redirect(
            self.request.META.get('HTTP_REFERER', '/') + '?msg=ok'
        )

    def form_invalid(self, form):
        if self.is_ajax_req():
            return JsonResponse({
                'success': False,
                'errors': form.errors
            }, status=400)

        referer = self.request.META.get('HTTP_REFERER', '/')
        parsed = urlparse(referer)
        
        query_params = dict(parse_qsl(parsed.query))
        query_items = [('msg', 'error')] + [
            (k, v) for k, v in query_params.items() if k != 'msg'
        ]

        new_url = urlunparse((
            parsed.scheme,
            parsed.netloc,
            parsed.path,
            parsed.params,
            urlencode(query_items),
            parsed.fragment
        ))

        return redirect(new_url)
    
    def is_ajax_req(self):
        return self.request.headers.get('x-requested-with') == 'XMLHttpRequest'
    
class InquiryPolicyView(InquiryView):
    with_policy = True
