from django import http
from django.conf import settings

from cms_engine.backoffice import defaults


def project(request):
    u"""
    The project can be accessed in the templates via
    request.session.project, but for reasons of comfort, better pass project.
    """
    
    context = {
        'project' : getattr(request, 'project', None),
        'page' : getattr(request, 'page', None),
        'http_host' : ''
    }

    # Another useful thing that we are going to pass in the templates
    # is the HTTP_REQUEST, with the http:// in front. If we are in
    # safe mode, we put https.
    # ssl = request.META.get('HTTPS')
    # prefix = 'http://'
    # if ssl:
    # prefix = 'https://'
    
    try:
        prefix = request.META['UWSGI_SCHEME'] + '://'
    except KeyError:
        prefix = '//'

    try:
        context['http_host'] = prefix + request.META['HTTP_HOST']
    except KeyError:
        # on some requests, the HTTP_HOST header is not included
        # for these, we will try to retrieve the hostname from the
        # SERVER_NAME header
        try:
            context['http_host'] = prefix + request.META['SERVER_NAME']
        except KeyError:
            print(u'404 kicked out by cms_engine, context processor. Line 37')
            raise http.Http404
    
    try:
        page = context['page']
        languages = []
        for code, name in settings.LANGUAGES:
            languages.push(code)
        context['page_languages'] = {pag: getattr(page, 'url_%s' % pag) for pag in languages if getattr(page, 'url_%s' % pag) and not '(?P<' in pag.url}
    except Exception:
        context['page_languages'] = None
    return context


def backoffice(request):
    u"""
    Context for administration. We only charge it when
    """
    context = {}
    if '/cms-view/' in getattr(request.META, 'REQUEST_URI', request.META['PATH_INFO']):

        if 'cms_superuser' in [g.name for g in request.user.groups.all()]:
            request.user.cms_superuser = True

        context = {
            'copyright' : defaults.COPYRIGHT,
            'version' : defaults.VERSION,
            'option_menus' : option_menus()
        }

    return context


def option_menus():
    u"""
    We check which applications have a back office and which menu options we should add in the cms navigation
    """
    options = {}

    for app in settings.INSTALLED_APPS:
        try:
            backapp = __import__(
                "%s.backoffice" % app, fromlist=['backoffice'])
        except ImportError:
            continue

        options = dict(options.items() | getattr(backapp, 'OPTION_MENUS', {}).items())

    return options
