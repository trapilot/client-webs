from django import http
from django.conf import settings

from cms_engine.backoffice import defaults


def session(request):
    u"""
    The site can be accessed in the templates via
    request.session.site, but for reasons of comfort, better pass site.
    """
    
    context = {
        'site' : getattr(request, 'site', None),
        'page' : getattr(request, 'page', None),
        'lang' : getattr(request, 'lang', None),
        'language_pages': None,
        'language_domains': None,
        'http_host' : ''
    }

    # Another useful thing that we are going to pass in the templates
    # is the HTTP_REQUEST, with the http:// in front. If we are in
    # safe mode, we put https.
    # ssl = request.META.get('HTTPS')
    # prefix = 'http://'
    # if ssl:
    # prefix = 'https://'
    
    prefix = 'https://' if request.is_secure() else 'http://'       

    try:
        context['http_host'] = prefix + request.get_host()
    except KeyError:
        # on some requests, the HTTP_HOST header is not included
        # for these, we will try to retrieve the hostname from the
        # SERVER_NAME header
        try:
            context['http_host'] = prefix + request.META['SERVER_NAME']
        except KeyError:
            print(u'404 kicked out by cms_engine, context processor. Line 37')
            raise http.Http404
    
    try:
        if len(settings.LANGUAGES) > 1:
            site = context['site']
            page = context['page']
            
            lang_codes = []
            for code, _name in settings.LANGUAGES:
                lang_codes.append(code)

            lang_pages = { lang: getattr(page, 'url_%s' % lang) for lang in lang_codes if getattr(page, 'url_%s' % lang) and not page.is_internal }
            lang_domains = { lang: getattr(site, 'domain_%s' % lang) for lang in lang_codes if getattr(site, 'domain_%s' % lang) }
            
            context['language_pages'] = lang_pages
            context['language_domains'] = lang_domains
    except Exception:
        pass
    return context


def backoffice(request):
    u"""
    Context for administration. We only charge it when
    """
    context = {}
    if '/cms-view/' in getattr(request.META, 'REQUEST_URI', request.META['PATH_INFO']):

        if 'cms_superuser' in [g.name for g in request.user.groups.all()]:
            request.user.cms_superuser = True

        context = {
            'copyright' : defaults.COPYRIGHT,
            'version' : defaults.VERSION,
            'option_menus' : option_menus()
        }

    return context


def option_menus():
    u"""
    We check which applications have a back office and which menu options we should add in the cms navigation
    """
    options = {}

    for app in settings.INSTALLED_APPS:
        try:
            backapp = __import__(
                "%s.backoffice" % app, fromlist=['backoffice'])
        except ImportError:
            continue

        options = dict(options.items() | getattr(backapp, 'OPTION_MENUS', {}).items())

    return options
