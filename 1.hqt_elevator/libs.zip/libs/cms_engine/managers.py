#!/usr/bin/env python
from django.db import models
from django.db.models import Q

from shared_engine.transmeta import get_real_fieldname as __

class SiteManager(models.Manager):

    def site(self, domain):
        """
        We return the site whose domain matches
        """
        kwargs = {
            __('domain'): domain
        }
        sites = self.filter(Q(**kwargs))
        try:
            site = sites[0]
        except IndexError:
            site = None

        return site

