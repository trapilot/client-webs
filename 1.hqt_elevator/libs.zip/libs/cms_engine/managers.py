#!/usr/bin/env python
from django.db import models
from django.db.models import Q

from shared_engine.transmeta import get_real_fieldname as __

class ProjectManager(models.Manager):

    def project(self, domain):
        """
        We return the project whose domain matches
        """
        kwargs = {
            __('domain'): domain
        }
        projects = self.filter(Q(**kwargs))
        try:
            project = projects[0]
        except IndexError:
            project = None

        return project


class PageManager(models.Manager):
    def is_activated(self, **kwargs):
        return self.filter(is_active=True, **kwargs)
