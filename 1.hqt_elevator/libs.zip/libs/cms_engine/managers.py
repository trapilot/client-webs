#!/usr/bin/env python
from django.db import models
from django.db.models import Q

class SiteQuerySet(models.QuerySet):
    def with_all(self):
        return self.prefetch_related(
            'page_set',
            'constant_set',
            'branch_set',
            'license_set',
            'top_feature_set',
            'marketing_claim_set',
            'social_network_set',
            'operating_hour_set',
        )
    
class SiteManager(models.Manager.from_queryset(SiteQuerySet)):
    def get_queryset(self):
        return SiteQuerySet(self.model, using=self._db)


class PageQuerySet(models.QuerySet):
    def with_all(self):
        return self.prefetch_related(
            'banner_set',
            'brand_set',
            'highlight_set',
            'testimonial_set',
            'nested_set',
        )
    
class PageManager(models.Manager.from_queryset(PageQuerySet)):
    def get_queryset(self):
        return PageQuerySet(self.model, using=self._db)