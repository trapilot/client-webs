from os.path import exists

from django.conf import settings
from django.contrib import admin
from django.utils.html import format_html
from django.utils.translation import gettext_lazy as _

from cms_engine.forms import ConstantForm, PageAdminForm
from cms_engine.models import (
    Constant,
    Branch,
    MarketingClaim,
    SocialNetwork,
    OperatingHour,
    MetaObject,
    Page,
    Project,
    Redirection,
    Translation,
    Landing,
)
from cms_engine.utils import default_project_code
from shared_engine.admin import (
    AdminBase,
    AdminModelBase,
    AdminImageMixin,
    AdminTabularInline,
    AdminStackedInline,
)
from shared_engine.transmeta import get_real_fieldname as __, get_lable_language as ___


class ConstantAdmin(AdminTabularInline):
    form = ConstantForm
    model = Constant


class MarketingClaimAdmin(AdminStackedInline):
    model = MarketingClaim

    fieldsets = [
        [_(u'General'), {
            'fields': ('icon', ('code', 'sorted_as',), 'page_code',)
        }]
    ]

    for code, name in settings.LANGUAGES:
        fieldsets.append(
            [___('Content', name), {
                'classes': ('grp-collapse',),
                'fields': [
                    __('description', code),
                    (__('link', code), __('link_text', code),),
                ]
            }]
        )


class SocialNetworkAdmin(AdminStackedInline):
    model = SocialNetwork

    fieldsets = [
        [_(u'General'), {
            'fields': ('name', ('code', 'icon'), 'url', ('sorted_as', 'is_active'))
        }]
    ]

class OperatingHourAdmin(AdminStackedInline):
    model = OperatingHour

    fieldsets = [
        [_(u'General'), {
            'fields': ('weekday', ('hour_from', 'hour_to'),)
        }]
    ]

class BranchAdmin(AdminStackedInline):
    model = Branch

    fieldsets = [
        [_(u'General'), {
            'fields': (
                'logo',
                ('email', 'phone', 'fax',),
                ('geolat', 'geolng', 'geozm'),
                ('icon', 'sorted_as',),
                'is_active',
                'is_default',
            )
        }]
    ]

    for code, name in settings.LANGUAGES:
        fieldsets.append(
            [___('Content', name), {
                'classes': ('grp-collapse',),
                'fields': Branch.append_lang_fields(code)
            }]
        )


class ProjectAdmin(AdminModelBase):
    list_display = (
        'code', 'name', 'language_text', 'language_type', 'domain', 'is_ssl', 'sitemap_extension',
    )
    search_fields = ['name', 'code',]

    inlines = [
        ConstantAdmin,
        BranchAdmin,
        OperatingHourAdmin,
        SocialNetworkAdmin,
        MarketingClaimAdmin,
    ]
    fieldsets = [
        [_(u'General'), {
            'fields': (
                ('code', 'language_type', 'language_text',),
                'name',
                'is_ssl',
                'imageLogo',
                'imageFavicon',
                'image404',
                'sitemap_extension',
                'extra_robots',
            )
        }],
        [_(u'Slogan'), {
            'fields': []
        }],
        [_(u'Domains'), {
            'fields': []
        }],
    ]

    for code, name in settings.LANGUAGES:
        fieldsets[1][1]['fields'].append(__('slogan', code))
        fieldsets[2][1]['fields'].append(__('domain', code))

    def get_readonly_fields(self, request, obj=None):
        if obj is None:
            return []
        return ['code',]
admin.site.register(Project, ProjectAdmin)


class MetaObjectAdmin(AdminTabularInline):
    model = MetaObject


class PageAdmin(AdminModelBase):
    form = PageAdminForm
    inlines = [MetaObjectAdmin]

    list_display = (
        __('name'), 'project', 'parent', 'url', 'is_home', 'is_top_menu', 'is_sub_menu',
        'is_active', 'is_ssl', 'cache_context', 'reversed_as',
    )
    list_filter = ('project', 'code',)
    list_editable = ('parent', 'cache_context', 'reversed_as',)
    fieldsets = [
        [_(u'General'), {
            'fields': (
                'project', 'code', 'icon', 'parent', 'is_active', 'is_ssl', 'is_external', 'is_internal',
                ('reversed_as',),
            )
        }],
        [_(u'Menu'), {
            'fields': (
                ('is_home',),
                ('is_top_menu', 'top_menu_col', 'top_menu_row',),
                ('is_sub_menu', 'sub_menu_col', 'sub_menu_row',),
            )
        }],
        [_(u'Template'), {
            'fields': ('view', 'context', 'cache_context',)
        }],
        [_(u'Robots'), {
            'fields': ('is_index', 'is_follow',)
        }],
        [_(u'Sitemap'), {
            'fields': ('changefreq', 'priority',)
        }],
        [_(u'Metadata'), {
            'fields': ('meta_card', 'meta_image',)
        }],
    ]
    search_fields = ['code',]
    lang_search_fields = ('name', 'url', 'content',)

    for code, name in settings.LANGUAGES:
        fieldsets.append(
            (___('Content', name), {
                'fields': Page.append_lang_fields(code)
            })
        )

        search_fields.extend([
            __((field for field in lang_search_fields), code)
        ])
    
    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        u"""
        We restrict the options of the 'parent' field to the pages of the same project
        """
        if db_field.name == 'parent':
            project_code = request.META.get('CMS_PROJECT_CODE')
            if not project_code:
                project = default_project_code()
                project_code = project.code
            kwargs['queryset'] = Page.objects.filter(
                project__code=project_code).order_by('-parent', __('name'))
        return super(PageAdmin, self).formfield_for_foreignkey(db_field, request, **kwargs)
admin.site.register(Page, PageAdmin)


class TranslationAdmin(AdminBase):
    list_display = ('project', 'page', 'identifier', 'exists',)
    list_filter = ('project', 'page__code', 'exists',)
    search_fields = ['identifier',]
    lang_search_fields = ('value',)
    list_display_links = ('identifier',)

    fieldsets = [[
        _(u'General'), {
            'fields': ('identifier', 'exists',)
        }],
        [_(u'Content'), {
            'fields': []
        }],
    ]

    for code, name in settings.LANGUAGES:
        fieldsets[1][1]['fields'].append(__('value', code))
admin.site.register(Translation, TranslationAdmin)


class RedirectionAdmin(AdminBase):
    list_display = ('project', 'old_url', 'new_url',)
    search_fields = ('old_url',)
    list_filter = ('project',)
admin.site.register(Redirection, RedirectionAdmin)


class LandingAdmin(AdminImageMixin, AdminModelBase):
    list_display = ('url', 'project', 'published_from', 'published_to', 'is_active', 'show_url',)
    # inlines = (NoticeLandingAdmin, OfferLandingAdmin)
    # actions = [General]
    fieldsets = [
        (u'General', {
            'fields': (
                'project',
                ('published_from', 'published_to',),
                ('is_active',),
            )
        }),
        (u'Images', {
            'fields': (
                'logo', 'backgroud_header', 'backgroud_footer',
            )
        }),
    ]

    prepopulated_fields = {}

    def show_url(self, obj):
        return format_html(
            '<a href="http://%s/landing/%s" target="_blank">%s</a>' % (
                getattr(obj.project, __('domain')),
                getattr(obj, __('url')),
                getattr(obj, __('url')),
            )
        )
    show_url.allow_tags = True
    show_url.short_description = 'Preview'

    for code, name in settings.LANGUAGES:
        fieldsets.append(
            (___('Content', name), {
                'fields': Landing.append_lang_fields(code)
            })
        )
        # readonly_fields.append(__('html', code))
        prepopulated_fields[__('url', code)] = (__('title', code),)
admin.site.register(Landing, LandingAdmin)


from django.contrib.auth.admin import UserAdmin
UserAdmin.filter_horizontal = ('user_permissions', 'groups')
