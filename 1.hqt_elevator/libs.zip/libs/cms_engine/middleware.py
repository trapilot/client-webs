from importlib import import_module

from django import http
from django.conf import settings
from django.core import management
from django.core.cache import cache
from django.utils import translation

from cms_engine import defaults
from cms_engine.models import Project


class CmsEngine:
    def __init__(self, get_response):
        self.get_response = get_response
        # One-time configuration and initialization.

    def __call__(self, request):
        # Code to be executed for each request before
        # the view (and later middleware) are called.

        response = self.get_response(request)

        # Code to be executed for each request/response after
        # the view is called.

        return response
        
    def process_request(self, request):
        # We add a functionalized one to clear cache through the url.
        #If we add a ?c=1, the cache is cleared.
        ccache = request.GET.get('c', 0)
        if ccache == '1':
            cache.clear()

        # Added functionality to update base translations
        ttrads = request.GET.get('t', 0)
        if ttrads == '1':
            management.call_command('reload_base_translations', verbosity=0, interactive=False)
            cache.clear()

        # Another parameter that we can receive is the session, through 's'
        # It's important that this is here. An attempt has been made to place it in the cms handler, but it doesn't work.
        if request.GET.get('s') and request.GET.get('s') != 'None':
            engine = import_module(settings.SESSION_ENGINE)
            session_key = request.GET['s']
            request.session = engine.SessionStore(session_key)
            request.session.modified = True

        # Added functionality to update base translations
        if request.GET.get('t', 0) == '1':
            management.call_command('reload_base_translations', verbosity=0, interactive=False)
            cache.clear()
        elif request.GET.get('c', 0) == '1':
            cache.clear()

        # Another parameter that we can receive is the session, through 's'
        # It's important that this is here. An attempt has been made to place it in the cms handler, but it doesn't work.
        if request.GET.get('s') and request.GET.get('s') != 'None':
            engine = import_module(settings.SESSION_ENGINE)
            session_key = request.GET['s']
            request.session = engine.SessionStore(session_key)
            request.session.modified = True

        if getattr(settings, 'CMS_FUTURE', False):
            self.detection_project(request)
            self.detect_language(request)

    def detection_project(self, request):
        u"""
        From the domain of the request, we detect the project it refers to.
        Once we have the domain, we check if it is in the cache.
        Otherwise, we look for it in the model.
        If it still doesn't exist, we return None.

        A second way to detect the project is through its code,
        passed from NGINX in the CMS_CODE_PROJECT attribute.
        """

        code = request.META.get('CMS_CODE_PROJECT')
        if code:
            key = 'project_%s' % code
        else:
            domain, sep, port = request.get_host().rpartition(':')
            if not sep:
                domain = port
            key = 'project_%s' % domain

        project = cache.get(key)
        if not project:
            if code:
                try:
                    project = Project.objects.get(code=code)
                except Project.DoesNotExist:
                    return
            else:
                project = Project.objects.project(domain)
                if not project:
                    return
            project._carga_constantes()
            project._carga_urls_paginas()
            cache.set(key, project)

        request.project = project

    def detect_language(self, request):
        try:
            DETECTION = settings.LANGUAGE_DETECTION
        except AttributeError:
            DETECTION = defaults.LANGUAGE_DETECTION

        # default language
        language = settings.LANGUAGE_CODE

        if DETECTION['TYPE'] == 0:
            # type 0: no detection, always the same language (the one that is defined in the settings)
            pass
        elif DETECTION['TYPE'] == 1:
            # type 1: depends on the prefix used in the subdomain
            # (en.example.com, fr.example.com, etc)
            host = request.META.get('HTTP_HOST')
            if host:
                # if there is no host, it will take the default language
                code = host.split('.', 1)[0]
                if code in defaults.MAPPING_LANGUAGE_CODE:
                    language = code
                else:
                    # We check if the language code is passed through GET
                    lang = request.GET.get('lang', settings.LANGUAGE_CODE)
                    if lang in defaults.MAPPING_LANGUAGE_CODE:
                        # if it is not in the mapping, it will take the default language
                        language = lang
        elif DETECTION['TYPE'] == 2:
            # type 2: depends on the geographic domain (eg: .com, .co.uk, .fr) those domains
            # whose extension does not match the language must be specified
            # (eg en.example.com: 'en', instead of 'es')
            host = request.META.get('HTTP_HOST')
            if host:
                # if there is no host, it will take the default language
                for v, k in defaults.MAPPING_LANGUAGE_DOMAIN.items():
                    if host.endswith(v):
                        language = k
                        break
            if 'FORZAR_DOM' in DETECTION:
                lang = request.GET.get('lang')
                if lang and lang in defaults.MAPPING_LANGUAGE_CODE:
                    language = lang
                else:
                    try:
                        language = DETECTION['FORZAR_DOM'][host]
                    except KeyError:
                        pass
        elif DETECTION['TYPE'] == 3:
            # type 3: we take the language according to the domain that has been put in
            # admin > projects
            host = request.get_host()
            project = getattr(request, 'project', None)
            if host and project:
                for lang in project.languages:
                    country = 'domain_%s' % lang
                    if host == getattr(project, 'domain_%s' % lang):
                        language = lang
                        break

        # Activate the language
        translation.activate(defaults.MAPPING_LANGUAGE_CODE[language])


class Redireccion:
    u"""Middleware for managing redirects."""
    
    def __init__(self, get_response):
        self.get_response = get_response
        # One-time configuration and initialization.

    def __call__(self, request):
        # Code to be executed for each request before
        # the view (and later middleware) are called.

        response = self.get_response(request)

        # Code to be executed for each request/response after
        # the view is called.

        return response
        
    def process_response(self, request, response):
        try:
            project = request.project
        except KeyError:
            return response
        except AttributeError:
            return response

        if not project:
            return response

        cache_key = 'redirects_%s' % project.code
        redirects = cache.get(cache_key)

        # The first time we load the redirects in the cache
        if redirects is None:
            redirects = load_cache_redirections(project)

        url = request.META['REQUEST_URI']
        host = request.META.get('HTTP_HOST')

        try:
            new_url = redirects[url]
        except KeyError:
            if url and host:
                try:
                    new_url = redirects[host + url]
                except KeyError:
                    pass
                else:
                    return self.redirect(new_url)
        else:
            return self.redirect(new_url)

        return response

    def redirect(self, new_url):
        if new_url == '':
            return http.HttpResponseGone()

        return http.HttpResponsePermanentRedirect(new_url)


# We load all urls from cached redirects. We put it here so that this is done once when loading the project.
# If we put it in the __init__, it is loaded every time someone imports the cms_engine
def load_cache_redirections(project):
    redirects = {}
    for redirect in project.redirection_set.all():
        key = redirect.old_url.strip()
        if key.startswith('http'):
            key = key.split('//')[1]
        redirects[key] = redirect.new_url.strip()

    cache_key = 'redirects_%s' % project.code
    cache.set(cache_key, redirects)

    return redirects


class MultipleProxyMiddleware:
    FORWARDED_FOR_FIELDS = [
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_FORWARDED_HOST',
        'HTTP_X_FORWARDED_SERVER',
    ]

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        """
        Rewrites the proxy headers so that only the most
        recent proxy is used.
        """
        for field in self.FORWARDED_FOR_FIELDS:
            if field in request.META:
                if ',' in request.META[field]:
                    parts = request.META[field].split(',')
                    request.META[field] = parts[-1].strip()
        return self.get_response(request)


class P3PHeaderMiddleware(object):
    # Middleware for IE to accept cookies through an iframe

    def process_response(self, request, response):
        P3P_COMPACT = 'policyref="http://www.example.com/p3p.xml", CP="IDC DSP COR ADM DEVi TAIi PSA PSD IVAi IVDi CONi HIS OUR IND CNT"'

        response['P3P'] = P3P_COMPACT
        return response
