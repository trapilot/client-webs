import ast
import dateutil

from django.db import models
from django.conf import settings
from django.core.cache import cache
from django.contrib.auth.models import User
from django.template.defaultfilters import slugify
from django.utils import translation
from django.utils.html import strip_tags
from django.utils.regex_helper import normalize
from django.utils.safestring import mark_safe
from django.utils.translation import gettext_lazy as _

from ckeditor.fields import RichTextField
from sorl.thumbnail import ImageField
from smart_selects.db_fields import ChainedForeignKey

from cms_engine import defaults
from cms_engine.managers import PageManager, ProjectManager
from cms_engine.utils import default_project_code
from shared_engine.managers import BackgroundManager, EnumActiveChoice
from shared_engine.transmeta import get_real_language, TransMeta


default_language = get_real_language(settings.LANGUAGE_CODE)
current_language = get_real_language(translation.get_language())

class ViewNotExists(Exception):
    pass


class Project(models.Model, metaclass=TransMeta):
    PROJECT_TYPES = (
        ('BLOG', _(u'BLOG')),
        ('ECOMMERCE', _(u'ECOMMERCE')),
        ('RESTAURANT', _(u'RESTAURANT')),
    )

    DOMAIN_TYPES = [
        (0, _('Auto')),
        (1, _('Prefix in subdomain')),
        (2, _('Geographic domain')),
        (3, _('Multipal Domains')),
    ]

    objects = ProjectManager()

    code = models.CharField(_(u'Code'), max_length=50, unique=True)
    name = models.CharField(_(u'Name'), max_length=100)
    type = models.CharField(_(u'Type'), max_length=50, choices=PROJECT_TYPES, default='BLOG')
    slogan = models.CharField(_(u"Slogan"), max_length=150, blank=True, null=True)
    language_text = models.CharField(_(u'Languages'), max_length=50, default='%s' % (default_language))
    language_type = models.IntegerField(_(u'Domain Type'), choices=DOMAIN_TYPES, default=0)
    domain = models.CharField(
        _(u'Domain'), max_length=80, default='',
        help_text=_(u'Domain for each language. If the project works with language folders, always put the same domain. Do not add the port.'),
    )
    is_ssl = models.BooleanField(
        _(u'SSL'), blank=True, null=True, default=False,
        help_text=_(u'Indicate the domain that listens to the project under ssl'),
    )
    sitemap_extension = models.CharField(
        _(u'Extension sitemap'), max_length=150, blank=True, null=True, default='',
        help_text=_(u'Returns a list of UrlSitemap objects that are added to the default sitemap.'),
    )
    extra_robots = models.TextField(
        _(u'Extra robots'), blank=True, null=True, default='',
        help_text=_(u'The cms itself already has a default robots, but if we want to add extra rules, they can be added here.'),
    )

    image404 = ImageField(
        _(u'Image 404'), blank=True, null=True,
        upload_to='uploads/cms/project',
        help_text=_(u'Image that will be seen on the 404 error page of the project.'),
    )
    imageLogo = ImageField(
        _(u'Image logo'), blank=True, null=True,
        upload_to='uploads/cms/project',
        help_text=_(u'Image logo of the project.'),
    )
    imageFavicon = ImageField(
        _(u'Image favicon'), blank=True, null=True,
        upload_to='uploads/cms/project',
        help_text=_(u'Image favicon of the project.'),
    )

    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='user_created', null=True, blank=True)
    updated_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='user_updated', null=True, blank=True)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Website Setting')
        verbose_name_plural = _(u'Website Settings')
        translate = ('domain', 'slogan',)
        translate_inline = ('domain', 'slogan',)
        ordering = ('name',)

    def __str__(self):
        return self.name

    @property
    def pages(self):
        u"""
        We return a dictionary with the project pages,
        whose key is the page code. We keep this dictionary in the object itself,
        so we save ourselves a query next time.
        """
        if not hasattr(self, '_cache_pages'):
            pages = {}
            for page in self.page_set.filter(is_active=True).order_by('top_menu_row', 'top_menu_col', 'sub_menu_row', 'sub_menu_col'):
                pages[page.code] = page
            self._cache_pages = pages
        return self._cache_pages

    @property
    def nested_pages(self):
        u"""
        We return a list with the project pages ordered in preorder.
        We will use it to create the sitemap as a tree listing page
        """
        if not hasattr(self, '_cache_nested_pages'):
            pages = self.page_set.filter(is_active=True, parent=None)
            preorder_list_pages = self._preorder_pages(pages)
            self._cache_nested_pages = preorder_list_pages
        return self._cache_nested_pages

    def _preorder_pages(self, pages, list=[]):
        u"""
        Build a list from a preorder traversal of the page tree.
        """
        for page in pages:
            list.append(page)
            page_childs = page.nested_set.filter(is_active=True)
            self._preorder_pages(page_childs, list)
        return list

    @property
    def home_page(self):
        for page in self.pages.values():
            if page.is_home:
                return page
        return None

    @property
    def navigation(self):
        u"""
        We return the pages that fall within the navigation.
        """
        nav = []
        for page in self.pages.values():
            if page.is_top_menu or page.is_sub_menu:
                nav.append(page)
        return sorted(nav, key=lambda page: page.top_menu_col + page.sub_menu_col)

    @property
    def navigation_primary(self):
        u"""
        We return the top navigation pages.
        """
        nav = []
        for page in self.pages.values():
            if page.is_top_menu:
                nav.append(page)
        return sorted(nav, key=lambda page: page.top_menu_col)

    @property
    def navigation_second(self):
        u"""
        We return the top navigation pages.
        """
        nav = []
        for page in self.pages.values():
            if page.is_sub_menu:
                nav.append(page)
        return sorted(nav, key=lambda page: page.sub_menu_col)

    # @property
    # def navigation_hotel(self):
        # u"""
        # We return the hotel navigation pages of a corporate
        # """
        # nav = []
        # for page in self.pages.values():
            # if page.code.startswith('hotel_'):
                # nav.append(page)
        # return sorted(nav, key=lambda page: page.top_menu_col + page.sub_menu_col)

    @property
    def languages(self):
        u"""
        We return a list with the active languages of the project.
        """
        languages = self.language_text.split(',')
        valid_languages = []
        for language in languages:
            if language != '':
                valid_languages.append(language)
        return valid_languages

    @property
    def languages_dict(self):
        u"""
        Returns a dictionary with the active languages, as key there is the language code,
        and as value the name/description of the language
        """
        languages = {}
        for language in self.languages:
            languages[language] = defaults.LANGUAGE_TRADS[language]
        return languages

    def _load_constants(self):
        u"""
        We load all the constants of the project and save them
        in the __dict__ itself, as if it were one more attribute of the object
        """
        for constant in self.constant_set.all():
            try:
                self.__dict__[constant.name] = constant.type_value
            except Exception:
                pass
        self._constant_loaded = True

    def constant(self, key, default=None):
        u"""
        Constants can be accessed through the __getter__
        of the object, that is by doing object.constant_name.
        But if, for example, we are interested in returning the constant,
        but if it does not exist, return the default.

        Example: project.constant('motor_plus', False)
        """
        # Check necessary because the _load_constants is only
        # called when saving a project or when going through
        # the cms_engine.handler. This excludes any url served through a urls.py
        if not hasattr(self, '_constant_loaded'):
            self._load_constants()
        if not hasattr(self, key):
            return default
        return self.__dict__[key]

    def _load_page_urls(self, auto_detect=True):
        u"""
        We load the dictionary where with all the pages of the project,
        where the key is the regular expression of the url, and the value, the page object.
        We save this dictionary in the object itself, in the urls_pages attribute
        """
        self.page_urls = []
        pages = self.page_set.filter(is_active=True).order_by('reversed_as')
        for page in pages:
            if auto_detect:
                for language in self.languages:
                    group = (default_language == language) # is default language
                    self.page_urls.append(
                        (page.pattern_url(expresion_r=True, language=language, group=group), page, language)
                    )
            else:
                self.page_urls.append(
                    (page.pattern_url(expresion_r=True), page, current_language)
                )

    def page(self, name):
        u"""
        Returns a project page, as long as the _pages have loaded
        """
        try:
            return self.pages[name]
        except KeyError:
            return None
        
    @property
    def branches(self):
        if not hasattr(self, '_cache_branches'):
            self._cache_branches = self.branch_set.all()
        return self._cache_branches
    
    @property
    def branch(self):
        return (
            self.branches.filter(is_default=True).first()
            or self.branches.first()
        )


    @property
    def marketing_claims(self):
        if not hasattr(self, '_marketing_claims'):
            self._marketing_claims = self.marketing_claim_set.all()
        return self._marketing_claims

    @property
    def social_networks(self):
        if not hasattr(self, '_social_networks'):
            self._social_networks = self.social_network_set.all()
        return self._social_networks

    @property
    def operating_hours(self):
        if not hasattr(self, '_operating_hours'):
            self._operating_hours = self.operating_hour_set.all()
        return self._operating_hours

    @property
    def operating_days(self):
        days = []
        grouped = []
        current_group = []
        operating_hours = self.operating_hours.order_by('weekday')

        for hour in operating_hours:
            if not current_group:
                current_group.append(hour)
                continue
            prev = current_group[-1]

            same_hours = (
                hour.hour_from == prev.hour_from and
                hour.hour_to == prev.hour_to
            )

            if same_hours:
                current_group.append(hour)
            else:
                grouped.append(current_group)
                current_group = [hour]

        if current_group:
            grouped.append(current_group)

        # build grouped days
        for group in grouped:
            first = group[0]
            last = group[-1]

            # label
            if len(group) == 1:
                label = first.get_weekday_display()
            else:
                label = '%s-%s' % (
                    first.get_weekday_display(),
                    last.get_weekday_display()
                )

            # hours
            if first.hour_from and first.hour_to:
                hours = '%s - %s' % (
                    first.hour_from.strftime('%H:%M'),
                    first.hour_to.strftime('%H:%M')
                )
            else:
                hours = _('Closed')

            days.append({
                'label': label,
                'closed': False,
                'day_number': first.weekday,
                'hour_from': first.hour_from,
                'hour_to': first.hour_to,
                'hour_text': hours
            })

        # closed days
        open_days = [hour.weekday for hour in operating_hours]
        for day_number, day_name in OperatingHour.WEEKDAYS:
            if day_number not in open_days:
                days.append({
                    'label': day_name,
                    'closed': True,
                    'day_number': day_number,
                    'hour_from': None,
                    'hour_to': None,
                    'hour_text': _('Closed')
                })

        days = sorted(days, key=lambda k: k['day_number'])

        return days
    
    @property
    def phone(self):
        try:
            return self.branch.phone
        except:
            return None

    @property
    def phones(self):
        return list({
            branch.phone for branch in self.branches if branch.phone
        })

    @property
    def fax(self):
        try:
            return self.branch.fax
        except:
            return None

    @property
    def faxes(self):
        return list({
            branch.fax for branch in self.branches if branch.fax
        })

    @property
    def email(self):
        try:
            return self.branch.email
        except:
            return None

    @property
    def emails(self):
        return list({
            branch.fax for branch in self.branches if branch.email
        })

    @property
    def address(self):
        try:
            return self.branch.address
        except:
            return None

    @property
    def addresses(self):
        return list({
            branch.address for branch in self.branches if branch.address
        })

    @property
    def location(self):
        try:
            return {
                'lat': self.branch.geolat,
                'lng': self.branch.geolng,
                'zoom': self.branch.geozm,
            }
        except:
            return None

    @property
    def locations(self):
        return list({
            {
                'lat': branch.geolat,
                'lng': branch.geolng,
                'zoom': branch.geozm,
            }
            for branch in self.branches
            if branch.geolat and branch.geolng and branch.geozm
        })


class Branch(models.Model, metaclass=TransMeta):
    project = models.ForeignKey(
        Project,
        on_delete=models.CASCADE,
        default=default_project_code,
        related_name='branch_set',
        verbose_name=_(u'Project'),
    )
    name = models.CharField(_(u'Name'), max_length=150)
    address = models.CharField(_(u'Address'), blank=True, null=True, max_length=250)
    description = models.TextField(_(u'Description'), blank=True, null=True)
    email = models.CharField(_(u'Email'), max_length=100, null=True, blank=True)
    phone = models.CharField(_(u'Phone'), blank=True, null=True, max_length=30)
    fax = models.CharField(_(u'Fax'), max_length=100, null=True, blank=True)
    geolat =models.CharField(_(u'Latitude'), blank=True, null=True, max_length=50)
    geolng = models.CharField(_(u'Longitude'), blank=True, null=True, max_length=50)
    geozm = models.CharField(_(u'Zoom'), blank=True, null=True, max_length=10)
    logo = models.ImageField(_(u'Logo'), null=True, blank=True, upload_to='uploads/cms/branch/logos/')
    icon = models.CharField(_(u'Icon'), blank=True, null=True, max_length=150)

    sorted_as = models.PositiveIntegerField(_(u'Order'), default=0)
    is_active = models.BooleanField(_(u'Active'), default=True)
    is_default = models.BooleanField(_(u'Default'), default=False)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Branch')
        verbose_name_plural = _(u'Branches')
        translate = ('name', 'address', 'description',)
        ordering = ('is_default', 'sorted_as', '-is_active',)

    def __str__(self):
        return self.name


class MarketingClaim(models.Model, metaclass=TransMeta):
    project = models.ForeignKey(
        Project,
        on_delete=models.CASCADE,
        default=default_project_code,
        related_name='marketing_claim_set',
        verbose_name=_(u'Project'),
    )
    code = models.CharField(_(u'Code'), max_length=10, blank=True, null=True, default='')
    title = models.CharField(_(u'Title'), max_length=100, blank=True, null=True, default='')
    description = models.TextField(_(u'Description'), blank=True, null=True)
    icon = ImageField(_(u'Icon'), blank=True, null=True, upload_to='uploads/cms/marketing-claims')
    page_code = models.CharField(
        _(u'page code'), max_length=25, blank=True, null=True,
        help_text=_(u'Optional field. Useful if we want an image to have a link to a project page.'),
    )
    link = models.URLField(_(u'Link'), max_length=250, blank=True, null=True)
    link_text = models.CharField(_(u'Link text'), default='', max_length=50, blank=True, null=True)

    sorted_as = models.PositiveIntegerField(_(u'Order'), default=0)
    is_active = models.BooleanField(_(u'Active'), default=True)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Marketing claim')
        verbose_name_plural = _(u'Marketing claims')
        translate = ('title', 'description', 'link', 'link_text',)
        ordering = ('sorted_as', '-is_active',)

    def __str__(self):
        return '(%s)' % (self.code)


class SocialNetwork(models.Model, metaclass=TransMeta):
    project = models.ForeignKey(
        Project,
        on_delete=models.CASCADE,
        default=default_project_code,
        related_name='social_network_set',
        verbose_name=_(u'Project'),
    )
    name = models.CharField(_(u'Name'), max_length=30)
    url = models.URLField(_(u'Url'), max_length=200, blank=True, null=True)
    icon = models.CharField(_(u'Icon'), max_length=5, blank=True, null=True)
    code = models.CharField(
        _(u'Code'), max_length=30,
        help_text=mark_safe("<a target='_blank' href='https://fontawesome.com/search?o=r&f=brands'>https://fontawesome.com/search?o=r&f=brands</a>"),
    )

    is_active = models.BooleanField(_(u'Activate'), default=True)
    sorted_as = models.PositiveIntegerField(_(u'Order'), default=0)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Social network')
        verbose_name_plural = _(u'Social networks')
        # translate = ('name',)
        ordering = ('sorted_as', '-is_active',)

    def __str__(self):
        return '(%s)' % (self.name)
    

class OperatingHour(models.Model, metaclass=TransMeta):
    WEEKDAYS = [
      (1, _('Monday')),
      (2, _('Tuesday')),
      (3, _('Wednesday')),
      (4, _('Thursday')),
      (5, _('Friday')),
      (6, _('Saturday')),
      (7, _('Sunday')),
    ]
    
    project = models.ForeignKey(
        Project,
        on_delete=models.CASCADE,
        default=default_project_code,
        related_name='operating_hour_set',
        verbose_name=_(u'Project'),
    )
    weekday = models.IntegerField(choices=WEEKDAYS)
    hour_from = models.TimeField(_(u'From Hour'))
    hour_to = models.TimeField(_(u'To Hour'))
    
    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Operating hour')
        verbose_name_plural = _(u'Operating hours')
        ordering = ('weekday', 'hour_from')
        unique_together = ('weekday', 'hour_from', 'hour_to')

    def __str__(self):
        return u'%s: %s - %s' % (self.get_weekday_display(), self.hour_from, self.hour_to)


class Constant(models.Model):
    TYPES = (
        ('STR', _(u'STRING')),
        ('INT', _(u'INTEGER')),
        ('LIST', _(u'LIST')),
        ('DICT', _(u'DICTIONARY')),
        ('BOOL', _(u'BOOLEAN')),
        ('DATE', _(u'DATETIME')),
    )

    OK_VALUES = frozenset(('ok', 'activated', 'yes', 'on', 'true', 'real', '1'))

    project = models.ForeignKey(
        Project,
        on_delete=models.CASCADE,
        default=default_project_code,
        related_name='constant_set',
        verbose_name=_(u'Project'),
    )
    name = models.CharField(
        _(u'Name'), max_length=30,
        help_text=_(u'Lowercase. As if it were an attribute of the project itself. It is accessed with a project __get__.'),
    )
    type = models.CharField(_(u'Type'), max_length=10, choices=TYPES, default='STR')
    type_value = models.TextField(_(u'Value'), blank=True, null=True,)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Constant')
        verbose_name_plural = _(u'Constants')

    def __str__(self):
        return '%s-%s' % (self.project.code, self.name)

    @property
    def value(self):
        u"""
        We return the type_value, but with the type specified in the model.
        For example, if the constant is a boolean and has a value of 1, we return a True
        """
        if self.type == 'STR':
            return self.type_value
        elif self.type == 'INT':
            return int(self.type_value, 10)
        elif self.type in ('LIST', 'DICT'):
            return ast.literal_eval(self.type_value)
        elif self.type == 'BOOL':
            try:
                return bool(int(self.type_value))
            except ValueError:
                return self.type_value in self.OK_VALUES
        elif self.type == 'DATE':
            return dateutil.parser.parse(self.type_value)
        else:
            return None


class Page(models.Model, metaclass=TransMeta):
    objects = PageManager()

    project = models.ForeignKey(
        Project,
        on_delete=models.CASCADE,
        default=default_project_code,
        related_name='page_set',
        verbose_name=_(u'Project'),
    )
    parent = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name='nested_set',
        verbose_name=_(u'Parent'),
        help_text=_(u'Parent page. It is used to create nested lists in the sitemap'),
    )
    code = models.CharField(
        _(u'Code'), max_length=25,
        help_text=_(u'Identifier code of the page. It is usually a text string, written in lowercase'),
    )
    icon = ImageField(_(u'Icon'), blank=True, null=True, upload_to='uploads/cms/icons')
    is_active = models.BooleanField(_(u'Active'), default=False)
    is_index = models.BooleanField(_(u'Index'), default=True)
    is_follow = models.BooleanField(_(u'Follow'), default=True)
    is_external = models.BooleanField(
        _(u'External'), default=False,
        help_text=_(u'Indicates if the link on this page redirects to an external website'),
    )
    is_internal = models.BooleanField(
        _(u'Internal'), default=False,
        help_text=_(u'Indicates if the link on this page link to an internal articles'),
    )
    is_ssl = models.BooleanField(
        _(u'SSL'), default=False,
        help_text=_(u'Indicates if this page use https'),
    )

    is_home = models.BooleanField(_(u'Home'), default=False, help_text=_(u'Indicates if this page is the home'))
    is_top_menu = models.BooleanField(_('Top Menu'), default=False)
    is_sub_menu = models.BooleanField(_('Sub Menu'), default=False)

    top_menu_row = models.IntegerField(_('Menu Row'), blank=True, null=True, default=0)
    top_menu_col = models.IntegerField(_('Menu Column'), blank=True, null=True, default=0)
    sub_menu_row = models.IntegerField(_('Menu Row'), blank=True, null=True, default=0)
    sub_menu_col = models.IntegerField(_('Menu Column'), blank=True, null=True, default=0)

    reversed_as = models.IntegerField(_(u'Order Url'), default=0, help_text=_(u'Order for when a url-reverse is done'))
    name = models.CharField(_(u'Name'), max_length=150, default='')
    url = models.CharField(
        _(u'Url'), max_length=150, blank=True, null=True,
        help_text=_(u'If no URL is specified, it is built from the page name plus the .htm extension. Otherwise, add the full regular expression.'),
    )
    meta_title = models.CharField(_(u'Meta title'), max_length=255, blank=True, null=True)
    meta_description = models.CharField(_(u'Meta description'), max_length=255, blank=True, null=True)
    meta_keywords = models.CharField(_(u'Meta keywords'), max_length=255, blank=True, null=True)
    meta_card = models.CharField(_(u'Meta card'), max_length=255, blank=True, null=True)
    meta_image = models.CharField(_(u'Meta image'), max_length=255, blank=True, null=True)
    content = RichTextField(_(u'Content'), blank=True, null=True)
    view = models.CharField(
        _(u'View'), max_length=150, default="CmsEngineView.as_view(template_name='home.html')", # default="CmsEngineView.as_view(template_name='%s/home.html')" % default_project_code,
        help_text=_(u'By default we use the generic views of the CMS, but it can be replaced by any other.'),
    )
    context = models.CharField(
        _(u'Context'), max_length=100, default='', blank=True, null=True,
        help_text=_(u'A method that returns a dictionary can be specified to pass a custom context to your view.'),
    )
    cache_context = models.BooleanField(
        _(u'Cache context'), default=False,
        help_text=_(u'If enabled, the system will automatically cache the entire context to save time.'),
    )

    # H...
    h1 = models.CharField(_(u'H1'), max_length=255, blank=True, null=True, default='')
    h2 = models.CharField(_(u'H2'), max_length=255, blank=True, null=True, default='')
    h3 = models.CharField(_(u'H3'), max_length=255, blank=True, null=True, default='')

    # Sitemap
    FREQUENCIES = (
        ('always', _(u'always')),
        ('hourly', _(u'hourly')),
        ('daily', _(u'daily')),
        ('weekly', _(u'weekly')),
        ('monthly', _(u'monthly')),
        ('yearly', _(u'yearly')),
        ('never', _(u'never')),
    )
    PRIORITIES = (
        ('0.1', '0.1'),
        ('0.2', '0.2'),
        ('0.3', '0.3'),
        ('0.4', '0.4'),
        ('0.5', '0.5'),
        ('0.6', '0.6'),
        ('0.7', '0.7'),
        ('0.8', '0.8'),
        ('0.9', '0.9'),
        ('1.0', '1.0'),
    )
    changefreq = models.CharField(_(u'Frequency'), max_length=10, default='monthly', choices=FREQUENCIES)
    priority = models.CharField(_(u'Priority'), max_length=4, default='0.5', choices=PRIORITIES)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Content Page')
        verbose_name_plural = _(u'Content Pages')
        translate = (
            'name', 'meta_title', 'meta_description', 'meta_keywords',
            'url', 'content', 'h1', 'h2', 'h3',
        )
        ordering = (
            'project','parent_id', '-is_active', '-is_home',
            '-is_top_menu', 'top_menu_row', 'top_menu_col',
            '-is_sub_menu', 'sub_menu_row', 'sub_menu_col',
        )

    def __str__(self):
        if self.parent:
            return '%s => %s' %(self.parent, self.name)
        return self.name

    
    @property
    def banners(self):
        if not hasattr(self, '_cache_banners'):
            self._cache_banners = self.banner_set.is_activated()
        return self._cache_banners
    
    @property
    def sliders(self):
        return self.banners.filter(type=Banner.BannerType.SLIDER)
    
    @property
    def popups(self):
        return self.banners.filter(type=Banner.BannerType.POPUP)
    
    @property
    def promos(self):
        return self.banners.filter(type=Banner.BannerType.PROMO)
    
    @property
    def background(self):
        return self.banners.filter(type=Banner.BannerType.HERO).first()
    
    @property
    def robots(self):
        return "%s,%s" % (
            "index" if self.is_index else "noindex",
            "follow" if self.is_follow else "nofollow",
        )
    
    @property
    def level(self):
        u"""
        Returns the nesting level of the page
        """
        if not self.parent:
            return 0
        return 1 + self.parent.level
    
    @property
    def nested_pages(self):
        return self.nested_set.filter(is_active=True)

    @property
    def view_callback(self):
        u"""
        Returns the view object
        """
        def _return_view_path(view):
            u"""
            Data a view url of the type
                project.apps.views.View.as_view(...)
            we return the project.apps.views
            """
            routes = []
            for item in view.split('.'):
                routes.append(item)
                if item == 'views':
                    break
            return '.'.join(routes)

        def _return_views(view):
            u"""
            Given project.apps.views.View.as_view(...), we return the View
            """
            parts = view.split('.')
            return [parts[parts.index('views')+1]]

        def _return_asview(view):
            u"""
            We return the as_view
            """
            return view[view.find('.as_view'):]

        view_exc = {}
        try:
            exec('view = %s' % self.view, globals(), view_exc)
        except NameError:
            # We must perform the import of the object.
            module = __import__(
                _return_view_path(self.view),
                fromlist=_return_views(self.view)
            )

            try:
                view_exc['view'] = getattr(module, _return_views(self.view)[0])
            except AttributeError:
                raise ViewNotExists(_(u'There is no view: %s') % self.view)

            exec('view = view%s' % _return_asview(self.view), globals(), view_exc)

        return view_exc['view']
    
    def pattern_url(self, language=False, expresion_r=True, group=True, domain='', reversed=False):
        u"""
        We return the pattern of the url. This can be used in the construction
        of the urls dispatcher, or to have the url when building the sitemap.
        """
        if not language:
            language = translation.get_language().split('-')[0]

        url = getattr(self, 'url_' + language)

        # First we check if we have the url, if not, we build it with
        # the page name slug
        if not url:
            # we remove the html tags from the name before getting the slug
            name = getattr(self, 'name_' + language)
            name = strip_tags(name)
            url = slugify(name) + '.htm'

        # The pattern of the home page differs from that of the other pages
        if getattr(settings, 'CMS_FUTURE', False):
            pattern = domain + url
        else:
            pattern = domain + ('' if (self.is_home and group) else url)

        if self.is_internal and not reversed and not self.is_home:
            # pattern = pattern + '(?P<pk>\d+/?)?'
            if '<slug>' not in pattern or '(?P<slug>' not in pattern:
                pattern = pattern + r'(?P<pk>\d+/?)?'

        if expresion_r and not '^' in pattern:
            pattern = r'^' + pattern + '$'

        return pattern

    def reverse(self, params=[], language=False, kwargs={}):
        u"""
        We perform the reverse of the url
        """
        if self.is_home:
            return '/'

        # If in the url field there is a complete url, with http, we return this
        if self.url:
            if 'http://' in self.url or 'https://' in self.url:
                return self.url

        urlp, fields = normalize(self.pattern_url(expresion_r=True, language=language, reversed=True))[0]

        subst = dict(zip(fields, params))

        if not len(subst) and len(kwargs):
            subst = kwargs

        try:
            if getattr(settings, 'CMS_FUTURE', False):
                return urlp % subst
            else:
                return '/' + urlp % subst
        except KeyError:
            return '/'

    def save(self, **kwargs):
        u"""
        We verify that the url in the different languages ends in '/', if not, we add it.
        """
        if getattr(settings, 'CMS_FUTURE', False):
            # The new dispatcher delegates a lot of work to the database, so
            # that we need to leave the ground well prepared
            if self.is_home:
                for language_code, n in settings.LANGUAGES:
                    setattr(self, 'url_' + language_code, "/")
            else:
                for language_code, n in settings.LANGUAGES:
                    try:
                        url = getattr(self, 'url_' + language_code).strip()
                    except AttributeError:
                        url = ""
                    if url:
                        if not url.startswith('/'):
                            url = '/' + url
                        if not url.endswith(('.htm', '.html', '/')):
                            url += '/'
                    else:
                        try:
                            name = getattr(self, 'name_' + language_code).strip()
                        except AttributeError:
                            name = ''
                        if name:
                            url = '/%s.htm' % slugify(strip_tags(name))
                    setattr(self, 'url_' + language_code, url)
        else:
            for language_code, _ in settings.LANGUAGES:
                url = getattr(self, 'url_' + language_code)
                if url:
                    if len(url) > 100:
                        raise ValueError(u'URL too long, the CMS cannot be upgraded')
                    if not url.endswith('.htm') and not url.endswith('.html'):
                        setattr(self, 'url_' + language_code, getattr(self, 'url_' + language_code).rstrip('/') + '/')

        super(Page, self).save(**kwargs)



class MetaObject(models.Model, metaclass=TransMeta):
    page = models.ForeignKey(Page, on_delete=models.CASCADE, verbose_name=_(u'Page'))
    object = models.CharField(
        _(u'Object'), max_length=25,
        help_text=_(u'Name of the object that is passed in the context of the page'),
    )
    field = models.CharField(_(u'Field'), max_length=25, help_text=_(u'Model field to match the value'))
    value = models.CharField(_(u'Value'), max_length=30)
    meta_title = models.CharField(_(u'Meta title'), max_length=255, blank=True, null=True)
    meta_description = models.CharField(_(u'Meta description'), max_length=255, blank=True, null=True)
    meta_keywords = models.CharField(_(u'Meta keywords'), max_length=255, blank=True, null=True)

    class Meta:
        verbose_name = _(u'Meta object')
        verbose_name_plural = _(u'Meta objects')
        translate = ('meta_title', 'meta_description', 'meta_keywords',)


class Translation(models.Model, metaclass=TransMeta):
    project = models.ForeignKey(
        Project,
        on_delete=models.CASCADE,
        default=default_project_code,
        related_name='translation_set',
        blank=True,
        null=True,
        verbose_name=_(u'Project'),
        help_text=_(u'If a project is specified, common for all pages of the project'),
    )
    page = ChainedForeignKey(
        Page,
        on_delete=models.CASCADE,
        related_name='translation_set',
        chained_field='project',
        chained_model_field='project',
        verbose_name=_(u'Page'),
        show_all=False,
        auto_choose=False,
        blank=True,
        null=True,
        help_text=_(u'If a page is specified, only for the specified page'),
    )
    identifier = models.TextField(_(u'Identifier'))
    value = models.TextField(_(u'Value'), blank=True, null=True, default='')
    exists = models.BooleanField(
        _(u'Exists'), default=True,
        help_text=_(u'Indicates if the translation exists in any of the templates. There is a command that performs this check.'),
    )

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Language Translation')
        verbose_name_plural = _(u'Language Translations')
        translate = ('value',)

    def __str__(self):
        return self.identifier

    def clear_cache(self):
        u"""
        We remove this translation from the cache so that it will be generated again next time
        """
        try:
            project = self.project if self.project else self.page.project
            cache_key = 'cache_translations_%s' % (project.code)
            cache_data = cache.get(cache_key)
            if cache_data:
                try:
                    del cache_data[self.identifier]
                except KeyError:
                    pass
                else:
                    cache.set(cache_key, cache_data)
        except:
            pass


class Redirection(models.Model):
    project = models.ForeignKey(
        Project,
        on_delete=models.CASCADE,
        default=default_project_code,
        related_name='redirection_set',
        verbose_name=_(u'Project'),
    )
    old_url = models.CharField(
        _(u'Url old'), max_length=200,
        help_text=_(u'Without the domain name. Only from the domain name. For example: /reviews.htm')
    )
    new_url = models.CharField(
        _(u'Url new'), max_length=200,
        help_text=_(u'The complete url, with the domain, where it will be redirected. If this field is blank, the system does a 410 redirect (Gone away)'),
    )

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'URL Redirect')
        verbose_name_plural = _(u'URL Redirects')

    def __str__(self):
        return "%s ---> %s" % (self.old_url, self.new_url)


class Landing(models.Model, metaclass=TransMeta):
    project = models.ForeignKey(
        Project,
        on_delete=models.CASCADE,
        default=default_project_code,
        verbose_name=u'Project',
        related_name='landing_set',
    )
    
    url = models.SlugField(u'Url')
    logo = ImageField(u'Logo',upload_to='uploads/cms/landing', null=True, blank=True)
    backgroud_header = ImageField(u'Header background',upload_to='uploads/cms/landing/headers')
    backgroud_footer = ImageField(u'Footer background',upload_to='uploads/cms/landing/footers', null=True, blank=True)
    title = models.CharField(u'Title', max_length = 200)
    subtitle = models.CharField(u'Sub-Title', max_length=150, null=True, blank=True)
    link = models.URLField(u"Link button", null=True, blank=True)
    link_text = models.CharField(u'Link text', max_length = 200,  default='Read more', help_text=u'Translation: Read more')
    html = RichTextField(u'Content', blank = True, null=True)
    taxes = models.CharField(u'taxes', max_length = 200, default='Taxes', help_text=u'Translation: Taxes')
    click = models.CharField(u'Text click', max_length = 200,  default='Click here', help_text=u'Translation: Click here')
    policies = models.CharField(u'Political text', max_length = 200,  default='See privacy policies', help_text=u'Translation: See privacy policies')
    unsubscribe = models.CharField(u'Unsubscribe text', max_length = 200,  default='Unsubscribe', help_text=u'Translation: Unsubscribe')
    concerns = models.CharField(u'Text concerns', max_length = 200,  default='If you have concerns', help_text=u'Translation: If you have concerns')
    header = models.CharField(u'Header text', max_length = 200,  default='If you can\'t read this e-mail', help_text=u'Translation: if you can\'t read this e-mail')
    specials = models.CharField(u'Special offers', max_length = 200,  default='Special offers', help_text=u'Translation: Special offers')

    is_active = models.BooleanField(_(u'Active'), default = True)

    published_from = models.DateTimeField(u'Available From', null=True, blank=True)
    published_to = models.DateTimeField(u'Available To', null=True, blank=True)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = u'Landing Page'
        verbose_name_plural = u'Landing Pages'
        translate = (
            'url', 'title', 'subtitle', 'link', 'link_text', 'html', 'taxes', 'click', 'policies',
            'unsubscribe', 'concerns', 'header', 'specials'
        )

    def __str__(self):
        return self.title


class Banner(models.Model, metaclass=TransMeta):
    objects = BackgroundManager()
    
    class BannerType(models.IntegerChoices):
        HERO = 1, _(u"Hero")
        POPUP = 2, _(u"Popup")
        SLIDER = 3, _(u"Slider")
        PROMO = 4, _(u"Promo")

    project = models.ForeignKey(
        Project,
        on_delete=models.CASCADE,
        default=default_project_code,
        related_name='banner_set',
        blank=True,
        null=True,
        verbose_name=_(u'Project'),
        help_text=_(u'If a project is specified, common for all banners of the project'),
    )
    page = ChainedForeignKey(
        Page,
        on_delete=models.CASCADE,
        related_name='banner_set',
        chained_field='project',
        chained_model_field='project',
        verbose_name=_(u'Page'),
        show_all=False,
        auto_choose=False,
        blank=True,
        null=True,
        help_text=_(u'If a page is specified, only for the specified page'),
    )

    type = models.IntegerField(_(u'Type'), max_length=20, choices=BannerType.choices)
    status = models.BooleanField(_(u'Status'), default=True)
    image = ImageField(_(u'Image'), null=True, blank=True, upload_to='uploads/cms/banners/images/')
    video = models.FileField(_(u'Video'), null=True, blank=True, upload_to='uploads/cms/banners/videos')
    title = models.CharField(_(u'Title'), max_length=255, blank=True, null=True)
    heading = models.CharField(_(u'Heading'), max_length=255, blank=True, null=True)
    subheading = models.TextField(_(u'Sub Heading'), blank=True, null=True)
    button_text = models.CharField(_(u'Button Text'), max_length=100, blank=True, null=True)
    button_link = models.CharField(_(u'Button Link'), max_length=255, blank=True, null=True)
    description = models.TextField(_(u'Description'), blank=True, null=True)

    published_at = models.DateTimeField(u'Available From', null=True, blank=True)
    unpublished_at = models.DateTimeField(u'Available To', null=True, blank=True)

    sorted_as = models.PositiveIntegerField(_(u'Order'), default=0)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Banner')
        verbose_name_plural = _(u'Banners')
        translate = ('status', 'image', 'video', 'title', 'heading', 'subheading', 'description', 'button_text', 'button_link',)
        ordering = ('sorted_as', 'created_at')

    def __str__(self):
        return f"{self.type} - {self.title}"
    

# DO NOT REMOVE: CmsEngineView is used indirectly,
# for example in the _return_views methods
from cms_engine.views import CmsEngineView
from cms_engine.signals import *
