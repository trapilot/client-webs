import os

from django.core.cache import cache
from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver

from cms_engine.models import (
    Site,
    Constant,
    Translation,
    Redirection,
    Page,
    Banner,
)


def delete_file(path):
    try:
        os.remove(path)
    except OSError:
        pass


@receiver(post_delete, sender=Banner)
def post_delete_image(sender, instance=None, **kwargs):
    if instance.image:
        delete_file(instance.image.path)
    if instance.video:
        delete_file(instance.video.path)


@receiver(post_save, sender=Constant)
def post_save_constant(sender, instance, created=None, **kwargs):
    u"""
    When a constant is modified, we must load it back into the site and update the cache.
    """
    if kwargs['raw']:
        return
    site = instance.site

    cache_key = 'cache_site_code__%s' % site.code
    if cache.get(cache_key):
        site._load_constants()
        cache.set(cache_key, site)


@receiver(post_save, sender=Translation)
def post_save_translation(sender, instance, created=None, **kwargs):
    if kwargs['raw']:
        return
    instance.clear_cache()


@receiver(post_delete, sender=Translation)
def post_delete_translation(sender, instance, **kwargs):
    instance.clear_cache()


@receiver(post_save, sender=Redirection)
def post_save_redirection(sender, instance, created=None, **kwargs):
    instance.clear_cache()


@receiver(post_save, sender=Page)
def post_save_page(sender, instance, created=None, **kwargs):
    if kwargs['raw']:
        return
    cache.clear()

@receiver(post_save, sender=Site)
def post_save_site(sender, instance, created=None, **kwargs):
    if kwargs['raw']:
        return
    cache.clear()

