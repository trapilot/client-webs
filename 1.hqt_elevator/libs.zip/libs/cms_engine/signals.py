import os

from django.core.cache import cache
from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver

from cms_engine.models import (
    Constant,
    Translation,
    Redirection,
    Page
)


def delete_file(path):
    try:
        os.remove(path)
    except OSError:
        pass


@receiver(post_save, sender=Constant)
def post_save_constant(sender, instance, created=None, **kwargs):
    u"""
    When a constant is modified, we must load it back into the project and update the cache.
    """
    if kwargs['raw']:
        return
    project = instance.project
    project._load_constants()

    cache_key = 'project_%s' % project.code
    cache.set(cache_key, project)


@receiver(post_save, sender=Translation)
def post_save_translation(sender, instance, created=None, **kwargs):
    if kwargs['raw']:
        return
    instance.clear_cache()


@receiver(post_delete, sender=Translation)
def post_delete_translation(sender, instance, **kwargs):
    instance.clear_cache()


@receiver(post_save, sender=Redirection)
def post_save_redirection(sender, instance, created=None, **kwargs):
    from cms_engine.middleware import load_cache_redirections

    load_cache_redirections(instance.project)


@receiver(post_save, sender=Page)
def post_save_pagina(sender, instance, created=None, **kwargs):
    if kwargs['raw']:
        return
    cache.clear()


# @receiver(post_delete, sender=Image)
# def post_delete_image(sender, instance=None, **kwargs):
#     if instance.image:
#         delete_file(instance.image.path)


# @receiver(post_delete, sender=ImagenExtra)
# def post_delete_image_extra(sender, instance=None, **kwargs):
#     if instance.image:
#         delete_file(instance.image.path)


# @receiver(post_delete, sender=Archivo)
# def post_delete_archivo(sender, instance=None, **kwargs):
#     if instance.archivo:
#         delete_file(instance.archivo.path)
