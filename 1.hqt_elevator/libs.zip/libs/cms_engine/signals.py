import os

from django.core.cache import cache
from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver

from cms_engine.models import (
    Project,
    Constant,
    Translation,
    Redirection,
    Page,
    Banner,
)


def delete_file(path):
    try:
        os.remove(path)
    except OSError:
        pass


@receiver(post_delete, sender=Banner)
def post_delete_image(sender, instance=None, **kwargs):
    if instance.image:
        delete_file(instance.image.path)
    if instance.video:
        delete_file(instance.video.path)


@receiver(post_save, sender=Constant)
def post_save_constant(sender, instance, created=None, **kwargs):
    u"""
    When a constant is modified, we must load it back into the project and update the cache.
    """
    if kwargs['raw']:
        return
    project = instance.project

    cache_key = 'project_code_%s' % project.code
    if cache.get(cache_key):
        project._load_constants()
        cache.set(cache_key, project)


@receiver(post_save, sender=Translation)
def post_save_translation(sender, instance, created=None, **kwargs):
    if kwargs['raw']:
        return
    instance.clear_cache()


@receiver(post_delete, sender=Translation)
def post_delete_translation(sender, instance, **kwargs):
    instance.clear_cache()


@receiver(post_save, sender=Redirection)
def post_save_redirection(sender, instance, created=None, **kwargs):
    from cms_engine.middleware import load_cache_redirections

    load_cache_redirections(instance.project)


@receiver(post_save, sender=Page)
def post_save_page(sender, instance, created=None, **kwargs):
    if kwargs['raw']:
        return
    cache.clear()

@receiver(post_save, sender=Project)
def post_save_project(sender, instance, created=None, **kwargs):
    if kwargs['raw']:
        return
    cache.clear()

