import os
import csv
import xlwt
import urllib

from django import db
from django import http
from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login, logout
from django.urls import reverse
from django.db.models import Q
from django.template import RequestContext
from django.views.generic.base import TemplateView, RedirectView
from django.views.generic import ListView, FormView, UpdateView, CreateView
from django.utils.translation import gettext_lazy as _

#from cms_engine.backoffice import defaults
from cms_engine.backoffice.forms import (
    LoginForm, SeoForm, UploadSeoRulesForm, ContentUploadExcelForm,
    RedirectionCreateForm, RedirectionEditForm,
    RedirectionRemoveForm, RedirectionImportForm,
    TranslationForm, TransferTranslationForm,
)    
from cms_engine.models import Redirection, Translation, Page
from cms_engine.defaults import TRADSBASE
from shared_engine.transmeta import get_real_language


class Login(FormView):
    u"""
    We show login form
    """
    template_name = 'backoffice/login.html'
    form_class = LoginForm

    def get_success_url(self):
        r = self.request.GET.get('r')

        return r if r else self.success_url

    def form_valid(self, form):
        # We must log the user.
        user = form.get_user()
        login(self.request, user)

        if settings.DEBUG:
            self.request.session.set_expiry(36000)

        return super(Login, self).form_valid(form)


class Logout(RedirectView):
    u"""
    Realizamos un logout del usuario
    """
    url = '/cms-view/'

    def get(self, request, *args, **kwargs):
        logout(request)
        return super(Logout, self).get(request, *args, **kwargs)


class Home(TemplateView):
    u"""
    We show the home of the dashboard
    """
    template_name = 'backoffice/home.html'


class RedirectionListView(ListView):
    u"""
    We show all system redirects
    """
    template_name = 'backoffice/redirections/list_redirections.html'
    model = Redirection
    paginate_by = 20

    def get_queryset(self):
        redirections = self.request.site.redirection_set.all()

        # We check if they are filtered by old url
        filter = self.request.GET.get('old_url')
        if filter and filter != '':
            redirections = redirections.filter(old_url__icontains=filter)

        # If requested to check the redirects we check their
        # http response code
        broken = self.request.GET.get('broken')
        if broken and broken == '1':
            valid_redirections = []
            for redirection in redirections:
                try:
                    response = urllib.request.urlopen(redirection.new_url, timeout=10)
                except (urllib.error.HTTPError, urllib.error.URLError):
                    valid_redirections.append(redirection)
            redirections = valid_redirections

        return redirections

class RedirectionEditView(UpdateView):
    u"""
    Editing a redirect
    """
    template_name = 'backoffice/redirections/edit_redirection.html'
    model = Redirection
    form_class = RedirectionEditForm
    success_url = '/cms-view/close-fancybox.htm'

    def get_object(self):
        return Redirection.objects.get(id=self.kwargs['redirection_id'])


class RedirectionCreateView(CreateView):
    u"""
    View for creating a redirect
    """
    template_name = 'backoffice/redirections/create_redirection.html'
    model = Redirection
    form_class = RedirectionCreateForm
    success_url = '/cms-view/close-fancybox.htm'

    def get_initial(self):
        return {
            'site': self.request.site
        }


class RedirectionRemoveView(FormView):
    u"""
    View to remove a redirect
    """
    template_name = 'backoffice/redirections/remove_redirection.html'
    form_class = RedirectionRemoveForm
    success_url = '/cms-view/close-fancybox.htm'

    def form_valid(self, form):
        form.cleaned_data['redirection'].delete()
        return super(RedirectionRemoveView, self).form_valid(form)

    def get_initial(self):
        return {
            'redirection': Redirection.objects.get(id=self.kwargs['redirection_id'])
        }


class RedirectionImportView(FormView):
    u"""
    Import of redirections through an excel file, where only
    we take the first two columns. old url new url
    """
    template_name = 'backoffice/redirections/import_redirections.html'
    form_class = RedirectionImportForm
    success_url = '/cms-view/close-fancybox.htm'

    def form_valid(self, form):
        redirections = form.cleaned_data['file']

        for redirection in redirections:

           # If we already have the original url, we just update the new url
            try:
                red = self.request.site.redirection_set.get(old_url=redirection[0])
            except Redirection.DoesNotExist:
                red = Redirection()
                red.site = self.request.site
                red.old_url = redirection[0]
            red.new_url = redirection[1]
            try:
                red.save()
            except db.IntegrityError:
                continue

        return super(ImportRedirections, self).form_valid(form)


class TranslationFormView(FormView):
    u"""
    list of translations
    """
    template_name = 'backoffice/translations/translation.html'
    form_class = TranslationForm

    def get(self, request, *args, **kwargs):
        if not request.session.get('active_language'):
            # context = RequestContext(request)            
            # request.session['active_language'] = context['LANGUAGE_CODE']
            request.session['active_language'] = get_real_language()

        # If a language change is requested, we save it in session,
        # and redirect where it was before...
        language = self.request.GET.get('language')
        if language and language != '':
            request.session['active_language'] = language
            return http.HttpResponseRedirect(self.request.META['HTTP_REFERER'])

        return super(TranslationFormView, self).get(request, *args, **kwargs)

    def get_queryset(self):
        lang = self.request.session['active_language']

        page = self.request.GET.get('p')
        if not page or page == '':
            translations = self.request.site.translation_set.filter(page=None)
        else:
            try:
                self.page_obj = Page.objects.get(id=page)
            except Page.DoesNotExist:
                raise http.Http404

            # translations = self.page_obj.translation_set.filter(site=None)
            translations = self.request.site.translation_set.filter(page=self.page_obj)

        translations = translations.order_by('identifier')

        # If you only want the untranslated ones...
        notrad = self.request.GET.get('nt')
        if notrad == '1':
            kwargs = {
                'value_%s' % lang: '',
            }
            translations = translations.filter(**kwargs)

        # Search text filter...
        search = self.request.GET.get('search')
        if search and search != '':
            kwargs = {
                'value_%s__icontains' % lang: search,
            }
            translations = translations.filter(
                Q(**kwargs) | Q(identifier__icontains=search))

        return translations

    def get_form(self, form_class=None):
        lang = self.request.session['active_language']
        qs = self.get_queryset()
        if form_class is None:
            form_class = self.get_form_class()
        if self.request.method == 'POST':
            return form_class(qs, lang, self.request.POST)
        return form_class(qs, lang)

    def get_success_url(self):
        url = reverse('bo_translations')

        if self.request.GET.get('p'):
            url += '?p=' + self.request.GET.get('p')

        if self.request.GET.get('nt'):
            if not '?' in url:
                url += '?nt=' + self.request.GET.get('nt')
            else:
                url += '&nt=' + self.request.GET.get('nt')
        return url

    def form_valid(self, form):
        messages.success(self.request, _(u'translations saved correctly'))
        form.save(self.request.session['active_language'])
        return super(TranslationFormView, self).form_valid(form)

    def get_context_data(self, **kwargs):
        context = super(TranslationFormView, self).get_context_data(**kwargs)
        if hasattr(self, 'page_obj'):
            context['page_obj'] = self.page_obj

        context['active_language'] = self.request.session['active_language']
        return context


class TransferTranslationFormView(FormView):
    template_name = 'backoffice/translations/transfer_translations.html'
    form_class = TransferTranslationForm
    success_url = '/cms-view/close-fancybox.htm'

    def get_form(self, form_class=None):
        if form_class is None:        
            form_class = self.get_form_class()
        # We skip the current site
        return form_class(site_actual=self.request.site, **self.get_form_kwargs())

    def form_valid(self, form):
        trads = self.request.GET.get('trads')

        if not trads:
            return super(TransferTranslationFormView, self).form_valid(form)

        for idtrad in trads.split(','):
            try:
                trad_org = Translation.objects.get(id=int(idtrad))
            except Translation.DoesNotExist:
                continue

            # Now we transfer the content of the translation to the other site,
            # but only if they have the same translation
            for site in form.cleaned_data['sites']:

                if not trad_org.site:
                    # It is a page level translation
                    try:
                        trad_final = Translation.objects.get(
                            page__code=trad_org.page.code,
                            page__site__id=site.id,
                            identifier=trad_org.identifier)
                    except Translation.DoesNotExist:
                        continue
                else:
                    # Site level translation
                    try:
                        trad_final = Translation.objects.get(
                            site=site,
                            identifier=trad_org.identifier)
                    except Translation.DoesNotExist:
                        continue
                    except Translation.MultipleObjectsReturned:
                        trad_finals = Translation.objects.filter(
                            site=site,
                            identifier=trad_org.identifier).order_by("-id")
                        trad_final = trad_finals[0]
                        trad_finals.exclude(id=trad_final.id).delete()

                for lang in settings.LANGUAGES:
                    field = 'value_%s' % lang[0]
                    setattr(trad_final, field, getattr(trad_org, field))
                trad_final.save()

        return super(TransferTranslationFormView, self).form_valid(form)


class SeoView(FormView):
    template_name = 'backoffice/seo/seo.html'
    form_class = SeoForm

    # def get i def get_queryset of class translations

    def get(self, request, *args, **kwargs):
        if not request.session.get('active_language'):
            context = RequestContext(request)
            request.session['active_language'] = context['LANGUAGE_CODE']

        # If a language change is requested, we save it in session,
        # and redirect where it was before...
        language = self.request.GET.get('language')
        if language and language != '':
            request.session['active_language'] = language
            return http.HttpResponseRedirect(self.request.META['HTTP_REFERER'])

        return super(SeoView, self).get(request, *args, **kwargs)

    def get_initial(self):
        pag = self.request.GET.get('p')

        try:
            self.page = Page.objects.get(id=pag)
        except Page.DoesNotExist:
            return {}

        lang = self.request.session['active_language']

        meta_title = getattr(self.page, 'meta_title_%s' % lang)
        meta_description = getattr(self.page, 'meta_description_%s' % lang)
        meta_keywords = getattr(self.page, 'meta_keywords_%s' % lang)
        content = getattr(self.page, 'content_%s' % lang)
        h1 = getattr(self.page, 'h1_%s' % lang)
        h2 = getattr(self.page, 'h2_%s' % lang)
        h3 = getattr(self.page, 'h3_%s' % lang)

        return {
            'title': meta_title,
            'description': meta_description,
            'keywords': meta_keywords,
            'content': content,
            'h1': h1,
            'h2': h2,
            'h3': h3,
        }

    def get_context_data(self, **kwargs):
        context = super(SeoView, self).get_context_data(**kwargs)

        if hasattr(self, 'page'):
            context['page_obj'] = self.page
        context['active_language'] = self.request.session['active_language']
        return context

    def get_success_url(self):
        # url = urlresolvers.reverse('bo_seo')
        url = reverse('bo_seo')

        if self.request.GET.get('p'):
            url += '?p=' + self.request.GET.get('p')
        return url

    def form_valid(self, form):
        lang = self.request.session['active_language']
        data = form.cleaned_data
        setattr(self.pagina, 'meta_title_%s' % lang, data['title'])
        setattr(self.pagina, 'meta_description_%s' % lang, data['description'])
        setattr(self.pagina, 'meta_keywords_%s' % lang, data['keywords'])
        setattr(self.pagina, 'content_%s' % lang, data['content'])
        setattr(self.pagina, 'h1_%s' % lang, data['h1'])
        setattr(self.pagina, 'h2_%s' % lang, data['h2'])
        setattr(self.pagina, 'h3_%s' % lang, data['h3'])

        self.pagina.save()

        messages.success(self.request, _(u'SEO changes saved successfully'))
        # form.guardar(self.request.session['active_language'])

        return super(SeoView, self).form_valid(form)


class BaseTranslationTemplateView(TemplateView):
    template_name = 'backoffice/translations/base_translations.html'

    def get_context_data(self, **kwargs):
        ctx = super(BaseTranslationTemplateView, self).get_context_data(**kwargs)
        
        try:
            with open(TRADSBASE, 'rt') as fcsv:
                ctx['trads'] = list(csv.reader(fcsv, delimiter=','))
        except:
            pass

        return ctx

    def post(self, request, *args, **kwargs):
        u"""
        Of everything we receive per post, we save it in a list,
        to be saved in the csv
        """

        trads = {}

        for field, value in request.POST.items():
            if field == 'csrfmiddlewaretoken':
                continue

            try:
                fld, line, language = field.split('_')
            except ValueError:
                fld, line = field.split('_')
                language = None

            #print fld, line, language
            if language:
                try:
                    trads[str(line)][language] = value
                except KeyError:
                    trads[str(line)] = {language: value}
            else:
                try:
                    trads[str(line)]['id'] = value
                except KeyError:
                    trads[str(line)] = {'id': value}

        self.save_csv(trads.values())

        return super(BaseTranslationTemplateView, self).get(request, *args, **kwargs)

    def save_csv(self, list):
        with open(TRADSBASE, 'wb') as fcsv:
            fitx = csv.writer(fcsv, delimiter='#', quotechar='"')

            # Headboard
            line_cab = ['Id']
            for lang in settings.LANGUAGES:
                line_cab.append(lang[1].encode('utf-8'))
            fitx.writerow(line_cab)

            for trad in list:

                if not trad['id']:
                    continue

                line = [trad['id'].encode('utf-8')]

                for lang in settings.LANGUAGES:
                    line.append(trad[lang[0]].encode('utf-8'))

                fitx.writerow(line)


class SeoUploadRuleFormView(FormView):
    form_class = UploadSeoRulesForm
    template_name = 'backoffice/seo/upload_rules.html'
    success_url = '/cms-view/close-fancybox.htm'

    def form_valid(self, form):

        rules = form.cleaned_data['file']

        for pag in self.request.site.page_set.all():
            if 'all' in rules:
                self.apply_rules(pag, rules['all'])

            if pag.code in rules:
                self.apply_rules(pag, rules[pag.code])

        return super(SeoUploadRuleFormView, self).form_valid(form)

    def apply_rules(self, pag, rules):
        for field, values in rules.iteritems():
            for language, value in values.iteritems():
                c = '%s_%s' % (field, language)
                setattr(pag, c, value)
        pag.save()


class SeoDownloadRuleFormView(FormView):

    def get(self, request, *args, **kwargs):
        name = self.request.site.name.replace(' ', '_').encode('utf-8')

        # Construimos la respuesta
        resp = http.HttpResponse(content_type='application/vnd.ms-excel')
        resp['Content-Disposition'] = 'attachment; filename="%s.xls"' % name
        file = self.export_to_xls()
        file.save(resp)
        return resp

    def export_to_xls(self):
        fields = sorted(Page._meta.translatable_fields)
        languages = self.request.site.languages
        style = xlwt.easyxf('pattern: pattern solid, fore_colour light_blue;'
                              'font: colour white, bold True;')

        book = xlwt.Workbook(encoding='utf-8')
        for page in self.request.site.page_set.all():
            # Add the new sheet
            sheet = book.add_sheet(page.code)

            # We add the header with the languages
            for column, language in enumerate(languages, start=1):
                sheet.write(0, column, language, style)

            # We add the rows
            for line, field in enumerate(fields, start=1):
                # Add the line name
                sheet.write(line, 0, field, style)
                for column, language in enumerate(languages, start=1):
                    # In case we flies lack some language, we put the value
                    # a ''
                    cell = getattr(page, '%s_%s' % (field, language), u'')
                    if cell:
                        sheet.write(line, column, cell.encode('utf-8'))
        return book


class ContentUploadFormView(FormView):
    template_name = 'backoffice/content/initiation.html'
    form_class = ContentUploadExcelForm

    def get_form(self, form_class=None):        
        if form_class is None:
            form_class = self.get_form_class()
        return form_class(self.request.user, **self.get_form_kwargs())

    def get_success_url(self):
        messages.success(self.request, _(u'Upload completed successfully'))
        # return urlresolvers.reverse('bo_content')
        return reverse('bo_content')

    def form_valid(self, form):
        datos = form.cleaned_data['file']
        hotel = form.cleaned_data['hotel']
        self.store_data(datos, hotel)

        return super(ContentUploadFormView, self).form_valid(form)

    def store_data(self, datos, hotel):
        u"""
        Action of storing data in each site where it corresponds
        """
        # from pprint import pprint
        # pprint(datos)
        from hotel_engine.models import (
            Contacto, Categoria, HotelExtra, PuntoInteres, RedSocial, Servicio)

        # Contacto
        hotel.contacto_set.all().delete()

        for cont in datos['contacto']:
            contacto = Contacto(
                hotel=hotel, tipo=cont['code'], valor=cont['valor'])

            for desc in cont['description']:
                setattr(
                    contacto,
                    'description_' + desc['language'],
                    desc['description'])
            contacto.save()

        # Datos básicos
        basicos = datos['datos_basicos']
        hotel.categoria = Categoria.objects.get(code=basicos['categoria'])
        hotel.longitud = basicos['coordenadas']['longitud']
        hotel.latitud = basicos['coordenadas']['latitud']
        hotel.direccion = basicos['direccion']

        for nom in basicos['nombre']:
            setattr(hotel, 'nombre_' + nom['language'], nom['nombre'])

        hotel.save()

        try:
            hot_desc = hotel.hotelextra_set.get(field='description')
        except HotelExtra.DoesNotExist:
            hot_desc = HotelExtra(hotel=hotel, field='description')

        for desc in basicos['description']:
            setattr(hot_desc, 'content_' + desc['language'], desc['description'])
        hot_desc.save()

        # Puntos de interés
        for punt in datos['puntos_interes']:
            pi = PuntoInteres(
                longitud=punt['longitud'], latitud=punt['latitud'])
            for nom in punt['nombre']:
                setattr(pi, 'nombre_' + nom['language'], nom['nombre'])
            pi.save()
            hotel.puntos_interes.add(pi)

        # Red social
        hotel.redsocial_set.all().delete()

        for rs in datos['redes']:
            reds = RedSocial(
                hotel=hotel, tipo=rs['code'], url=rs['url'])
            reds.save()

        # Servicios
        hotel.servicios.clear()
        for serv in datos['servicios']:
            hotel.servicios.add(Servicio.objects.get(code=serv))
