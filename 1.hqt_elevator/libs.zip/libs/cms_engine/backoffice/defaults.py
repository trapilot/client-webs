from django.conf import settings
from django.utils.translation import gettext_lazy as _


class MissingContextProcessor(Exception):
    pass


GROUP_PERMISSIONS = ['cms_superuser','cms_user']
COPYRIGHT = '&copy; namdwb@gmail.com'
VERSION = _(u'Content Management System')

# We check that in the context processor of the application we have
# including the context for the backoffice. We need it
if not 'cms_engine.context_processors.backoffice' in settings.TEMPLATES[0]['OPTIONS']['context_processors']:
    raise MissingContextProcessor(u'You must include this context processor "cms_engine.context_processors.backoffice" in the application settings')
