import os

from django.conf import settings
from django.urls import re_path, include
from django.views.generic.base import TemplateView
from django.views.static import serve

from cms_engine.backoffice import views
from cms_engine.backoffice.decorators import has_authorization

PATH_ACTUAL = os.path.abspath(os.path.dirname(__file__))

urlpatterns = [
    re_path(r'^$', has_authorization(views.Home.as_view()), name='bo_home'),
    re_path(r'^login.htm$', views.Login.as_view(), name='bo_login'),
    re_path(r'^logout.htm$', views.Logout.as_view(), name='bo_logout'),
    re_path(r'^close-fancybox.htm$', TemplateView.as_view(template_name='backoffice/cierre_fancybox.html'), name='bo_close_fancybox'),
    re_path(r'^static/(.*)$', serve, {'document_root': os.path.join(PATH_ACTUAL, 'static'), 'show_indexes': True}),
]

# We load the urls of the modules installed in the INSTALLED_APPS, which have a backoffice
for app in settings.INSTALLED_APPS:
    if app != 'cms_engine':
        try:
            backapp = __import__('%s.backoffice.urls' % app, fromlist = ['urls'])
        except ImportError:
            continue
        urlpatterns += re_path(r'^%s/' % app, include(backapp)),


# Redirections
urlpatterns += [
    re_path(r'^redirections.htm$', has_authorization(views.RedirectionListView.as_view()), name='bo_redirections'),
    re_path(r'^edit-redirection/(?P<redirection_id>[0-9]+).htm$', has_authorization(views.RedirectionEditView.as_view()), name='bo_edit_redirections'),
    re_path(r'^create-redirection.htm$', has_authorization(views.RedirectionCreateView.as_view()), name='bo_create_redirection'),
    re_path(r'^remove-redirection/(?P<redirection_id>[0-9]+).htm$', has_authorization(views.RedirectionRemoveView.as_view()), name='bo_remove_redirection'),
    re_path(r'^import-redirections.htm$', has_authorization(views.RedirectionImportView.as_view()), name='bo_import_redirections'),
]

# Translations
urlpatterns += [
    re_path(r'^translations.htm$', has_authorization(views.TranslationFormView.as_view()), name='bo_translations'),
    re_path(r'^transfer-translations.htm$', has_authorization(views.TransferTranslationFormView.as_view()), name='bo_transfer_translations'),
    re_path(r'^base-translations.htm$', has_authorization(views.BaseTranslationTemplateView.as_view()), name='bo_base_translations'),
]

# Seo
urlpatterns += [
    re_path(r'^seo.htm$', has_authorization(views.SeoView.as_view()), name='bo_seo'),
    re_path(r'^seo/upload-rules.htm$', has_authorization(views.SeoUploadRuleFormView.as_view()), name='bo_seo_upload_rules'),
    re_path(r'^seo/download-rules.htm$', has_authorization(views.SeoDownloadRuleFormView.as_view()), name='bo_seo_download_rules'),
]

# Contents
urlpatterns += [
    re_path(r'^content.htm$', has_authorization(views.ContentUploadFormView.as_view()), name='bo_content'),
]
