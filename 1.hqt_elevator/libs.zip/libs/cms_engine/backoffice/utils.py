"""
We will add in this module, several utilities
"""
from django.conf import settings


def delete_i18n_fields(tuple, *fields):
    u"""
    Starting with a tuple and some fields, we update the tuple by adding the
    fields for each language
    """
    for field in fields:
        for language in settings.LANGUAGES:
            tuple += ('%s_%s' % (field, language[0]),)

    return tuple
