import os

from django.utils.http import urlencode
from django.template.loaders.app_directories import Loader


def default_project_code():
    u"""
    Returns the code of the last project created as the default value
    for the path of the templates in the Page view.
    """
    try:
        from django.conf import settings
        from cms_engine.models import Project
        
        if hasattr(settings, 'SITE_ID'):
            project = Project.objects.get(pk=settings.SITE_ID)
        elif hasattr(settings, 'SITE_CODE'):
            project = Project.objects.get(code=settings.SITE_CODE)
        else:
            project = Project.objects.all()[::-1][0]
    except:
        return None
    else:
        return project


def build_page_url(project, page, language, return_parent=False, **kwargs):
    u"""
    We generate the url of a page according to the indicated language.
    This method is used for language change. For example, if we are on the page of offers
    in Vietnam and it changes to English, we return the url of this page in English
    """
    
    url = build_domain_url(project, language)
    if not page:
        return url
    
    if return_parent and page.parent and not page.is_home:
        url += page.parent.reverse(language=language)
    else:
        url += page.reverse(language=language, **kwargs)
    return url


def build_domain_url(project, language):
    u"""
    We return the domain of a page according to the indicated language. This method is used for language change.
    """
    prefix = 'https://' if project.is_ssl else 'http://'
    return prefix + getattr(project, 'domain_%s' % language)


def get_parameters(request, skip=()):
    copy = request.GET.copy()
    for k in skip:
        del copy[k]
    return ("?" + urlencode(copy)) if copy else ""

def delete_file(path):
    try:
        os.remove(path)
    except OSError:
        pass

class AppTemplateExtender(Loader):
    def get_template_sources(self, template_name, template_dirs=None):
        if template_name.startswith("apps:"):
            return super(AppTemplateExtender, self).get_template_sources(template_name[5:], template_dirs)
        return ()
