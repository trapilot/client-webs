import os
import re

from django.utils.http import urlencode
from django.template.loaders.app_directories import Loader


def default_site_code():
    u"""
    Returns the code of the last site created as the default value
    for the path of the templates in the Page view.
    """
    try:
        from django.conf import settings
        from cms_engine.models import Site
        
        if hasattr(settings, 'SITE_ID'):
            site = Site.objects.get(pk=settings.SITE_ID)
        elif hasattr(settings, 'SITE_CODE'):
            site = Site.objects.get(code=settings.SITE_CODE)
        else:
            site = Site.objects.all()[::-1][0]
    except:
        return None
    else:
        return site


def build_page_url(site, page, language, return_parent=False, **kwargs):
    u"""
    We generate the url of a page according to the indicated language.
    This method is used for language change. For example, if we are on the page of offers
    in Vietnam and it changes to English, we return the url of this page in English
    """
    
    url = build_domain_url(site, language)
    if not page:
        return url
    
    if return_parent and page.parent and not page.is_home:
        url += page.parent.reverse(language=language)
    else:
        url += page.reverse(language=language, **kwargs)
    return url


def build_domain_url(site, language):
    u"""
    We return the domain of a page according to the indicated language. This method is used for language change.
    """
    prefix = 'https://' if site.is_ssl else 'http://'
    return prefix + getattr(site, 'domain_%s' % language)


def normalize_path(path: str) -> str:
    """
    Normalize path:
    - ensure leading slash
    - remove trailing slash except root
    """
    if path.endswith('/'):
        return path[:-1]
    return path + '/'


def resolve_page(site, path):
    """
    Resolve page from path.
    Returns:
        (page, language, view_args)
    """
    for reg, page, lang in site.page_urls:
        regex = re.compile(reg)
        match = regex.match(path)
        if not match:
            match = regex.match(normalize_path(path))

        if match:
            view_kwargs = {}
            pattern = page.pattern_url(lang)
            if pattern:
                view_match = re.match(pattern, path)
                if view_match:
                    view_kwargs = view_match.groupdict()
            return page, lang, view_kwargs
    return None, None, {}

def get_parameters(request, skip=()):
    copy = request.GET.copy()
    for k in skip:
        del copy[k]
    return ("?" + urlencode(copy)) if copy else ""

def delete_file(path):
    try:
        os.remove(path)
    except OSError:
        pass

class AppTemplateExtender(Loader):
    def get_template_sources(self, template_name, template_dirs=None):
        if template_name.startswith("apps:"):
            return super(AppTemplateExtender, self).get_template_sources(template_name[5:], template_dirs)
        return ()
