#from operator import itemgetter

from django import http
from django.conf import settings
from django.template import RequestContext
from django.utils.translation import gettext_lazy as _
from django.views.generic.base import TemplateView
#from django.core import urlresolvers
#from django.utils import translation


class NotList(Exception):
    pass


class NoObjectsUrlSitemap(Exception):
    pass


class HaveNoParent(Exception):
    pass


class UrlSitemap(object):
    u"""
    Object to map the URLs of the sitemap. To build it, you pass the
    template a list of objects of this type.
    """
    def __init__(self):
        self.url = ''
        self.level = 0
        self.sorted = 0
        self.frequency = 'yearly'
        self.priority = 1
        self.childs = []

    def __str__(self):
        return self.url

    def reverse_url(self, project, page_code, args):
        u"""
        If this method is used, it is not necessary to make the assignment of the
        URL in the url attribute, since it is this same method that does a
        reverse over the page_code and the rest of the passed arguments and attributes
        the URL to self.url
        """
        page = project.pages[page_code]

        self.url = 'http://%s' % project.domain
        self.url += page.reverse(args)

        self.level = page.level
        self.sorted = page.sorted_as

    def add_child(self, child):
        u"""
        Add a Url Sitemap object as a child page
        """
        self.childs.append(child)


class SitemapView(TemplateView):
    u"""
    View to eject the sitemap
    """
    template_name = 'sitemap.xml'
    content_type = 'application/xml; charset=utf-8'

    def get(self, request, *args, **kwargs):
        self.context = RequestContext(request)
        self.project = request.project
        self.domain = 'http://%s/' % request.META['HTTP_HOST']

        return super(SitemapView, self).get(request, *args, **kwargs)
        
    def get_context_data(self, **kwargs):
        u"""
        On the one hand, we build the urls of the static pages, those that do not
        they have associated objects or they do not have dynamic urls. These others are
        They build from their objects.
        """
        context = super(SitemapView, self).get_context_data(**kwargs)
        context['pages'] = self._pages(self.project, self.domain, self.context)
        return context

    @staticmethod
    def _pages(project, domain, context):
        u"""
        We return a list of all the UrlSitemap objects that make up the sitemap XML
        """
        # In case the domain is passed with a slash at the end...
        if domain[-1] == "/":
            domain = domain[:-1]

        pages = []
        project_pages = sorted(
            [
                page for page in project.pages.values()
                if page.url is not None and '(?P<' not in page.url
            ],
            key=lambda pag: pag.sorted_as
        )

        for page in project_pages:
            urlsm = UrlSitemap()
            urlsm.url = domain + page.reverse()
            urlsm.code = page.code
            urlsm.name = page.name
            urlsm.changefreq = page.changefreq
            urlsm.priority = page.priority
            urlsm.level = page.level
            urlsm.sorted = page.sorted_as
            pages.append(urlsm)

        # We load the sitemap extension
        if project.sitemap_extension:
            parts = project.sitemap_extension.split('.')
            p = parts[:-1]
            md = str(parts[0]) + '.' + str(parts[1])
            try:
                module = __import__('.'.join(parts[:-1]), fromlist=parts[-1:])
            except ImportError:
                if settings.DEBUG:
                    print("[E] Wrong sitemap extension")
                raise http.Http404()

            method = getattr(module, parts[-1])
            urls = method(context)

            if not isinstance(urls, list):
                raise NotList(_(u'The sitemap_extension method must return a list'))

            if len(urls) and not isinstance(urls[0], UrlSitemap):
                raise NoObjectsUrlSitemap(
                    _(u'The sitemap_extension list should return a list of UrlsSitemap objects'))

            pages += urls
        
        return pages

    @staticmethod
    def _pages_as_tree(project, domain, context):
        u"""
        Returns a list of pages to display nested
        """
        # In case the domain is passed with a slash at the end...
        if domain[-1] == '/':
            domain = domain[:-1]

        # we retrieve the root pages that have no parameters and whose order
        # is greater than or equal to 0 (just put a -1 so that the page does not
        # appear in the sitemap), sorted by the order field
        project_pages = sorted(
            [page for page in project.pages.values() if not '(?P<' in pag.url and pag.level == 0 and pag.sorted_as >= 0],
            key = lambda pag: pag.sorted_as
        )

        # we add the childs pages that do not need parameters
        # we clone the list to be able to return the list of pages of projects
        list_pages = project_pages[:]
        for pag in list_pages:
            pag.url_reversed = pag.reverse()
            pag.childs = pag.nested_set.exclude(url_en__contains='(?P<')

            # we repeat with the rest of the offspring
            if pag.childs:
                list_pages.extend(pag.childs)

        # We load the sitemap extension
        if project.sitemap_extension:
            partes = project.sitemap_extension.split('.')
            module = __import__('.'.join(partes[:-1]), fromlist=partes[-1:])
            method = getattr(module, partes[-1])

            # to make it compatible with the previous version, we will pass a
            # optional parameter
            dynamic_pages = method(context, xml=False)

            if not isinstance(dynamic_pages, list):
                raise NotList(
                    _(u'The sitemap_extension method must return a list'))

            # we add the dynamic childs pages to their respective parents
            parents = list_pages[:]
            for page in dynamic_pages:
                try:
                    index = parents.index(page.parent)
                    parent = parents[index]
                except ValueError:
                    parent = page.parent
                    parents.append(page)

                try:
                    parent.childs_dynamics.append(page)
                except AttributeError:
                    try:
                        parent.childs_dynamics = [page]
                    except AttributeError:
                        # If the childs_dinamicas attribute does not exist, it means that
                        # the page has no parent. For now, we do not allow
                        # dynamic pages that have no parent
                        raise HaveNoParent(
                            _(u"Page {0} (id:{1}) has no parent").format(page, page.id))

                page.parent = parent

        return project_pages
