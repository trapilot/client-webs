#from operator import itemgetter

from django import http
from django.conf import settings
from django.template import RequestContext
from django.utils.translation import gettext_lazy as _, get_language
from django.views.generic.base import TemplateView
#from django.core import urlresolvers
#from django.utils import translation

from shared_engine.transmeta import get_real_language
from cms_engine.utils import build_domain_url, build_page_url


class SitemapContext:
    def __init__(self, language, lastmod=None, priority=None, changefreq=None):
        self.language = language
        self.lastmod = lastmod
        self.priority = priority
        self.changefreq = changefreq

class UrlSitemap(object):
    u"""
    Object to map the URLs of the sitemap. To build it, you pass the
    template a list of objects of this type.
    """
    def __init__(self):
        self.url = ''
        self.level = 0
        self.sorted = 0
        self.lastmod = ''
        self.priority = 1
        self.changefreq = 'yearly'
        self.childs = []

    def __str__(self):
        return self.url

    def reverse_url(self, project, page_code, args):
        u"""
        If this method is used, it is not necessary to make the assignment of the
        URL in the url attribute, since it is this same method that does a
        reverse over the page_code and the rest of the passed arguments and attributes
        the URL to self.url
        """
        page = project.pages[page_code]
        
        self.url = build_page_url(project, page, get_real_language(), False, args)
        self.level = page.level
        self.sorted = page.sorted

    def add_child(self, child):
        u"""
        Add a Url Sitemap object as a child page
        """
        self.childs.append(child)


class SitemapView(TemplateView):
    u"""
    View to eject the sitemap
    """
    template_name = 'sitemap.xml'
    content_type = 'application/xml; charset=utf-8'

    def get(self, request, *args, **kwargs):
        self.context = RequestContext(request)
        self.project = request.project
        
        return super(SitemapView, self).get(request, *args, **kwargs)
        
    def get_context_data(self, **kwargs):
        u"""
        On the one hand, we build the urls of the static pages, those that do not
        they have associated objects or they do not have dynamic urls. These others are
        They build from their objects.
        """
        context = super(SitemapView, self).get_context_data(**kwargs)
        context['pages'] = self._pages(self.project, self.context)
        return context

    @staticmethod
    def _pages(project, context):
        u"""
        We return a list of all the UrlSitemap objects that make up the sitemap XML
        """
        
        pages = []
        domain = build_domain_url(project, get_real_language())
        project_pages = [
            page for page in project.pages.values()
            if page.is_index and page.url is not None and not page.is_internal
        ]
        
        for page in project_pages:
            sm = UrlSitemap()
            sm.url = domain + page.reverse()
            sm.changefreq = page.changefreq
            sm.lastmod = page.updated_at
            sm.priority = page.priority
            sm.level = page.level
            sm.sorted = page.sorted
            pages.append(sm)

        # We load the sitemap extension
        if project.sitemap_extension:
            parts = project.sitemap_extension.split('.')
            try:
                module = __import__('.'.join(parts[:-1]), fromlist=parts[-1:])
            except ImportError as ex:
                if settings.DEBUG:
                    print(f"[E] Wrong sitemap extension: {ex}")
                raise http.Http404()

            method = getattr(module, parts[-1])
            urls = method(project, context)

            if not isinstance(urls, list):
                raise Exception(_(u'The sitemap_extension method must return a list'))

            if len(urls) and not isinstance(urls[0], UrlSitemap):
                raise Exception(
                    _(u'The sitemap_extension list should return a list of UrlsSitemap objects'))

            pages += urls
        
        pages.sort(key=lambda x: (x.sorted, x.level))

        return pages

    @staticmethod
    def _pages_as_tree(project, language, context):
        u"""
        Returns a list of pages to display nested
        """
        
        # we retrieve the root pages that have no parameters and whose order
        # is greater than or equal to 0 (just put a -1 so that the page does not
        # appear in the sitemap), sorted by the order field
        project_pages = [
            page for page in project.pages.values()
            if page.is_index and page.url is not None and not page.is_internal
        ]

        # we add the childs pages that do not need parameters
        # we clone the list to be able to return the list of pages of projects
        list_pages = project_pages[:]
        for pag in list_pages:
            pag.url_reversed = pag.reverse()
            pag.childs = pag.nested_set.exclude(url_en__contains='(?P<')

            # we repeat with the rest of the offspring
            if pag.childs:
                list_pages.extend(pag.childs)

        # We load the sitemap extension
        if project.sitemap_extension:
            partes = project.sitemap_extension.split('.')
            module = __import__('.'.join(partes[:-1]), fromlist=partes[-1:])
            method = getattr(module, partes[-1])

            # to make it compatible with the previous version, we will pass a
            # optional parameter
            dynamic_pages = method(context, xml=False)

            if not isinstance(dynamic_pages, list):
                raise Exception(_(u'The sitemap_extension method must return a list'))

            # we add the dynamic childs pages to their respective parents
            parents = list_pages[:]
            for page in dynamic_pages:
                try:
                    index = parents.index(page.parent)
                    parent = parents[index]
                except ValueError:
                    parent = page.parent
                    parents.append(page)

                try:
                    parent.childs_dynamics.append(page)
                except AttributeError:
                    try:
                        parent.childs_dynamics = [page]
                    except AttributeError:
                        # If the childs_dinamicas attribute does not exist, it means that
                        # the page has no parent. For now, we do not allow
                        # dynamic pages that have no parent
                        raise Exception(_(u"Page {0} (id:{1}) has no parent").format(page, page.id))

                page.parent = parent

        project_pages.sort(key=lambda x: (x.sorted, x.level))

        return project_pages
