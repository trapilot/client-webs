from django.views.generic import TemplateView


class RobotsView(TemplateView):
    template_name = 'robots.txt'
    content_type = 'text/plain'
    
    def get_context_data(self, **kwargs):
        try:
            disallow_all = self.request.get_host() != self.request.site.domain
        except AttributeError:
            disallow_all = False

        context = super(RobotsView, self).get_context_data(**kwargs)
        context['robots_extra'] = self.request.site.robots_extra
        context['disallow_all'] = disallow_all
        return context
