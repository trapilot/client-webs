from django.views.generic import TemplateView


class RobotsView(TemplateView):
    template_name = 'robots.txt'
    content_type = 'text/plain'
    
    def get_context_data(self, **kwargs):
        try:
            disallow_all = (self.request.project.is_ssl and self.request.get_host() == self.request.project.domain)
        except AttributeError:
            disallow_all = False

        context = super(RobotsView, self).get_context_data(**kwargs)
        context['extra_robots'] = self.request.project.extra_robots
        context['disallow_all'] = disallow_all
        return context
