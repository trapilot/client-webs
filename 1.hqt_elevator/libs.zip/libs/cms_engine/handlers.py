import re
import sys
import inspect
import logging
import django

from django import http
from django.conf import settings
from django.core.cache import cache
from django.core.handlers import base
from django.core.handlers.wsgi import WSGIRequest
from django.core import signals
# from django.core.urlresolvers import set_script_prefix
from django.urls import set_urlconf, Resolver404
from django.utils import translation

from threading import Lock
from http.client import responses
from asgiref.sync import async_to_sync, sync_to_async

from shared_engine.transmeta import get_real_language
from cms_engine import defaults
from cms_engine.utils import build_page_url, build_domain_url


logger = logging.getLogger('django.request')


# class NoneSite(Exception):
    # pass


class CmsHandler(base.BaseHandler):
    u"""
    We override the main handler to give the functionalities of our cms
    """

    initLock = Lock()
    request_class = WSGIRequest
    auto_detect = False

    def _load_middlewares(self, is_async=False):
        u"""
        We have removed this code snippet from the main call to make it cleaner.
        """

        if not self._middleware_chain:
            self.initLock.acquire()
            try:
                try:
                    # Check that middleware is still uninitialised.
                    if not self._middleware_chain:
                        self.load_middleware(is_async)
                except:
                    # Unload whatever middleware we got
                    self._middleware_chain = None
                    raise
            finally:
                self.initLock.release()

    def __call__(self, environ, start_response):
        # On the first request, the settings are not loaded yet, so
        # that we load the settings and the middlewares are loaded. In the
        # remaining requests no longer go through here
        self._load_middlewares()

        # set_script_prefix(base.get_script_name(environ))
        signals.request_started.send(sender=self.__class__)

        try:
            try:
                request = self.request_class(environ)
            except UnicodeDecodeError:
                logger.warning(
                    'Bad Request (UnicodeDecodeError)',
                    exc_info=sys.exc_info(),
                    extra={'status_code': 400,}
                )
                response = http.HttpResponseBadRequest()
            else:
                # Here we will detect the language and site.
                from django.conf import settings

                self.resolve_language(request, settings)
                self.resolve_site(request)
                response = self.get_response_django(request)

                # ATTENTION!!!!
                # If, at any time, we have a problem that the web
                # does not change language correctly and the browser gives us a
                # warning that it is not redirecting well, there may be
                # created a redirect with the language code in the admin
                # (/admin/cms_engine/redirect/)
                # After deleting these redirects, keep in mind
                # account that can be cached by the browser

                # collect the parameters that come from get, except 'chlng'
                self.get_parameters = '&'.join([
                    '%s=%s' % (k, v)
                    for k, v in request.GET.items() if k != 'chlng' and len(v) > 0])
        finally:
            signals.request_finished.send(sender=self.__class__)

        # At this point we will apply our hack. If the response returns a
        # 404, means it has not found any of the urlpatterns urls.
        # (these are the priority ones).
        # Now let's detect if the site exists and detect the page
        # that is requested
        if response.status_code == 404:
            response = self.get_response_cms(request, response, settings)
        else:
            # It could still be trying to switch languages
            # from a URL in the urlpatterns (eg a search for
            # availability), it would not go into the get_response_cms method and
            # would ignore the language change request.
            # Here we are going to check if we are getting the 'chlng' parameter
            # and if so, do a redirect to home. To unlink the
            # maximum the CMS, we will not repeat any search queries from availability
            lang = request.GET.get('chlng', None)
            if lang:
                url = request.scheme + '://' + request.META['HTTP_HOST']
                qs = self.transfer_get_parameters()
                qs += '&' if qs else '?'
                qs += 'chlng=' + lang
                url += qs
                response = http.HttpResponseRedirect(url)
                
        # We continue with the original handler code
        try:
            status_text = responses[response.status_code]
        except KeyError:
            status_text = 'UNKNOWN STATUS CODE'

        status = '%s %s' % (response.status_code, status_text)
        response_headers = [(str(k), str(v)) for k, v in response.items()]
        for c in response.cookies.values():
            response_headers.append(('Set-Cookie', str(c.output(header=''))))
        start_response(status, response_headers)

        return response

    def resolve_request_cms(self, request):
        # resolver_match = self.resolve_request(request)

        callback = request.page.view_callback
        callback_args = ()
        callback_kwargs = ()
        return callback, callback_args, callback_kwargs

    def get_response_django(self, request, is_async=False):
        try:
            get_response = (
                self.get_response_async
                if is_async else self.get_response
            )
            return get_response(request)
        except Resolver404:
            return http.HttpResponseNotFound()
        except Exception:
            logger.exception("Unhandled exception while processing request")
            return http.HttpResponseServerError()

    def get_response_cms(self, request, response, settings):
        u"""
        Similar to the get_response that this object has, but this one works with our cms
        """
        site = getattr(request, 'site', None)
        if not site:
            return response
            # raise NoneSite(u'The site does not exist!')

        page, old_url, language, callback_kwargs = CmsHandler.detection_page(request, site)

        chlng = request.GET.get('chlng')

        if not page:
            if chlng:
                url = build_domain_url(site, chlng)
                url += self.transfer_get_parameters()
                return http.HttpResponseRedirect(url)
            else:
                return response

        # Store the site and page in the request. It will be useful later.
        request.site = site
        request.page = page

        # Check if a language change is requested
        if chlng and chlng in request.site.languages:
            return self.change_language(request, chlng)

        # active language when auto_detect from url
        if language and language in request.site.languages:
            translation.activate(defaults.MAPPING_LANGUAGE_CODE[language])

        # Setup default url resolver for this thread
        set_urlconf(settings.ROOT_URLCONF)

        """
        Resolve and call the view, then apply view, exception, and
        template_response middleware. This method is everything that happens
        inside the request/response middleware.
        """
        response = None
        callback, callback_args, _ = self.resolve_request_cms(request)

        # Apply view middleware
        for middleware_method in self._view_middleware:
            response = middleware_method(request, callback, callback_args, callback_kwargs)
            if response:
                break

        if response is None:
            wrapped_callback = self.make_view_atomic(callback)
            # If it is an asynchronous view, run it in a subthread.
            if inspect.iscoroutinefunction(wrapped_callback):
                wrapped_callback = async_to_sync(wrapped_callback)
            try:
                response = wrapped_callback(request, *callback_args, **callback_kwargs)
            except Exception as e:
                response = self.process_exception_by_middleware(e, request)
                if response is None:
                    raise

        # Complain if the view returned None (a common error).
        self.check_response(response, callback)

        # If the response supports deferred rendering, apply template
        # response middleware and then render the response
        if hasattr(response, 'render') and callable(response.render):
            for middleware_method in self._template_response_middleware:
                response = middleware_method(request, response)
                # Complain if the template response middleware returned None (a common error).
                self.check_response(
                    response,
                    middleware_method,
                    name='%s.process_template_response'
                    % (middleware_method.__self__.__class__.__name__,),
                )
            try:
                response = response.render()
            except Exception as e:
                response = self.process_exception_by_middleware(e, request)
                if response is None:
                    raise

        # Check the request URL, in slash, if not do a redirect, since all URLs must end the slash.
        if not page.is_home:
            if not old_url.endswith('/') and not old_url.endswith('.htm') and not old_url.endswith('.html'):
                new_pag_url = '%s/' % old_url
                # We pass the final URL with all get parameters, it can have.
                new_pag_url += self.transfer_get_parameters()
                response = http.HttpResponsePermanentRedirect(new_pag_url)

        return response

    def resolve_site(self, request):
        u"""
        From the domain of the request, we detect the site by
        witch reffers to. Once we have the domain, we check if it is
        in the cache. Otherwise, we look for it in the
        model. If it still doesn't exist, we return None.

        A second way to detect the site is through its code,
        passed from NGINX in the CMS_PROJECT_CODE attribute.
        """
        
        site = getattr(request, 'site', None)
        if site is not None:
            return site
        
        from cms_engine.models import Site

        site_code = request.META.get('CMS_PROJECT_CODE')
        if site_code:
            cache_key = 'cache_site_code__%s' % site_code
            site = cache.get(cache_key)
            if not site:
                try:
                    site = Site.objects.get(code=site_code)
                except Site.DoesNotExist:
                    if settings.DEBUG:
                        print(u"[E] Site not found: %s" % site_code)
                        return None
        else:
            try:
                domain = request.META['HTTP_HOST']
            except KeyError:
                return None

            domain = domain.lower().split(':')[0]

            cache_key = 'cache_site_domain__%s' % domain
            site = cache.get(cache_key)
            if not site:
                site = Site.objects.site(domain)
                if not site:
                    logger.info('Site do not exists.')
                    return None

        site._load_constants()
        site._load_page_urls(auto_detect=self.auto_detect)
        
        cache.set(cache_key, site)

        request.site = site
        return site

    @staticmethod
    def detection_page(request, site, urlWM=None):
        u"""
        We detect the page we are on and return the page object.
        """

        try:
            url = request.META['PATH_INFO']
        except KeyError:
            return None, None, None, {}

        if urlWM:
            url = urlWM

        for urlregex, pag, lang in site.page_urls:
            urlregex = re.compile(urlregex)
            # Based on the url, check all possibilities where we can get a page.
            urls = url[1:]

            #match = urlregex.match(urls)
            if urls.endswith('/'):
               match = urlregex.match(urls)
               if not match:
                    match = urlregex.match(urls[:-1])
            else:
               match = urlregex.match(urls)
               if not match:
                    urls = urls + '/'
                    match = urlregex.match(urls)

            if match:
                return pag, url, lang, match.groupdict()
        return None, None, None, {}

    def resolve_language(self, request, settings):
        u"""
        We detect and set the language of the request, depending on the configuration.
        """

        try:
            LANGUAGE_TYPE = settings.LANGUAGE_TYPE
        except AttributeError:
            LANGUAGE_TYPE = defaults.LANGUAGE_TYPE

        # default language
        language = get_real_language(settings.LANGUAGE_CODE)

        # type 0: auto detection, depends on the request url
        if LANGUAGE_TYPE == 0:
            self.auto_detect = True

        # type 1: depends on the prefix used in the subdomain (en.example.com, fr.example.com, etc)
        elif LANGUAGE_TYPE == 1:
            host = request.META.get('HTTP_HOST')
            if host:
                # if there is no host, it will get the default language
                language_code = host.split('.', 1)[0]
                if language_code in defaults.MAPPING_LANGUAGE_CODE:
                    language = language_code
                else:
                    # Check if the language code is passed through GET
                    lang = request.GET.get('lang', settings.LANGUAGE_CODE)
                    if lang in defaults.MAPPING_LANGUAGE_CODE:
                        # if it is not in the mapping, it will take the default language
                        language = lang

        # type 2: depends on the geographic domain (ex: .com, .co.uk, .fr)
        # those domains whose extension does not match must be specified
        # with the language (eg en.example.com: 'en', instead of 'es')
        elif LANGUAGE_TYPE == 2:
            host = request.META.get('HTTP_HOST')
            if host:
                # if there is no host, it will get the default language
                for domain, idi in defaults.MAPPING_LANGUAGE_DOMAIN.items():
                    if host.endswith(domain):
                        language = idi
                        break

            if len(settings.LANGUAGE_MAPPING_DOMAIN):
                lang = request.GET.get('lang')
                if lang and lang in defaults.MAPPING_LANGUAGE_CODE:
                    language = lang
                else:
                    try:
                        language = settings.LANGUAGE_MAPPING_DOMAIN[host]
                    except KeyError:
                        pass

        # type 3: we take the language according to the domain that has been put in admin > sites
        elif LANGUAGE_TYPE == 3:
            host = request.META.get('HTTP_HOST')
            site = self.resolve_site(request)
            if host and site:
                for lang in site.languages:
                    field = 'domain_%s' % lang
                    if host == getattr(site, field):
                        language = lang
                        break
                else:
                    # Check if the language code is passed through GET
                    lang = request.GET.get('lang', settings.LANGUAGE_CODE)
                    if lang in defaults.MAPPING_LANGUAGE_CODE:
                        # If it is not in the mapping, it will take the default language
                        language = lang
        
        translation.activate(defaults.MAPPING_LANGUAGE_CODE[language])

    def change_language(self, request, chlng):
        u"""
        We look for the same url but with the requested language and we make a redirection
        """
        url = build_page_url(request.site, request.page, chlng, True)
        url += self.transfer_get_parameters()
        return http.HttpResponseRedirect(url)

    def transfer_get_parameters(self):
        u"""
        Transfers the rest of the parameters that are received by get when changing languages
        """
        query_string = ''
        if self.get_parameters:
            query_string = '?' + self.get_parameters
        return query_string


def get_wsgi_application():
    django.setup()

    return CmsHandler()
