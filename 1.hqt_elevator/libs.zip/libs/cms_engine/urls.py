# coding: utf-8
from django.conf import settings
from django.urls import include, path, re_path

from cms_engine.backoffice import urls as backoffice_urls
from cms_engine.robots import RobotsView
from cms_engine.sitemap import SitemapView
from cms_engine.views import dispatcher, CmsStaticView, ExternalRequestView, LandingView

urlpatterns = [
    path('sitemap.xml', SitemapView.as_view()),
    path('robots.txt', RobotsView.as_view()),
    path('cms-view/', include(backoffice_urls)),
    path('cms-external-rq', ExternalRequestView.as_view(), name='cms_external'),
    re_path(r'landing/(?P<slug>[-\w]+)/', LandingView.as_view(), name='cms_landing'),
    re_path(r'cms-static/(?P<type>(css|js|less))/', CmsStaticView.as_view(), name='cms_static'),
]

if getattr(settings, 'CMS_FUTURE', False):
    urlpatterns.append(path('', dispatcher))