# coding: utf-8
from django import template
from django.utils.safestring import mark_safe
import json

register = template.Library()


@register.simple_tag(takes_context=True)
def google_tag_manager_head(context):
    site = context.get("site")
    if not site:
        return ""

    gtm_ids = [x.strip() for x in (site.GOOGLE_TAG_MANAGER or "").split(",") if x.strip()]
    if not gtm_ids:
        return ""

    gtm_id = gtm_ids[0]

    return mark_safe(f"""
<script>
(function(w,d,s,l,i){{
    w[l]=w[l]||[];
    w[l].push({{'gtm.start': new Date().getTime(), event:'gtm.js'}});
    var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),
        dl=l!='dataLayer'?'&l='+l:'';
    j.async=true;
    j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;
    f.parentNode.insertBefore(j,f);
}})(window,document,'script','dataLayer','{gtm_id}');
</script>
""")

@register.simple_tag(takes_context=True)
def google_tag_manager_body(context):
    site = context.get("site")
    if not site:
        return ""

    gtm_ids = [x.strip() for x in (site.GOOGLE_TAG_MANAGER or "").split(",") if x.strip()]
    if not gtm_ids:
        return ""

    gtm_id = gtm_ids[0]

    return mark_safe(f"""
<noscript>
  <iframe src="https://www.googletagmanager.com/ns.html?id={gtm_id}"
  height="0" width="0"
  style="display:none;visibility:hidden"></iframe>
</noscript>
""")


@register.simple_tag(takes_context=True)
def google_tag_manager_datalayer(context):
    site = context.get("site")
    if not site:
        return ""

    gtm_ids = [x.strip() for x in (site.GOOGLE_TAG_MANAGER or "").split(",") if x.strip()]
    if not gtm_ids:
        return ""
    
    request = context.get("request")
    ua = request.META.get("HTTP_USER_AGENT", "").lower() if request else ""
    device = "m" if any(x in ua for x in ["iphone", "android", "mobile"]) else "d"

    data_layer = {
        "device": device,
    }

    return mark_safe(f"""
<script>
window.dataLayer = window.dataLayer || [];
window.dataLayer.push({json.dumps(data_layer)});
</script>
""")


@register.simple_tag(takes_context=True)
def google_tag_manager(context):
    site = context.get("site")
    request = context.get("request")

    if not site:
        return ""

    # Device detection
    device = "m"
    if request and request.session.get("webmobile_vclasic") is False:
        device = "d"

    # GTM IDs
    raw_gtm = getattr(site, "GOOGLE_TAG_MANAGER", "") or ""
    gtm_ids = [x.strip() for x in raw_gtm.split(",") if x.strip()]

    if not gtm_ids:
        return ""

    # Base dataLayer
    data_layer = {
        "device": device,
    }

    # Optional connection
    connection = None
    channel = None
    channel_code = None
    # try:
    #     connection = Connection.objects.select_related("channel_set").get(site=site)
    #     channel = str(connection.channel)
    #     channel_code = connection.channel.code
    # except Connection.DoesNotExist:
    #     pass

    if connection:
        data_layer.update({
            "channel": channel,
            "channelCode": channel_code,
        })

    # Extra dataLayer
    extra_data = getattr(site, "DATALAYER_INITIAL", None)

    html = []

    # Init dataLayer
    html.append(f"""
        <script>
        window.dataLayer = window.dataLayer || [];
        window.dataLayer.push({json.dumps(data_layer)});
        </script>
        """
    )

    # Optional extra dataLayer (raw JS object string)
    if extra_data:
        html.append(f"""
            <script>
            window.dataLayer.push({extra_data});
            </script>
            """
        )

    # GTM scripts
    for gtm_id in gtm_ids:
        html.append(f"""
            <!-- Google Tag Manager -->
            <noscript>
            <iframe src="https://www.googletagmanager.com/ns.html?id={gtm_id}"
            height="0" width="0" style="display:none;visibility:hidden"></iframe>
            </noscript>

            <script>
            (function(w,d,s,l,i){{
                w[l]=w[l]||[];
                w[l].push({{ 'gtm.start': new Date().getTime(), event:'gtm.js' }});

                var f=d.getElementsByTagName(s)[0],
                    j=d.createElement(s),
                    dl=l!='dataLayer' ? '&l='+l : '';

                j.async=true;
                j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;

                f.parentNode.insertBefore(j,f);
            }})(window,document,'script','dataLayer','{gtm_id}');
            </script>
            <!-- End Google Tag Manager -->
            """
        )

    return mark_safe("\n".join(html))