# coding: utf-8
from django import template
from django.template import Context, Template
# from bookcore_client.models import Connection
from django.template import RequestContext  
from pprint import pprint

register = template.Library()

class GetContextNode(template.Node):
    def render(self, context):
        project = context.get('project')
        channel = None
        channel_cod = None
        request = context['request']

        try:
            channel_classic_version = request.session.get('webmobile_vclasic', False)
        except AttributeError:
            channel_classic_version = False

        if channel_classic_version:
            device = 'm'
        else:
            device = 'd'

        try:
            code = project.GOOGLE_TAG_MANAGER
            code = code.split(',')
        except Exception as e:
            print(str(e))
            code = None
        
        connection = None # TOTO later
        # try:
            # connection = Connection.objects.get(project=project)
        # except Exception:
            # connection = None
            
        if connection:
            channel = connection.channel
            channel_code = connection.channel.code
        
        if code and connection:
            try:
                dataLayer = project.DATALAYER_INITIAL
            except Exception as e:
                print(str(e))
                dataLayer = ''

            google_tag_magener = ''
            for i, cod in enumerate(code):
                if i == 0:
                    google_tag_magener += """
                    <script>
                        dataLayer = [{
                            'device': '%(device)s',
                            'channelCode':'%(channel_code)s', 
                            'channel':'%(channel)s',
                            %(dataLayer)s
                        }]
                    </script>
                    """ % {'dataLayer':dataLayer, 'channel':channel, 'channel_code':channel_code, 'device':device}
                google_tag_magener += """               
                <noscript>
                    <iframe src='//www.googletagmanager.com/ns.html?id='%(code)s'
                    height='0' width='0' style='display:none;visibility:hidden'></iframe>
                </noscript>
                <script>
                    (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});
                    var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;
                    j.src='//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
                    })(window,document,'script','dataLayer','%(code)s');
                </script>""" % {"code":code}
            
            template = Template(google_tag_magener)
            return template.render(context)
        else:
            return ''
            

@register.tag
def google_tag_manager(parser, token):
    return GetContextNode()