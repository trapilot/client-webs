from pathlib import Path

from django import template
from django.utils.html import conditional_escape
from django.utils.safestring import mark_safe

register = template.Library()


PRESETS = {
    "default": {
        "sizes": "100vw",
        "loading": "lazy",
        "fetchpriority": None,
    },
    "card": {
        "sizes": "(max-width:768px) 100vw, 33vw",
        "loading": "lazy",
        "fetchpriority": None,
    },
    "hero": {
        "sizes": "100vw",
        "loading": "eager",
        "fetchpriority": "high",
    },
}


@register.simple_tag
def picture(
  image,
  alt="",
  preset="default",
  class_name="",
  id=None,
  sizes=None,
  loading=None,
  fetchpriority=None,
):
  """
  Usage:

  {% picture post.image %}

  {% picture
    post.image
    alt=post.title
    preset="card"
  %}

  {% picture
    page.banner
    alt=page.title
    preset="hero"
    class_name="w-full rounded-xl"
  %}
  """

  if not image:
    return ""

  preset_config = PRESETS.get(
    preset,
    PRESETS["default"]
  )

  sizes = sizes or preset_config["sizes"]
  loading = loading or preset_config["loading"]
  fetchpriority = (
    fetchpriority
    or preset_config["fetchpriority"]
  )

  image_url = image.url

  path = Path(image_url)

  generated_base = (
    path.parent
    / "generated"
    / path.stem
  )

  avif_srcset = ", ".join([
    f"{generated_base}_480.avif 480w",
    f"{generated_base}_768.avif 768w",
    f"{generated_base}_1200.avif 1200w",
  ])

  webp_srcset = ", ".join([
    f"{generated_base}_480.webp 480w",
    f"{generated_base}_768.webp 768w",
    f"{generated_base}_1200.webp 1200w",
  ])

  attrs = [
    f'src="{image_url}"',
    f'alt="{conditional_escape(alt or "")}"',
    'decoding="async"',
  ]
  
  if class_name:
    attrs.append(f'class="{conditional_escape(class_name)}"')

  if id:
    attrs.append(f'id="{conditional_escape(id)}"')
  
  if loading:
    attrs.append(f'loading="{loading}"')

  if fetchpriority:
    attrs.append(
      f'fetchpriority="{fetchpriority}"'
    )

  img_attrs = " ".join(attrs)

  html = f"""
<picture>
  <source
      type="image/avif"
      srcset="{avif_srcset}"
      sizes="{sizes}"
  >

  <source
      type="image/webp"
      srcset="{webp_srcset}"
      sizes="{sizes}"
  >
  <img {img_attrs}>
</picture>
"""

  return mark_safe(html)