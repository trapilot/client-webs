from django import template

register = template.Library()

@register.filter
def file_exists(file):
    try:
        return file and file.storage.exists(file.name)
    except Exception:
        return False
    