# coding: utf-8
from django import template
from django.template import  Template
from django.template.defaultfilters import linebreaksbr

register = template.Library()

ALLOWED_LIST = {
    'title': 'meta_title',
    'description': 'meta_description',
    'keywords': 'meta_keywords',
    'content': 'content',
    'h1': 'h1',
    'h2': 'h2',
    'h3': 'h3',
}


class InvalidArgument(Exception):
    pass


class SeoMetaNode(template.Node):

    def __init__(self, option):
        self._option = option

    def _object_meta(self, page, context):
        metaobjects = getattr(page, "_cached_metaobjects", None)

        if metaobjects is None:
            metaobjects = list(page.metaobject_set.all())
            page._cached_metaobjects = metaobjects

        for metaobj in metaobjects:
            obj = context.get(metaobj.object)

            if obj is None:
                continue

            value = getattr(obj, metaobj.field, None)

            if value == metaobj.value:
                return metaobj

        return page

    def render(self, context):
        request = context.get('request')
        page = getattr(request, "page", None)
        
        if page is None:
            return ''

        # We check if the page has any MetaObject records
        object = self._object_meta(page, context)
        valid = ALLOWED_LIST[self._option]
        content = getattr(object, valid) or ""
        if valid == 'content':
            content = linebreaksbr(content)

        template = Template(content)
        return template.render(context)


@register.tag
def seo_meta(parser, token):
    u"""
    Very similar to context_cms but for the exclusive use of obtaining the title, description and keywords
    """
    arg = token.split_contents()[1:][0]

    # We check that we receive only the arguments
    # ALLOWED_LIST
    if arg not in ALLOWED_LIST.keys():
        raise InvalidArgument(
            u'Invalid argument. Only allowed: %s' % ALLOWED_LIST.keys())

    return SeoMetaNode(arg)

