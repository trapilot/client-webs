# coding: utf-8
import csv
import datetime
import logging

from django import template
register = template.Library()

from django.conf import settings
from django.core.cache import cache
from django.core.mail import send_mail
from django.template import Template
from django.template.base import FilterExpression
from django.utils import translation

from cms_engine.models import Translation
from cms_engine.defaults import TRADSBASE

logger = logging.getLogger('django.request')


class TtMalUsado(Exception):
    pass


class SendTranslationError(Exception):
    pass


class TradNode(template.Node):

    def __init__(self, identifier, scope='page'):
        self._identifier = identifier
        self._scope = scope

    def _load_cache_translations(self):
        u"""
        We load the translations from the cache for the corresponding site,
        if it does not exist we create the empty dictionary
        """
        cache_key = 'cache_site_translation__%s' % (self._site.code)
        self._translations = cache.get(cache_key, {})

    def _update_cache(self):
        u"""We cache the translations dictionary again."""
        cache_key = 'cache_site_translation__%s' % (self._site.code)
        cache.set(cache_key, self._translations)

    def trads_base(self, trad_obj):
        u"""
        We check if this translation exists in the translations file
        base, to take its value.
        """
        self.send_email = False
        # rb: bytes mode
        # rt: text mode
        with open(TRADSBASE, 'rt') as fcsv:
            trads = {}
            try:
                for trad in list(csv.reader(fcsv, delimiter=','))[1:]:
                    identifier = trad[0].lower()
                    trads[identifier] = {}

                    for num, lang in enumerate(settings.LANGUAGES, start=1):
                        trads[identifier][lang[0]] = trad[num]
            except:
                pass
        # print "TRADS: ",trads
        identifier = trad_obj.identifier.lower()
        if identifier in trads:
            for code, name in settings.LANGUAGES:
                setattr(trad_obj, 'value_%s' % code, trads[identifier][code])
        else:
            # If the translation is not found in the base file
            # Then we will send the mail to the content.
            self.send_email = True

    def _create_trad_record(self):
        u"""We create the translation record in the model"""
        trad_obj = Translation()

        # this method is called when the translation does not exist, so no
        # it is necessary to check again that it does not exist
        scope = self._scope if self._scope == 'page' else 'site'
        setattr(trad_obj, scope, getattr(self, '_' + scope))
        trad_obj.identifier = self._identifier

        # Before saving, we load the base translations file
        # and if we have the value there, we assign it
        self.trads_base(trad_obj)
        trad_obj.save()
        if self.send_email:
            if getattr(settings, 'SEND_TRANSLATION', True):
                self._notify_translation(trad_obj, scope, self._site)
        return trad_obj

    def _notify_translation(self, trad_obj, scope, site):
        try:
            today = str(datetime.date.today().strftime("%Y/%m/%d"))
            subject = u"There is a new translation in %s" % site
            domain = "http://" + self._site.domain_en + "/cms-view/translations.htm"
            message = u"""
                There is a new translation pending in %s:
                Translation: %s
                Scope: %s
                Page: %s
                Site: %s
                Created at: %s
                Domain to upload translation: %s


                May the force be with you.
                """ % (site,
                        trad_obj,
                        scope,
                        str(self._page.code),
                        site,
                        today,
                        domain)
            receiver = getattr(
                self._site,
                'email_translation',
                settings.DEFAULT_NOTIFY_EMAIL.split(','))
            send_mail(subject, message, settings.EMAIL_HOST_USER, receiver, fail_silently=False)
        except Exception as e:
            SendTranslationError(u"There is an error sending the new translation email")

    def _get_trad_object(self):
        u"""
        We return the translation object according to the type of scope and identifier
        """
        scope = self._scope if self._scope == 'page' else 'site'
        kwargs = {
            'identifier': self._identifier,
            scope: getattr(self, '_' + scope)
        }

        try:
            trad_obj = Translation.objects.get(**kwargs)
        except Translation.DoesNotExist:
            trad_obj = self._create_trad_record()
        except Translation.MultipleObjectsReturned:
            trad_obj = Translation.objects.filter(**kwargs)[:1][0]
            logger.warning("Trad %s (%s) duplicated: %s" % (
                self._identifier, self._site, trad_obj)
            )

        return trad_obj

    def _get_translation(self):
        u"""
        We look for the translation to the dictionary for the language that it touches. But
        exists in the database, we will need to create the record.
        """
        # We get the page or global translations, depending on the
        # scope of the requested translation.
        if self._scope == 'page':
            try:
                translations_scope = self._translations.setdefault(self._page.code, {})
            except AttributeError:
                raise TtMalUsado(
                    u'Misused template tag "trad". Check that instead of '
                    u'trad, it doesn\'t have to be tradg. identifier: %s'
                    % self._identifier)
        else:
            translations_scope = self._translations.setdefault(self._site.code, {})

        # Now we can retrieve the concrete translation according to
        # scope and locator
        lang = translation.get_language()
        trans = translations_scope.setdefault(self._identifier, {})
        content = trans.get(lang)

        if content is None:
            trad_obj = self._get_trad_object()
            content = getattr(trad_obj, 'value_' + lang)

            # We save the translation, according to the scope
            code = self._page.code if self._scope == 'page' else self._site.code
            self._translations[code][self._identifier][lang] = content
            self._update_cache()

        return content

    def _render_content(self, content, ctx):
        u"""
        If the content has {{ }}, render it with the context to substitute dynamic tags
        """
        if '{{' in content and '}}' in content:
            template = Template(content)
            return template.render(ctx)
        return content

    def render(self, context):
        u"""
        We load the dictionary of translations from the cache and check if
        there is such an identifier
        """
        request = context.get('request')
        self._site = request.site
        self._page = request.page

        if isinstance(self._identifier, FilterExpression):
            self._identifier = self._identifier.resolve(context)
        else:
            try:
                self._identifier = self._identifier.render(context)
            except AttributeError:
                # When the trad is inside another context, for example a loop,
                # returns a pete of an attributeerror.
                pass

        self._load_cache_translations()
        text = self._get_translation()

        # If the translation is empty, we return
        # the identifier, but through a render, to replace dynamic tags
        if not text:
            return self._render_content(self._identifier, context)

        return self._render_content(text, context)


@register.tag
def trad(parser, token):
    u"""Tag for managing translations to page scope"""
    identifier = token.split_contents()[1]
    identifier = parser.compile_filter(identifier)
    return TradNode(identifier)


@register.tag
def blocktrad(parser, token):
    identifier = parser.parse(('endblocktrad',))
    parser.delete_first_token()
    return TradNode(identifier)


@register.tag
def tradg(parser, token):
    u"""Tag for site scope translation management"""
    identifier = token.split_contents()[1]
    identifier = parser.compile_filter(identifier)
    return TradNode(identifier, scope='site')


@register.tag
def blocktradg(parser, token):
    u"""
    The same as trad, but with a block. Example:
    {% blocktrad%}
        This is a block text
    {% endblocktrad %}
    """
    identifier = parser.parse(('endblocktradg',))
    parser.delete_first_token()
    return TradNode(identifier, scope='site')
