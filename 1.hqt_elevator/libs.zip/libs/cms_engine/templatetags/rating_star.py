# coding: utf-8
from django import template
from django.utils.safestring import mark_safe

register = template.Library()


class RatingStarNode(template.Node):

    def __init__(self, rating):
        self.rating = rating

    def render(self, context):
        try:
            rating = int(self.rating.resolve(context))
        except (TypeError, ValueError):
            rating = 0

        stars = '★' * rating + '☆' * (5 - rating)
        return mark_safe(f"{stars}")


@register.tag
def rating_star(parser, token):
    """
    Usage:
        {% rating_star 5 %}
    """

    args = token.split_contents()

    if len(args) != 2:
        raise template.TemplateSyntaxError(
            "Usage: {% rating_star 5 %}"
        )

    rating = parser.compile_filter(args[1])

    return RatingStarNode(rating)