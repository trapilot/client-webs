# coding: utf-8
import urllib
from PIL import Image
from django import template
from django.conf import settings

register = template.Library()


@register.filter
def imagesize(path, key="w"):
    u"""
    Returns the size of an image. By default, it returns the width of the
    image. If we pass the parameter 'h' it returns the height. can be passed
    an absolute or relative path.

    Usage examples:

        {% load imagesize %}

        {% if photo.url|imagesize < 300 %}...{% endif %}
        {{photo.url|imagesize:"h"}}

        <img src="{{hotel.logo.url}}" title="{{hotel.name}}" alt="{{hotel.name}}" width="{{hotel.logo.url|imagesize}}" height="{{hotel.logo.url|imagesize:"h"}}" />
    """
    path = settings.MEDIA_ROOT + path
    img = Image.open(path)

    value = img.size[1] if key == 'h' or key == 'height' else img.size[0]
    return value
