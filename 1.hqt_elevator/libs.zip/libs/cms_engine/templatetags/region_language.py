# coding: utf-8
from django import template
from django.conf import settings

from cms_engine.defaults import LANGUAGE_REGIONS


register = template.Library()


class IncorrectParameters(Exception):
    pass


class LanguageNotAllowed(Exception):
    pass


class RegionLanguageNode(template.Node):
    u"""
    Adds the REGION_CODE variable to the context depending on the language
    indicated and according to the list available in defaults.py
    """

    def __init__(self, language):
        # at this point it is worth "LANGUAGE_CODE", we have to resolve the variable
        self.language = language

    def render(self, context):
        request = context.get('request')
        project = request.project
        page = request.page
        language = self.language.resolve(context)

        # We check if the project accepts that language
        if not language in project.languages:
            if settings.DEBUG:
                print(u'Language not allowed for this project: %s' % language)
            return ''

        try:
            context['REGION_CODE'] = LANGUAGE_REGIONS[language]
        except KeyError:
            # we use the language code
            context['REGION_CODE'] = language
        return ''

@register.tag
def region_language(parser, token):
    u"""
    How to use:
        {% region_language 'vi' %}
        {% region_language 'en' %}
        {% region_language language %}
    """

    args = token.split_contents()[1:]

    try:
        language = args[0]
    except IndexError:
        raise IncorrectParameters(u'You must indicate the language code')

    return RegionLanguageNode(parser.compile_filter(language))
