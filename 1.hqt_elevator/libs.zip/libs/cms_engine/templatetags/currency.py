from django import template

register = template.Library()


@register.filter
def currency(value, format_string=".,₫"):
    """
    usage:
        {{ currency|price:".,đ" }}

    format_string:
        decimal_sep, currency
    """

    if value is None:
        return ""

    try:
        value = float(value)
    except (TypeError, ValueError):
        return value

    # parse format string
    parts = format_string.split(",")
    decimal_sep = parts[0] if len(parts) > 0 else "."
    currency = parts[1] if len(parts) > 1 else ""

    # format number (default python uses comma for thousands, dot for decimal)
    formatted = f"{value:,.0f}"

    # replace separators
    formatted = formatted.replace(",", "X").replace(".", decimal_sep).replace("X", ".")

    if currency:
        return f"{formatted} {currency}"
    return f"{formatted}"