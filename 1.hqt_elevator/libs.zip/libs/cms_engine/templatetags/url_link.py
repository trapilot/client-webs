# coding: utf-8
from django import template

register = template.Library()


@register.filter
def url_link(link):
    if not link:
        return 'javascript:void(0);'
    return link