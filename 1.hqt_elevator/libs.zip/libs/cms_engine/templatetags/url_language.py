# coding: utf-8
from django import template

from cms_engine.utils import build_page_url

register = template.Library()

class IncorrectParameters(Exception):
    pass

class LanguageNotAllowed(Exception):
    pass

class UrlLanguageNode(template.Node):
    u"""
    This TT generates a complete URL of the page where we are,
    but with the indicated language
    """

    def __init__(self, language, project=None):
        self._language = language
        self._project = project

    def render(self, context):
        project = self._project.resolve(context) if self._project else context['project']
        page = context.get('page')
        language = self._language.resolve(context)

        # We check if the project accepts said language
        if not language in project.languages:
            raise LanguageNotAllowed(u'language not allowed for this project: %s' % language)

        return build_page_url(project, page, language, True)

@register.tag
def url_language(parser, token):
    u"""
    How to use:
         {% url_language 'in' %}
         {% url_language 'en' %}
         {% url_language language %}
         {% url_language language project %}
    """
    args = token.split_contents()[1:]

    try:
        language = parser.compile_filter(args[0])
    except IndexError:
        raise IncorrectParameters(u'You must indicate the language code')
    try:
        project = parser.compile_filter(args[1])
    except IndexError:
        project = None

    return UrlLanguageNode(language, project)
