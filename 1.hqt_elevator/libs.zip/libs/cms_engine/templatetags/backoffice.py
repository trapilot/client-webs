'''
TT for the back office
'''
import re

from django import template
from django.template.loader import get_template
from django.template import Context
from django.conf import settings
from pprint import pprint
from django.template.defaultfilters import title

register = template.Library()


@register.filter
def indexelem(list, index):
    try:
        return list[index]
    except IndexError:
        return ''


@register.filter
def form(form):
    '''
    Draw the form with the classes suitable to best fit boottrap
    '''

    # We detect the initial and final language codes of the system,
    # to check if the field being parsed is i18n. In that case
    # we will transform it to show tabs
    idf = settings.LANGUAGES[0][0]
    idl = settings.LANGUAGES[-1][0]

    for campo in form:
        if '_%s' % idf in campo.name:
            # As it is i18n, we prepare the header of the tabs...
            items, name = [], campo.name.replace('_%s' % idf, '')

            for lang in settings.LANGUAGES:
                items.append({
                    'lang' : '%s' % lang[0].upper(),
                    'lang_code' : lang[0],
                    'name' : '%s_%s' % (name, lang[0]),
                })

            # Items must always be ordered in the same way.
            items = sorted(items, key = lambda item : item['lang'])

            tpl = get_template('backoffice/forms/header_tabs.html')
            contx = Context({'items' : items})
            campo.field.header_tabs = tpl.render(contx)

        if '_%s' % idl in campo.name:
            campo.field.ultimo = True

        # We also mark all i18n fields with a flag
        for lang in settings.LANGUAGES:
            if campo.name.endswith('_%s' % lang[0]):
                campo.field.i18n = True
                campo.field.label = re.sub(r' \(.*\)',  '', campo.label)

    tpl = get_template('backoffice/forms/form.html')
    # contx = Context({ 'form' : form })
    contx = { 'form' : form }

    return tpl.render(contx)
