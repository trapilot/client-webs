
from django import forms
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _


MENU_WM = {}
# try:
#     from bookcore_client.webmobile.constant import MENU_WM
# except ImportError:
#     MENU_WM = {}


class ConstantForm(forms.ModelForm):
    def clean(self):
        name = self.cleaned_data.get('name')
        value = self.cleaned_data.get('value')

        # If we are activating the new webmobile, we need to check
        # that the project has all the pages created so that they appear
        # on the menu
        if name == "WM2" and value == '1':
            project = self.cleaned_data.get('project')
            pages = project.pages
            for menu in MENU_WM.keys():
                if menu != 'category_offers':
                    # At the moment we exclude offers category
                    if menu not in pages:
                        raise ValidationError(
                            _(u'You cannot activate the new webmobile because '
                              u'the project does not have the page %s. '
                              u'Check the documentation '
                              u'https://roiback.atlassian.net/wiki/display/IT/Webmobile+2.0' % menu))

        return self.cleaned_data


class PageAdminForm(forms.ModelForm):
    def clean_code(self):
        u"""
        Until we can use the "unique_together" directive, we prevent
        page code repeat
        """
        
        # there is no need to check if it exists as it is a required field and already checked automatically
        code = self.cleaned_data['code']
        project = self.cleaned_data['project']
        page = self.instance

        if project.page_set.is_activated(code=code).exclude(id=page.id).exists():
            raise ValidationError(_(u'Code exists.'))

        return self.cleaned_data['code']

    def clean_context(self):
        u"""
        We check that the method specified in the context really exists
        """
        context = self.cleaned_data['context']
        if context:
            path = context.split('.')
            try:
                module = __import__('.'.join(path[:-1]), fromlist=path[-1:])
                getattr(module, path[-1])
            except (ImportError, AttributeError):
                raise ValidationError(_(u'Context invalid format'))

        return self.cleaned_data['context']

    def _clean(self, field, lang):
        u"""
        For multilanguage fields, no two values must be the same in two
        different pages for that same language (in different languages yes
        can be. Eg the url "photos" would be the same in Spanish and Catalan)
        """
        project = self.cleaned_data['project']
        page = self.instance

        value = self.cleaned_data['%s_%s' % (field, lang)]
        kwargs = {
            '%s_%s' % (field, lang): value
        }
        if project.page_set.is_activated(**kwargs).exclude(id=page.id).exists():
            raise ValidationError(_(u'Repeated value'))

        return self.cleaned_data['%s_%s' % (field, lang)]

    def __init__(self, *args, **kwargs):
        super(PageAdminForm, self).__init__(*args, **kwargs)

        from functools import partial
        try:
            project = self.fields['project']._queryset[0]
            fields = ['url',]
            for field in fields:
                for lang in project.languages:
                    # self._clean(field, lang)
                    setattr(self, '%s_%s' % (field, lang), partial(self._clean, field, lang))
                    # does not work properly
                    # lambda: self._clean(field, lang))
        except IndexError:
            pass