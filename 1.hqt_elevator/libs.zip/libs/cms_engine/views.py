# coding: utf-8
import base64
import re
import urllib

from django import http
from django.conf import settings
from django.core.cache import cache
from django.views.generic.base import TemplateView, View

from cms_engine.models import Landing
from shared_engine.transmeta import get_real_language


def view_dispatcher(request, path=None):
    page = getattr(request, "page", None)

    if not page:
        raise http.Http404()
    
    pattern = page.pattern_url(request.language)
    if pattern and path:
        matched = re.match(pattern, path)
        if matched:
            return request.page.view_callback(request, **matched.groupdict())
    return request.page.view_callback(request)



class CmsEngineView(TemplateView):
    u"""
    Main control object of the CMS views
    """

    def get(self, request, *args, **kwargs):

        # We retrieve the page object that was passed in the context
        # because we will need it in this view.
        # print(request.page)
        # context = RequestContext(request)
        # self.page = context['page']
        
        self.page = request.page

        # We collect the kwargs, in case there is any url that has
        # parameters. So we can pass them in the context.
        self.parameters = kwargs

        return super(CmsEngineView, self).get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        u"""
        If the page has a context method defined, we execute it and pass it to the template.
        """
        context = super(CmsEngineView, self).get_context_data(**kwargs)

        if self.page.context != '' and not self.page.context is None:
            # If the context is cached, we grab it from there. It is important to add the parameters
            # of the page when constructing the name of the cache, since if for example it is being passed
            # a page number, we are interested in caching this context according to this page number.

            # if there are optional parameters, and they are not being passed, the key
            # will have a null value associated with it, which will cause an error
            values = [value or '' for value in self.parameters.values()]
            cache_key = 'cache_site_context__%s__%s__%s__%s' % (
                self.page.site.code,
                self.page.code,
                get_real_language(),
                '_'.join(values)
            )
            page_context = cache.get(cache_key)

            if not page_context:
                # We import the module
                parts = self.page.context.split('.')
                module = __import__('.'.join(parts[:-1]), fromlist = parts[-1:])

                try:
                    method = getattr(module, parts[-1])
                except AttributeError:
                    raise Exception(u"Context '%s' non-existent" % self.page.context)

                if self.parameters:
                    page_context = method(self.request, self.parameters)
                else:
                    page_context = method(self.request)

                if not isinstance(page_context, dict):
                    raise Exception(u'The context has to return a dictionary')

                # We check if we have to use another template than the one defined in the page
                try:
                    self.template_name = page_context['template_name']
                except KeyError:
                    pass

                # We only cache the context in case it is specified in the model.
                if self.page.cache_context:
                    cache.set(cache_key, page_context, 60 * 60) # 1 hour

            return page_context

        return context


class CmsStaticView(View):
    u"""
    Return static content, like css, js, in a compressed form.

    Sample URL:
    http://web1.roibacktest.com/cms-static/js/js1/?f=http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js,http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.2/jquery-ui.min.js,http://web1.roibacktest.com/bookcore/static/js/jquery.carritotop.min.js,http://web1.roibacktest.com/bookcore/static/js/packsweb/jquery.individual.min.js
    http://web1.roibacktest.com/cms-static/css/css1/?f=
    """

    CONTENT_TYPES = {
        'css': 'text/css',
        'js': 'text/javascript',
        'less': 'text/less'
    }

    CACHE_TIME = 3600 * 24 * 30
    CACHE_CONTROL = 'max-age=1800'
    TIMEOUT = 5

    def dev_content(self, cont):
        u"""We throw the answer"""

        try:
            resp = http.HttpResponse(cont, self.CONTENT_TYPES[self.type])
            resp['Cache-Control'] = self.CACHE_CONTROL
            return resp
        except KeyError:
            print(u'CmsStaticView: There is no content type')
            raise http.Http404

    def compresses(self, content):
        u"""We compress content"""

        if self.type == 'js':
            try:
                from jsmin import jsmin
            except ImportError:
                return cont

            return jsmin(content)
        elif self.type == 'css':
            cont = self.fix_url_paths(content)
            return self.css_min(content)

        return content

    def generate_key(self):
        u"""We generate the key for the cache"""
        try:
            return base64.b64encode(''.join(self.files))
        except TypeError:
            return str(hash(''.join(self.files)))

    def get(self, request, *args, **kwargs):

        # We check that we have the files
        self.files = request.GET.get('f')
        if not self.files:
            print(u'CmsStaticView: not received files')
            raise http.Http404()

        # We can't receive the & character, so we send it as *
        self.files = self.files.replace('*', '&')

        self.files, self.type = self.files.split('|'), kwargs['type']
        cache_key = self.generate_key()

        # If it's in the cache, we return it
        content = cache.get(cache_key)
        if content and 1 == 0:
            return self.dev_content(content)

        # let's generate it
        content = ''
        for file in self.files:

            # If there is no domain, we put it
            if file[0] == '/':
                if settings.DEBUG == True:
                    host = '%s:%s' %('nginx', request.get_port())
                else:
                    host = request.get_host()
                file = 'http://%s%s' % (host, file)

            print(u'CmsStaticView: Reading %s' % file)

            try:
                resp = urllib.request.urlopen(file, timeout=self.TIMEOUT)
            except Exception as ex:
                # All exceptions, we go to the next
                print(u' ERROR!!!')
                if settings.DEBUG == True:
                    print(file, ex)
                continue
            else:
                print('')

            content += '\n' + resp.read().decode('utf-8')
            resp.close()

        content = self.compresses(content)

        # We cache it for the next request
        cache.set(cache_key, content, self.CACHE_TIME)

        return self.dev_content(content)

    def css_min(self, css):
        u"""
        We minimize, compress css chunk. Code extracted from:
        http://stackoverflow.com/questions/222581/python-script-for-minifying-css
        """

        css = re.sub(r'\s*/\*\s*\*/', "$$HACK1$$", css)
        css = re.sub(r'/\*[\s\S]*?\*/', '', css)
        css = css.replace("$$HACK1$$", '/**/')
        css = re.sub(r'url\((["\'])([^)]*)\1\)', r'url(\2)', css)
        css = re.sub(r'\s+', ' ', css)
        css = re.sub(r'#([0-9a-f])\1([0-9a-f])\2([0-9a-f])\3(\s|;)', r'#\1\2\3\4',
            css)
        css = re.sub(r':\s*0(\.\d+([cm]m|e[mx]|in|p[ctx]))\s*;', r':\1;', css)

        return css

    def fix_url_paths(self, css):
        u"""
        As the one who expels the css is another url different from /static/,
        the css does not find the images. We have to convert imgs into absolute urls
        """

        urls = re.findall(r'url\(.*\)', css)

        for url in urls:
            if 'http' in url:
                continue

        return css


class ExternalRequestView(View):
    u"""
    This URL is very useful for making ajax requests to external websites.
    They cannot be done directly from Ajax (the .js) because the
    browser throws an Access-Control-Allow-Origin exception. we can use this
    sight to do.

    For security reasons, requests must always be POST.

    Example:
        $.ajax({
            type : "POST",
            url : "/cms-external-rq",
            data : {
                url: 'http://www.aemet.es/xml/municipios/localidad_25120.xml'
            },
            dataType : "xml",
            headers : {
                "X-CSRFToken" : getCookie("csrftoken")
            },
            success : function(response) {
                console.log(response);
            }
        });

        function getCookie(name) {
            var cookieValue = null;
            if (document.cookie && document.cookie != '') {
                var cookies = document.cookie.split(';');
                for (var i = 0; i < cookies.length; i++) {
                    var cookie = jQuery.trim(cookies[i]);
                    // Does this cookie string begin with the name we want?
                    if (cookie.substring(0, name.length + 1) == (name + '=')) {
                        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                        break;
                    }
                }
            }
            return cookieValue;
        }
    """

    TIMEOUT = 5

    def get(self, request, *args, **kwargs):
        raise http.Http404

    def request(self, url):
        try:
            rs = urllib.request.urlopen(url, timeout=self.TIMEOUT)
        except:
            raise http.Http404

        response = rs.read()
        rs.close()

        return response

    def post(self, request, *args, **kwargs):

        url = request.POST.get('url')
        if not url:
            raise http.Http404

        cache_time = request.POST.get('cache')
        mimetype = request.POST.get('mimetype', 'text/html')

        if cache_time:
            k = 'rq_ext_%s' % url
            response = cache.get(k)

            if not response:
                response = self.request(url)
                cache.set(k, response, int(cache_time))

            return http.HttpResponse(response, content_type=mimetype)

        return http.HttpResponse(self.request(url))
    

class LandingView(TemplateView):
    template_name = 'landing.html'

    def get_context_data(self, **kwargs):
        ctx = super(LandingView, self).get_context_data(**kwargs)
        site = self.request.site
        landing = None

        for language in site.languages:
            params = {
                'site': site,
                'url_%s' % language: kwargs['slug']
            }
            try:
                landing = Landing.objects.get(**params)
            except Landing.DoesNotExist:
                continue
            else:
                break

        if not landing:
            raise http.Http404()

        active_urls = {}
        for lang in site.languages:
            """We need to go through the languages again to know which languages the landing has active."""
            url = getattr(landing, 'url_%s' % lang, None)
            if url:
                active_urls[lang] = url

        ctx['html'] = getattr(landing, 'html_%s' % lang, None)
        ctx['active_urls'] = active_urls

        return ctx
