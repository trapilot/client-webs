from django import forms

from shared_engine.models import FieldType
from site_engine.utils import default_site_code
from site_engine.models import Site
from site_content.models import Product, ProductField, Project, ProjectField, Solution, SolutionField


class EntryAdminForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        site = None

        # 1. edit object
        if self.instance and self.instance.pk:
            site = self.instance.site
        
        elif self.fields['site']:
            site = site = self.fields['site']._queryset[0]

        # 2. form POST (create new)
        elif self.data.get('site'):
            try:
                site = Site.objects.get(pk=self.data.get('site'))
            except Site.DoesNotExist:
                site = None

        # 3. fallback initial
        elif self.initial.get('site'):
            site = self.initial.get('site')

        else:
            site = default_site_code()

        if not site:
            return

        fields = self.get_fields(site)
        existing_values = {}
        if self.instance.pk:
            existing_values = {
                v.field_id: v.value
                for v in self.instance.attribute_set.select_related('field')
            }

        for field in fields:
            value = existing_values.get(field.id)
            if field.type == FieldType.TEXT:
                self.fields[f'dynamic_{field.id}'] = forms.CharField(
                    label=f"{field.label} ({field.unit})" if field.unit else field.label,
                    required=field.required,
                    initial=value or field.default_value,
                    widget=forms.TextInput(attrs={
                        "class": "vTextField"
                    })
                )
            elif field.type == FieldType.NUMBER:
                self.fields[f'dynamic_{field.id}'] = forms.IntegerField(
                    label=f"{field.label} ({field.unit})" if field.unit else field.label,
                    required=field.required,
                    initial=value or field.default_value,
                    widget=forms.TextInput(attrs={
                        "class": "vTextField"
                    })
                )
            elif field.type == FieldType.DECIMAL:
                self.fields[f'dynamic_{field.id}'] = forms.FloatField(
                    label=f"{field.label} ({field.unit})" if field.unit else field.label,
                    required=field.required,
                    initial=value or field.default_value,
                    widget=forms.TextInput(attrs={
                        "class": "vTextField"
                    })
                )
            elif field.type == FieldType.DATE:
                self.fields[f'dynamic_{field.id}'] = forms.DateField(
                    label=f"{field.label} ({field.unit})" if field.unit else field.label,
                    required=field.required,
                    initial=value or field.default_value,
                )
            elif field.type == FieldType.BOOLEAN:
                self.fields[f'dynamic_{field.id}'] = forms.BooleanField(
                    label=f"{field.label} ({field.unit})" if field.unit else field.label,
                    required=False,
                    initial=(value or field.default_value) == 'True',
                )
            elif field.type == FieldType.SELECT:
                self.fields[f'dynamic_{field.id}'] = forms.ChoiceField(
                    label=field.label,
                    required=field.required,
                    initial=value or field.default_value,
                    choices=[("", "---------")] + list(field.choices),
                )

    def get_fields(self, site):
        return []
    
    def save(self, commit=True):
        return super().save(commit)


class ProductAdminForm(EntryAdminForm):
    def get_fields(self, site):
        return ProductField.objects.is_activated(site=site).order_by('sorted_as')

    class Meta:
        model = Product
        fields = '__all__'


class ProjectAdminForm(EntryAdminForm):
    def get_fields(self, site):
        return ProjectField.objects.is_activated(site=site).order_by('sorted_as')

    class Meta:
        model = Project
        fields = '__all__'


class SolutionAdminForm(EntryAdminForm):
    def get_fields(self, site):
        return SolutionField.objects.is_activated(site=site).order_by('sorted_as')

    class Meta:
        model = Solution
        fields = '__all__'

