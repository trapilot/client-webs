from datetime import date

from django.db import models
from django.utils.safestring import mark_safe
from django.utils.translation import  gettext_lazy as _
from django.utils.functional import cached_property

from ckeditor.fields import RichTextField

from shared_engine.managers import GeneralManager
from shared_engine.transmeta import TransMeta
from shared_engine.transcode import upload_to
from shared_engine.models import FieldAttribute, FieldType, TargetType
from site_engine.utils import default_site_code
from site_engine.models import Site


class Category(models.Model, metaclass=TransMeta):
    objects = GeneralManager()
    ADMIN_ORDER = 4
    INTERNAL_SET = True

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='category_dynamic',
        verbose_name=_(u'Site'),
    )

    target_type = models.CharField(_(u'Target'), max_length=20, choices=TargetType.choices, default=TargetType.PRODUCT)
    name = models.CharField(_(u'Name'), max_length=255, unique=True)
    slug = models.SlugField(u'Slug', max_length=255, unique=True)
    code = models.CharField(u'Code', max_length=255, unique=True)
    summary = models.TextField(_(u'Summary'), blank=True)
    content = RichTextField(_(u'Content'), blank=True)
    image = models.ImageField(_(u'Image'), upload_to=upload_to('uploads/category/images'), blank=True)
    
    is_active = models.BooleanField(_(u'Active'), default=True)
    is_homepage = models.BooleanField(_(u'Homepage'), default=False)
    sorted_as = models.PositiveIntegerField(_(u'Sorting'), default=0)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Category')
        verbose_name_plural = _(u'Categories')
        translate = ('name', 'slug', 'summary', 'content',)
        ordering = ['sorted_as', 'is_active']

    def __str__(self):
        return self.name
    

class Product(models.Model, metaclass=TransMeta):
    objects = GeneralManager()
    ADMIN_ORDER = 1
    INTERNAL_SET = True

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='product_set',
        verbose_name=_(u'Site'),
    )

    category = models.ForeignKey(
        Category,
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name='product_set',
        verbose_name=_(u'Category'),
    )

    code = models.CharField(_(u'Code'), max_length=255, unique=True)    
    name = models.CharField(_(u'Name'), max_length=255)
    slug = models.SlugField(_(u'Slug'), max_length=255, unique=True)
    summary = models.TextField(_(u'Summary'), blank=True, null=True)
    content = RichTextField(_(u'Content'), null=True, blank=True)
    image = models.ImageField(_(u'Image'), blank=True, null=True, upload_to=upload_to('uploads/product/images'))
    video = models.FileField(_(u'Video'), null=True, blank=True, upload_to=upload_to('uploads/product/videos'))
    pdf = models.FileField(_(u'Pdf'), null=True, blank=True, upload_to=upload_to('uploads/product/pdfs'))
    
    icon_svg = models.TextField(_(u'Svg'), blank=True, null=True)
    icon_img = models.ImageField(_(u'Icon'), blank=True, null=True, upload_to=upload_to('uploads/product/icons'))
    icon_name = models.CharField(_(u'Name'), max_length=150, blank=True, null=True)
    icon_code = models.CharField(_(u'Code'), max_length=30, blank=True, null=True,
        help_text=mark_safe("<a target='_blank' href='https://fontawesome.com/search?o=r&f=brands'>https://fontawesome.com/search?o=r&f=brands</a>"),
    )

    is_active = models.BooleanField(_(u'Active'), default=True)
    is_homepage = models.BooleanField(_(u'Homepage'), default=False)
    sorted_as = models.PositiveIntegerField(_(u'Sorting'), default=0)
    visited_as = models.PositiveIntegerField(_(u'View Count'), default=0)

    # Badge
    is_vip = models.BooleanField(_(u'High Class'), default=False)
    is_new = models.BooleanField(_(u'New'), default=False)
    is_popular = models.BooleanField(_(u'Popular'), default=False)
    is_bestseller = models.BooleanField(_(u'Bestseller'), default=False)

    # Price
    base_price = models.DecimalField(_(u'Base Price'), null=True, blank=True, max_digits=15, decimal_places=0)
    sale_price = models.DecimalField(_(u'Sale Price'), null=True, blank=True, max_digits=15, decimal_places=0)
    
    # Meta
    meta_title = models.CharField(_(u'Meta title'), null=True, blank=True, max_length=200)
    meta_description = models.CharField(_(u'Meta description'), null=True, blank=True, max_length=500)
    meta_keywords = models.CharField(_(u'Meta keywords'), null=True, blank=True, max_length=300)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Product')
        verbose_name_plural = _(u'Products')
        translate = ('name', 'slug', 'summary', 'content', 'meta_title', 'meta_description', 'meta_keywords',)
        ordering = ['sorted_as', 'is_active', 'is_homepage']

    def __str__(self):
        return self.name or self.code
    
    @cached_property
    def attributes(self):
        attrs = {}
        for attribute in self.attribute_set.select_related("field").all():
            try:
                field = attribute.field
                attr_value = attribute.value or ""
                attr_unit = field.unit or ""

                # handle SELECT type
                if attr_value and field.type == FieldType.SELECT:
                    choices = dict(field.choices)
                    attr_value = choices.get(attr_value, attr_value)

                attrs[field.name] = attr_value
                attrs[f"{field.name}_unit"] = attr_unit

                if field.unit and attr_value:
                    attrs[f"{field.name}_disp"] = f"{attr_value} {attr_unit}".strip()
                    attrs[f"{field.name}_disp_compact"] = f"{attr_value}{attr_unit}".strip()
                else:
                    attrs[f"{field.name}_disp"] = f"{attr_value}".strip()
                    attrs[f"{field.name}_disp_compact"] = f"{attr_value}".strip()
            except Exception:
                pass
        return attrs
    
    @property
    def has_discount(self):
        if self.sale_price and self.base_price:
            return self.sale_price < self.base_price
        return False
    
    @property
    def discount_percent(self):
        if self.has_discount:
            return round((self.base_price - self.sale_price) / self.base_price * 100)
        return 0
    

class ProductField(FieldAttribute):
    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='product_field_set',
        verbose_name=_(u'Site'),
    )
    
    class Meta:
        verbose_name = _(u'Product Field')
        verbose_name_plural = _(u'Product Fields')
        ordering = ['sorted_as', 'is_active']

class ProductAttribute(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='attribute_set')
    field = models.ForeignKey(ProductField, on_delete=models.CASCADE)
    value = models.TextField(blank=True, null=True)

    class Meta:
        unique_together = ('product', 'field',)

    def __str__(self):
        return f'{self.product} - {self.field}'
    
    def clean(self):
        if self.field:
            self.value = self.field.clean_value(self.value)

class ProductFeature(models.Model, metaclass=TransMeta):
    objects = GeneralManager()
    
    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        related_name='feature_set',
        verbose_name=_(u'Product'),
    )

    label = models.CharField(_(u'Feature'), max_length=200)
    value = models.CharField(_(u'Value'), null=True, blank=True, max_length=200)
    
    icon_svg = models.TextField(_(u'Svg'), blank=True, null=True)
    icon_img = models.ImageField(_(u'Icon'), blank=True, null=True, upload_to=upload_to('uploads/product/features'))
    icon_name = models.CharField(_(u'Name'), max_length=150, blank=True, null=True)
    icon_code = models.CharField(_(u'Code'), max_length=30, blank=True, null=True,
        help_text=mark_safe("<a target='_blank' href='https://fontawesome.com/search?o=r&f=brands'>https://fontawesome.com/search?o=r&f=brands</a>"),
    )

    is_active = models.BooleanField(_(u'Active'), default=True)
    sorted_as = models.PositiveIntegerField(_(u'Sorting'), default=0)

    class Meta:
        verbose_name = _(u'Feature')
        verbose_name_plural = _(u'Features')
        translate = ('label', 'value',)
        ordering = ['sorted_as', 'is_active']

    def __str__(self):
        return f"{self.product} - {self.label}"

class ProductFaq(models.Model, metaclass=TransMeta):
    objects = GeneralManager()
    
    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        related_name='faq_set',
        verbose_name=_(u'Product'),
    )

    question = models.CharField(_(u'Question'), max_length=200)
    answer = models.CharField(_(u'Answer'), null=True, blank=True, max_length=200)
    icon = models.CharField(_(u'Icon'), null=True, blank=True, max_length=100, help_text=mark_safe("<a target='_blank' href='https://fontawesome.com/search>https://fontawesome.com/search</a>"),)
    is_active = models.BooleanField(_(u'Active'), default=True)
    sorted_as = models.IntegerField(_(u'Sorting'), null=True, blank=True, default=0)

    class Meta:
        verbose_name = _(u'Product FAQ')
        verbose_name_plural = _(u'Product FAQs')
        translate = ('question', 'answer',)
        ordering = ['sorted_as', 'is_active']

    def __str__(self):
        return f"{self.product.name} - {self.question}"
    
class ProductGallery(models.Model, metaclass=TransMeta):
    objects = GeneralManager()
    
    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        related_name='gallery_set',
        verbose_name=_(u'Product'),
    )

    image = models.ImageField(_(u'Image'), upload_to=upload_to('uploads/product/galleries'), null=True, blank=True)

    is_active = models.BooleanField(_(u'Active'), default=True)
    sorted_as = models.PositiveIntegerField(_(u'Sorting'), default=0)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)

    class Meta:
        verbose_name = _(u'Gallery')
        verbose_name_plural = _(u'Galleries')
        ordering = ['sorted_as', 'is_active',]

    def __str__(self):
        return f"{self.product} - {self.created_at}"
    

class Project(models.Model, metaclass=TransMeta):
    objects = GeneralManager()
    ADMIN_ORDER = 2
    INTERNAL_SET = True

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='project_set',
        verbose_name=_(u'Site'),
    )

    category = models.ForeignKey(
        Category,
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name='project_set',
        verbose_name=_(u'Category'),
    )
    
    products_used = models.ManyToManyField(
        Product,
        blank=True,
        related_name='products_used',
        verbose_name=_(u'Used Products')
    )

    slug = models.SlugField(_(u'Slug'), max_length=255, unique=True)
    name = models.CharField(_(u'Name'), max_length=255)
    label = models.CharField(_(u'Label'), max_length=255, blank=True, null=True)
    summary = models.TextField(_(u'Summary'), blank=True, null=True)
    content = RichTextField(_(u'Content'), blank=True, null=True)
    address = models.CharField(_(u'Address'), max_length=255, blank=True, null=True)
    image = models.ImageField(_(u'Image'), blank=True, null=True, upload_to=upload_to('uploads/project/images'))
    video = models.FileField(_(u'Video'), null=True, blank=True, upload_to=upload_to('uploads/project/videos'))

    icon_svg = models.TextField(_(u'Svg'), blank=True, null=True)
    icon_img = models.ImageField(_(u'Icon'), blank=True, null=True, upload_to=upload_to('uploads/project/icons'))
    icon_name = models.CharField(_(u'Name'), max_length=150, blank=True, null=True)
    icon_code = models.CharField(_(u'Code'), max_length=30, blank=True, null=True,
        help_text=mark_safe("<a target='_blank' href='https://fontawesome.com/search?o=r&f=brands'>https://fontawesome.com/search?o=r&f=brands</a>"),
    )

    is_active = models.BooleanField(_(u'Active'), default=True)
    is_homepage = models.BooleanField(_(u'Homepage'), default=False)
    sorted_as = models.PositiveIntegerField(_(u'Sorting'), default=0)
    visited_as = models.PositiveIntegerField(_(u'View Count'), default=0)
    
    opened_date = models.DateField(_(u'Opened Date'), blank=True, null=True)
    closed_date = models.DateField(_(u'Closed Date'), blank=True, null=True)

    # Meta
    meta_title = models.CharField(_(u'Meta title'), null=True, blank=True, max_length=200)
    meta_description = models.CharField(_(u'Meta description'), null=True, blank=True, max_length=500)
    meta_keywords = models.CharField(_(u'Meta keywords'), null=True, blank=True, max_length=300)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Project')
        verbose_name_plural = _(u'Projects')
        translate = ('name', 'slug', 'label', 'address', 'summary', 'content', 'meta_title', 'meta_description', 'meta_keywords',)
        ordering = ['sorted_as', 'is_active']

    def __str__(self):
        return self.name
    
    @cached_property
    def attributes(self):
        attrs = {}
        for attribute in self.attribute_set.select_related("field").all():
            try:
                attr_value = attribute.value or ""
                attr_unit = attribute.field.unit or ""

                attrs[attribute.field.name] = attr_value
                attrs[f"{attribute.field.name}_unit"] = attr_unit
                if attribute.field.unit and attr_value:
                    attrs[f"{attribute.field.name}_disp"] = f"{attr_value}{attr_unit}"
                else:
                    attrs[f"{attribute.field.name}_disp"] = f"{attr_value}"
            except Exception:
                pass
        return attrs
    
    @property
    def closed(self):
        return self.closed_date is not None
        
    @property
    def duration(self):
        if not self.opened_date:
            return None

        closed_date = self.closed_date or date.today()

        total_days = (closed_date - self.opened_date).days

        months = (
            (closed_date.year - self.opened_date.year) * 12
            + (closed_date.month - self.opened_date.month)
        )

        if closed_date.day < self.opened_date.day:
            months -= 1

        total_years = months // 12
        remaining_months = months % 12

        # rebuild date after subtracting years/months
        temp_date = self.opened_date.replace(
            year=self.opened_date.year + total_years,
            month=self.opened_date.month
        )

        # fix month overflow safely
        try:
            anchor_date = temp_date
        except ValueError:
            # fallback nếu ngày không hợp lệ (31 Feb...)
            anchor_date = temp_date.replace(day=1)

        remaining_days = (closed_date - anchor_date).days

        return {
            "total_years": total_years,
            "total_months": max(months, 0),
            "total_days": total_days,
            "remaining_months": remaining_months,
            "remaining_days": max(remaining_days, 0),
        }

    @property
    def duration_days(self):
        d = self.duration
        return d["total_days"] if d else ""


    @property
    def duration_months(self):
        d = self.duration
        return d["total_months"] if d else ""


    @property
    def duration_years(self):
        d = self.duration
        return d["years"] if d else ""
    
    @property
    def duration_remaining_days(self):
        d = self.duration
        return d["remaining_days"] if d else 0
    
    @property
    def is_closed(self):
        if not self.closed_date:
            return False
        return (self.closed_date - date.today()).days <= 0
    
    @property
    def closed_year(self):
        if self.is_closed:
            return self.closed_date.year
        return ""
    
    @property
    def closed_month(self):
        if self.is_closed:
            return self.closed_date.month
        return ""
    
    @property
    def closed_day(self):
        if self.is_closed:
            return self.closed_date.day
        return ""

class ProjectField(FieldAttribute):
    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='project_field_set',
        verbose_name=_(u'Site'),
    )
    
    class Meta:
        verbose_name = _(u'Project Field')
        verbose_name_plural = _(u'Project Fields')
        ordering = ['sorted_as', 'is_active']

class ProjectAttribute(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='attribute_set')
    field = models.ForeignKey(ProjectField, on_delete=models.CASCADE)
    value = models.TextField(blank=True, null=True)

    class Meta:
        unique_together = ('project', 'field',)

    def __str__(self):
        return f'{self.project} - {self.field}'
    
    def clean(self):
        if self.field:
            self.value = self.field.clean_value(self.value)

class ProjectFeature(models.Model, metaclass=TransMeta):
    objects = GeneralManager()
    
    project = models.ForeignKey(
        Project,
        on_delete=models.CASCADE,
        related_name='feature_set',
        verbose_name=_(u'Project'),
    )

    label = models.CharField(_(u'Feature'), max_length=200)
    value = models.CharField(_(u'Value'), null=True, blank=True, max_length=200)
    
    icon_svg = models.TextField(_(u'Svg'), blank=True, null=True)
    icon_img = models.ImageField(_(u'Icon'), blank=True, null=True, upload_to=upload_to('uploads/project/features'))
    icon_name = models.CharField(_(u'Name'), max_length=150, blank=True, null=True)
    icon_code = models.CharField(_(u'Code'), max_length=30, blank=True, null=True,
        help_text=mark_safe("<a target='_blank' href='https://fontawesome.com/search?o=r&f=brands'>https://fontawesome.com/search?o=r&f=brands</a>"),
    )

    is_active = models.BooleanField(_(u'Active'), default=True)
    sorted_as = models.PositiveIntegerField(_(u'Sorting'), default=0)

    class Meta:
        verbose_name = _(u'Feature')
        verbose_name_plural = _(u'Features')
        translate = ('label', 'value',)
        ordering = ['sorted_as', 'is_active']

    def __str__(self):
        return f"{self.project} - {self.label}"
    
class ProjectGallery(models.Model, metaclass=TransMeta):
    objects = GeneralManager()
    
    project = models.ForeignKey(
        Project,
        on_delete=models.CASCADE,
        related_name='gallery_set',
        verbose_name=_(u'Project'),
    )

    image = models.ImageField(_(u'Image'), upload_to=upload_to('uploads/project/galleries'), null=True, blank=True)

    is_active = models.BooleanField(_(u'Active'), default=True)
    sorted_as = models.PositiveIntegerField(_(u'Sorting'), default=0)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)

    class Meta:
        verbose_name = _(u'Gallery')
        verbose_name_plural = _(u'Galleries')
        ordering = ['sorted_as', 'is_active',]

    def __str__(self):
        return f"{self.project} - {self.created_at}"
    

class Solution(models.Model, metaclass=TransMeta):
    objects = GeneralManager()
    ADMIN_ORDER = 3
    INTERNAL_SET = True

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='solution_set',
        verbose_name=_(u'Site'),
    )

    category = models.ForeignKey(
        Category,
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name='solution_set',
        verbose_name=_(u'Category'),
    )
    
    slug = models.SlugField(_(u'Slug'), max_length=255, unique=True)
    name = models.CharField(_(u'Title'), max_length=255)
    label = models.CharField(_(u'Label'), max_length=255, blank=True, null=True)
    summary = models.TextField(_(u'Summary'), blank=True, null=True)
    content = RichTextField(_(u'Content'), blank=True, null=True)
    image = models.ImageField(_(u'Image'), blank=True, null=True, upload_to=upload_to('uploads/solution/images'))
    video = models.FileField(_(u'Video'), null=True, blank=True, upload_to=upload_to('uploads/solution/videos'))

    icon_svg = models.TextField(_(u'Svg'), blank=True, null=True)
    icon_img = models.ImageField(_(u'Icon'), blank=True, null=True, upload_to=upload_to('uploads/solution/icons'))
    icon_name = models.CharField(_(u'Name'), max_length=150, blank=True, null=True)
    icon_code = models.CharField(_(u'Code'), max_length=30, blank=True, null=True,
        help_text=mark_safe("<a target='_blank' href='https://fontawesome.com/search?o=r&f=brands'>https://fontawesome.com/search?o=r&f=brands</a>"),
    )

    is_active = models.BooleanField(_(u'Active'), default=True)
    is_homepage = models.BooleanField(_(u'Homepage'), default=False)
    sorted_as = models.PositiveIntegerField(_(u'Sorting'), default=0)
    visited_as = models.PositiveIntegerField(_(u'View Count'), default=0)
    
    # Meta
    meta_title = models.CharField(_(u'Meta title'), null=True, blank=True, max_length=200)
    meta_description = models.CharField(_(u'Meta description'), null=True, blank=True, max_length=500)
    meta_keywords = models.CharField(_(u'Meta keywords'), null=True, blank=True, max_length=300)
    
    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Solution')
        verbose_name_plural = _(u'Solutions')
        translate = ('name', 'slug', 'label', 'summary', 'content', 'meta_title', 'meta_description', 'meta_keywords',)
        ordering = ['sorted_as', 'is_active']

    def __str__(self):
        return self.name
    
    @cached_property
    def attributes(self):
        attrs = {}
        for attribute in self.attribute_set.select_related("field").all():
            try:
                attr_value = attribute.value or ""
                attr_unit = attribute.field.unit or ""

                attrs[attribute.field.name] = attr_value
                attrs[f"{attribute.field.name}_unit"] = attr_unit
                if attribute.field.unit and attr_value:
                    attrs[f"{attribute.field.name}_disp"] = f"{attr_value}{attr_unit}"
                else:
                    attrs[f"{attribute.field.name}_disp"] = f"{attr_value}"
            except Exception:
                pass
        return attrs

class SolutionField(FieldAttribute):
    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='solution_field_set',
        verbose_name=_(u'Site'),
    )
    
    class Meta:
        verbose_name = _(u'Solution Field')
        verbose_name_plural = _(u'Solution Fields')
        ordering = ['sorted_as', 'is_active']

class SolutionAttribute(models.Model):
    solution = models.ForeignKey(Solution, on_delete=models.CASCADE, related_name='attribute_set')
    field = models.ForeignKey(SolutionField, on_delete=models.CASCADE)
    value = models.TextField(blank=True, null=True)

    class Meta:
        unique_together = ('solution', 'field',)

    def __str__(self):
        return f'{self.solution} - {self.field}'
    
    def clean(self):
        if self.field:
            self.value = self.field.clean_value(self.value)

class SolutionFeature(models.Model, metaclass=TransMeta):
    objects = GeneralManager()
    
    solution = models.ForeignKey(
        Solution,
        on_delete=models.CASCADE,
        related_name='feature_set',
        verbose_name=_(u'Solution'),
    )

    label = models.CharField(_(u'Feature'), max_length=200)
    value = models.CharField(_(u'Value'), null=True, blank=True, max_length=200)
    
    icon_svg = models.TextField(_(u'Svg'), blank=True, null=True)
    icon_img = models.ImageField(_(u'Icon'), blank=True, null=True, upload_to=upload_to('uploads/solution/features'))
    icon_name = models.CharField(_(u'Name'), max_length=150, blank=True, null=True)
    icon_code = models.CharField(_(u'Code'), max_length=30, blank=True, null=True,
        help_text=mark_safe("<a target='_blank' href='https://fontawesome.com/search?o=r&f=brands'>https://fontawesome.com/search?o=r&f=brands</a>"),
    )

    is_active = models.BooleanField(_(u'Active'), default=True)
    sorted_as = models.PositiveIntegerField(_(u'Sorting'), default=0)

    class Meta:
        verbose_name = _(u'Feature')
        verbose_name_plural = _(u'Features')
        translate = ('label', 'value',)
        ordering = ['sorted_as', 'is_active']

    def __str__(self):
        return f"{self.solution} - {self.label}"
    

class SolutionGallery(models.Model, metaclass=TransMeta):
    objects = GeneralManager()
    
    solution = models.ForeignKey(
        Solution,
        on_delete=models.CASCADE,
        related_name='gallery_set',
        verbose_name=_(u'Solution'),
    )

    image = models.ImageField(_(u'Image'), upload_to=upload_to('uploads/solution/galleries'), null=True, blank=True)

    is_active = models.BooleanField(_(u'Active'), default=True)
    sorted_as = models.PositiveIntegerField(_(u'Sorting'), default=0)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)

    class Meta:
        verbose_name = _(u'Gallery')
        verbose_name_plural = _(u'Galleries')
        ordering = ['sorted_as', 'is_active',]

    def __str__(self):
        return f"{self.solution} - {self.created_at}"
    

from site_content.signals import *
