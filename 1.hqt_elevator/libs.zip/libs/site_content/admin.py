from django.conf import settings
from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from django.utils.html import format_html

from shared_engine.transmeta import get_real_fieldname as __, get_lable_language as ___
from shared_engine.admin import AdminFeature, AdminTabularInline
from shared_engine.models import TargetType
from site_engine.models import Site
from site_content.models import (
    Category,
    Product, ProductFeature, ProductGallery, ProductField, ProductAttribute, ProductFaq,
    Project, ProjectFeature, ProjectGallery, ProjectField, ProjectAttribute,
    Solution, SolutionFeature, SolutionGallery, SolutionField, SolutionAttribute,
)
from site_content.forms import ProductAdminForm, ProjectAdminForm, SolutionAdminForm


class CategoryAdmin(AdminFeature):
    feature_key = Site.FeatureFlag.TARGET_CATEGORY
    list_display = (__('name'), 'target_type', 'code', 'site', 'is_active', 'is_homepage', 'sorted_as',)
    list_editable = ('is_active', 'is_homepage', 'sorted_as',)
    prepopulated_fields = {}
    fieldsets = [
        [_(u'General'), {
            'fields': (
                'site', 'target_type', 'code', 'image', 'is_homepage',
                ('sorted_as', 'is_active',),
            )
        }],
    ]

    for code, name in settings.LANGUAGES:
        prepopulated_fields[__('slug', code)] = (__('name', code),)
        fieldsets.append(
            (___('Content', name), {
                'fields': Category.append_lang_fields(code)
            })
        )
admin.site.register(Category, CategoryAdmin)

class ProductFeatureAdmin(AdminTabularInline):
    model = ProductFeature
    fields = []
    for code, name in settings.LANGUAGES:
        fields += ProductFeature.append_lang_fields(code)
    fields += ('sorted_as', 'is_active',)
    
class ProductGalleryAdmin(AdminTabularInline):
    model = ProductGallery
    fields = ['image',]
    for code, name in settings.LANGUAGES:
        fields += ProductGallery.append_lang_fields(code)
    fields += ('sorted_as', 'is_active',)

class ProductFaqAdmin(AdminTabularInline):
    model = ProductFaq
    fields = []
    for code, name in settings.LANGUAGES:
        fields += ProductFaq.append_lang_fields(code)
    fields += ('sorted_as', 'is_active',)

@admin.register(ProductField)
class ProductFieldAdmin(AdminFeature):
    feature_key = Site.FeatureFlag.TARGET_FIELD
    list_display = ('name', 'label', 'unit', 'type', 'default_value', 'is_active', 'required', 'sorted_as')
    list_editable = ('is_active', 'required', 'sorted_as',)

@admin.register(Product)
class ProductAdmin(AdminFeature):
    feature_key = Site.FeatureFlag.PRODUCT
    form = ProductAdminForm
    change_form_template = "admin/dynamic_attribute_form.html"
    inlines = [ProductFeatureAdmin, ProductFaqAdmin, ProductGalleryAdmin]
    list_display = ('code', 'category', __('name'), 'price_display', 'is_active', 'is_homepage', 'sorted_as', 'visited_as')
    prepopulated_fields = {}
    fieldsets = [
        [_(u'General'), {
            'fields': (
                'site',
                'category',
                'image',
                'video',
                'pdf',
                'visited_as',
                'is_homepage',
                ('sorted_as', 'is_active',),
            )
        }],
        [_(u'Badges & Status'), {
            'fields': (
                ('is_vip', 'is_new', 'is_popular', 'is_bestseller',),
            )
        }],
        [_(u'Price'), {
            'fields': (
                'base_price',
                'sale_price',
            )
        }],
        [_(u'Code'), {
            'fields': (
                ('code',),
            )
        }],
    ]
    
    for code, name in settings.LANGUAGES:
        prepopulated_fields[__('slug', code)] = (__('name', code),)
        fieldsets.append(
            (___('Content', name), {
                'fields': Product.append_lang_fields(code)
            })
        )
    
    def price_display(self, obj):
        if obj.sale_price:
            return format_html(
                '<span style="text-decoration: line-through; color: red;">{}</span> → <b>{}</b>',
                int(obj.base_price),
                int(obj.sale_price)
            )
        if obj.base_price:
            return format_html('<b>{}</b>', int(obj.base_price))
        return ''
    price_display.short_description = _(u'Price')
    
    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == "category":
            kwargs["queryset"] = Category.objects.filter(
                target_type=TargetType.PRODUCT
            )
        return super().formfield_for_foreignkey(
            db_field, request, **kwargs
        )

    def save_model(self, request, obj, form, change):
        super().save_model(request, obj, form, change)
        
        if not obj.site_id:
            return

        fields = ProductField.objects.filter(site_id=obj.site_id)
        for field in fields:
            value = form.cleaned_data.get(f'dynamic_{field.id}')
            ProductAttribute.objects.update_or_create(
                product_id=obj.id,
                field_id=field.id,
                defaults={
                    'value': str(value)
                    if field.is_active and value is not None
                    else '',
                }
            )


class SolutionFeatureAdmin(AdminTabularInline):
    model = SolutionFeature
    fields = []
    for code, name in settings.LANGUAGES:
        fields += SolutionFeature.append_lang_fields(code)
    fields += ('sorted_as', 'is_active',)

class SolutionGalleryAdmin(AdminTabularInline):
    model = SolutionGallery
    fields = ['image',]
    for code, name in settings.LANGUAGES:
        fields += SolutionGallery.append_lang_fields(code)
    fields += ('sorted_as', 'is_active',)

@admin.register(SolutionField)
class SolutionFieldAdmin(AdminFeature):
    feature_key = Site.FeatureFlag.TARGET_FIELD
    list_display = ('name', 'label', 'unit', 'type', 'default_value', 'is_active', 'required', 'sorted_as')
    list_editable = ('is_active', 'required', 'sorted_as',)

@admin.register(Solution)
class SolutionAdmin(AdminFeature):
    feature_key = Site.FeatureFlag.SOLUTION
    form = SolutionAdminForm
    change_form_template = "admin/dynamic_attribute_form.html"
    inlines = [SolutionFeatureAdmin, SolutionGalleryAdmin]
    list_display = (__('name'), __('label'), 'category', 'is_active', 'is_homepage', 'sorted_as',)
    prepopulated_fields = {'slug': ('name',)}
    
    fieldsets = [
        [_(u'General'), {
            'fields': (
                'site',
                'category',
                'image',
                'video',
                'is_homepage',
                ('sorted_as', 'is_active',),
            )
        }],
        [_(u'Icon'), {
            'fields': (
                'icon_img',
                ('icon_code', 'icon_name',),
                'icon_svg',
            )
        }],
    ]

    prepopulated_fields = {}
    for code, name in settings.LANGUAGES:
        prepopulated_fields[__('slug', code)] = (__('name', code),)
        fieldsets.append(
            (___('Content', name), {
                'fields': Solution.append_lang_fields(code)
            })
        )
    
    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == "category":
            kwargs["queryset"] = Category.objects.filter(
                target_type=TargetType.SOLUTION
            )
        return super().formfield_for_foreignkey(
            db_field, request, **kwargs
        )

    def save_model(self, request, obj, form, change):
        super().save_model(request, obj, form, change)
        
        if not obj.site_id:
            return

        fields = SolutionField.objects.filter(site_id=obj.site_id)
        for field in fields:
            value = form.cleaned_data.get(f'dynamic_{field.id}')
            SolutionAttribute.objects.update_or_create(
                solution_id=obj.id,
                field_id=field.id,
                defaults={
                    'value': str(value)
                    if field.is_active and value is not None
                    else '',
                }
            )


class ProjectFeatureAdmin(AdminTabularInline):
    model = ProjectFeature
    fields = []
    for code, name in settings.LANGUAGES:
        fields += ProjectFeature.append_lang_fields(code)
    fields += ('sorted_as', 'is_active',)

class ProjectGalleryAdmin(AdminTabularInline):
    model = ProjectGallery
    fields = ['image',]
    for code, name in settings.LANGUAGES:
        fields += ProjectGallery.append_lang_fields(code)
    fields += ('sorted_as', 'is_active',)

@admin.register(ProjectField)
class ProjectFieldAdmin(AdminFeature):
    feature_key = Site.FeatureFlag.TARGET_FIELD
    list_display = ('name', 'label', 'unit', 'type', 'default_value', 'is_active', 'required', 'sorted_as')
    list_editable = ('is_active', 'required', 'sorted_as',)

@admin.register(Project)
class ProjectAdmin(AdminFeature):
    feature_key = Site.FeatureFlag.PROJECT
    form = ProjectAdminForm
    change_form_template = "admin/dynamic_attribute_form.html"
    inlines = [ProjectFeatureAdmin, ProjectGalleryAdmin]
    list_display = (__('name'), __('label'), __('address'), 'category', 'is_active', 'is_homepage', 'sorted_as',)
    prepopulated_fields = {}
    fieldsets = [
        [_(u'General'), {
            'fields': (
                'site',
                'category',
                'image',
                'video',
                'opened_date',
                'closed_date',
                'visited_as',
                'is_homepage',
                ('sorted_as', 'is_active',),
            )
        }],
        [_(u'Icon'), {
            'fields': (
                'icon_img',
                ('icon_code', 'icon_name',),
                'icon_svg',
            )
        }],
    ]

    for code, name in settings.LANGUAGES:
        prepopulated_fields[__('slug', code)] = (__('name', code),)
        fieldsets.append(
            (___('Content', name), {
                'fields': Project.append_lang_fields(code)
            })
        )
    
    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == "category":
            kwargs["queryset"] = Category.objects.filter(
                target_type=TargetType.PROJECT
            )
        return super().formfield_for_foreignkey(
            db_field, request, **kwargs
        )

    def save_model(self, request, obj, form, change):
        super().save_model(request, obj, form, change)
        
        if not obj.site_id:
            return

        fields = ProjectField.objects.filter(site_id=obj.site_id)
        for field in fields:
            value = form.cleaned_data.get(f'dynamic_{field.id}')
            ProjectAttribute.objects.update_or_create(
                project_id=obj.id,
                field_id=field.id,
                defaults={
                    'value': str(value)
                    if field.is_active and value is not None
                    else '',
                }
            )
