from django.conf import settings
from django.contrib import admin
from django.utils.translation import gettext_lazy as _

from shared_engine.transmeta import get_real_fieldname as __, get_lable_language as ___
from shared_engine.admin import AdminFeature
from site_engine.models import Site
from site_blog.models import Category, Post, Tag


class CategoryAdmin(AdminFeature):
    feature_key = Site.FeatureFlag.BLOG
    list_display = (__('name'), 'code', 'site', 'is_active', 'sorted_as',)
    list_editable = ('is_active', 'sorted_as',)
    fieldsets = [
        [_(u'General'), {
            'fields': (
                'site', 'code', 'image', 'video',
                ('sorted_as', 'is_active',),
            )
        }],
        [_(u'Icon'), {
            'fields': (
                'icon_img',
                ('icon_code', 'icon_name',),
                'icon_svg',
            )
        }],
    ]

    for code, name in settings.LANGUAGES:
        fieldsets.append(
            (___('Content', name), {
                'fields': Category.append_lang_fields(code)
            })
        )
admin.site.register(Category, CategoryAdmin)


class TagAdmin(AdminFeature):
    feature_key = Site.FeatureFlag.BLOG
    list_display = (__('name'), 'code', 'site', 'sorted_as', 'is_active')
    fieldsets = [
        [_(u'General'), {
            'fields': (
                'site', 'code',
                ('sorted_as', 'is_active',),
            )
        }],
        [_(u'Icon'), {
            'fields': (
                'icon_img',
                ('icon_code', 'icon_name',),
                'icon_svg',
            )
        }],
    ]

    for code, name in settings.LANGUAGES:
        fieldsets.append(
            (___('Content', name), {
                'fields': Tag.append_lang_fields(code)
            })
        )
admin.site.register(Tag, TagAdmin)


class PostAdmin(AdminFeature):
    feature_key = Site.FeatureFlag.BLOG
    list_display = ('title', 'site', 'author', 'category', 'is_active', 'published_at', 'sorted_as',)
    list_editable = ('is_active', 'published_at', 'sorted_as',)
    preserve_filters = True

    fieldsets = [
        [_(u'General'), {
            'fields': (
                'site',
                'category',
                'tags',
                # ('categories', 'tags',),
                'image', 'icon',
                ('published_at',),
                ('author', 'visited_as',),
                ('sorted_as', 'is_active',),
            )
        }]
    ]

    prepopulated_fields = {}
    for code, name in settings.LANGUAGES:
        prepopulated_fields[__('slug', code)] = (__('title', code),)
        fieldsets.append(
            (___('Content', name), {
                'fields': Post.append_lang_fields(code)
            })
        )
admin.site.register(Post, PostAdmin)
