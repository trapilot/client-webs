from datetime import date

from django.db import models
from django.db.models import Q, Case, When, Value, IntegerField, Count
from django.utils.safestring import mark_safe
from django.utils.translation import  gettext_lazy as _

from ckeditor.fields import RichTextField
from smart_selects.db_fields import ChainedManyToManyField

from shared_engine.managers import GeneralManager
from shared_engine.transmeta import TransMeta
from shared_engine.transcode import upload_to
from site_engine.utils import default_site_code
from site_engine.models import Site


class Category(models.Model, metaclass=TransMeta):
    objects = GeneralManager()
    ADMIN_ORDER = 3
    INTERNAL_SET = True

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='category_set',
        blank=True,
        null=True,
        verbose_name=_(u'Site'),
        help_text=_(u'If a site is specified, common for all categories of the site'),
    )

    code = models.SlugField(u'Code', max_length=255, unique=True)
    name = models.CharField(_(u'Name'), max_length=255)
    slug = models.SlugField(u'Slug', max_length=255, unique=True)
    description = models.TextField(_(u'Description'), blank=True)
    image = models.ImageField(_(u'Image'), upload_to=upload_to('uploads/category/images'), null=True, blank=True)
    video = models.FileField(_(u'Video'), upload_to=upload_to('uploads/category/videos'), null=True, blank=True)
    
    icon_svg = models.TextField(_(u'Svg'), blank=True, null=True)
    icon_img = models.ImageField(_(u'Icon'), blank=True, null=True, upload_to=upload_to('uploads/category/icons'))
    icon_name = models.CharField(_(u'Name'), max_length=150, blank=True, null=True)
    icon_code = models.CharField(_(u'Code'), max_length=30, blank=True, null=True,
        help_text=mark_safe("<a target='_blank' href='https://fontawesome.com/search?o=r&f=brands'>https://fontawesome.com/search?o=r&f=brands</a>"),
    )
    
    is_active = models.BooleanField(_(u'Active'), default=True)
    sorted_as = models.PositiveIntegerField(_(u'Sorting'), default=0)
    visited_as = models.PositiveIntegerField(_(u'View Count'), default=0)
    
    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Category')
        verbose_name_plural = _(u'Categories')
        translate = ('name', 'slug', 'description',)
        ordering = ['sorted_as', 'is_active']

    def __str__(self):
        return self.name

class Tag(models.Model, metaclass=TransMeta):
    objects = GeneralManager()
    ADMIN_ORDER = 2

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='tag_set',
        verbose_name=_(u'Site'),
    )

    code = models.SlugField(u'Code', max_length=255, unique=True)
    name = models.CharField(_(u'Name'), max_length=255)
    slug = models.SlugField(u'Slug', max_length=255, unique=True)
    
    icon_svg = models.TextField(_(u'Svg'), blank=True, null=True)
    icon_img = models.ImageField(_(u'Icon'), blank=True, null=True, upload_to=upload_to('uploads/tag/icons'))
    icon_name = models.CharField(_(u'Name'), max_length=150, blank=True, null=True)
    icon_code = models.CharField(_(u'Code'), max_length=30, blank=True, null=True,
        help_text=mark_safe("<a target='_blank' href='https://fontawesome.com/search?o=r&f=brands'>https://fontawesome.com/search?o=r&f=brands</a>"),
    )

    is_active = models.BooleanField(_(u'Active'), default=True)
    sorted_as = models.PositiveIntegerField(_(u'Sorting'), default=0)
    visited_as = models.PositiveIntegerField(_(u'View Count'), default=0)
    
    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Tag')
        verbose_name_plural = _(u'Tags')
        translate = ('name', 'slug',)
        ordering = ('sorted_as', '-is_active',)
    
    def __str__(self):
        return self.name
    
class Post(models.Model, metaclass=TransMeta):
    objects = GeneralManager()
    ADMIN_ORDER = 1
    INTERNAL_SET = True

    site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        default=default_site_code,
        related_name='post_set',
        verbose_name=_(u'Site'),
    )
    category = models.ForeignKey(
        Category,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='post_set',
        verbose_name=_(u'Category'),
    )
    tags = ChainedManyToManyField(
        Tag,
        related_name='post_set',
        chained_field='site',
        chained_model_field='site',
        verbose_name=_(u'Tags'),
        auto_choose=True,
        blank=True,
    )
    slug = models.SlugField(u'Slug', max_length=255, unique=True)
    title = models.CharField(_(u'Title'), max_length=255, null=True)
    summary = models.TextField(_(u'Summary'), blank=True, null=True)
    content = RichTextField(_(u'Content'), blank=True, null=True)
    icon = models.ImageField(_(u'Icon'), blank=True, null=True, upload_to=upload_to('uploads/post/icons'))
    image = models.ImageField(_(u'Image'), blank=True, null=True, upload_to=upload_to('uploads/post/images'))
    
    author = models.CharField(_(u'Author'), max_length=150, blank=True, null=True, default='')
    published_at = models.DateField(_(u'Publish'), blank=True, null=True)

    is_active = models.BooleanField(_(u'Active'), default=True)
    sorted_as = models.PositiveIntegerField(_(u'Sorting'), default=0)
    visited_as = models.PositiveIntegerField(_(u'View Count'), default=0)
    
    # Meta
    meta_title = models.CharField(_(u'Meta title'), null=True, blank=True, max_length=200)
    meta_description = models.CharField(_(u'Meta description'), null=True, blank=True, max_length=500)
    meta_keywords = models.CharField(_(u'Meta keywords'), null=True, blank=True, max_length=300)

    created_at = models.DateTimeField(_(u'Created'), auto_now_add=True)
    updated_at = models.DateTimeField(_(u'Updated'), auto_now=True)

    class Meta:
        verbose_name = _(u'Post')
        verbose_name_plural = _(u'Posts')
        translate = ('title', 'slug', 'summary', 'content', 'meta_title', 'meta_description', 'meta_keywords',)
        ordering = ('-published_at', 'sorted_as', 'visited_as',)
        
    def __str__(self):
        return self.title
    
    @property
    def related_items(self):
        if not hasattr(self, '_related_items'):
            queryset = Post.objects.filter(is_active=True).exclude(id=self.id)
            
            conditions = Q()
            
            if self.category:
                conditions |= Q(category=self.category)
            
            if conditions:
                queryset = queryset.filter(conditions)

            self._related_items = list(
                queryset.distinct().order_by(
                    'sorted_as',
                    'visited_as',
                    '-published_at',
                    'created_at',
                )[:3]
            )
        return self._related_items
    
    def get_related(self, limit=3):
        qs = (
            Post.objects.filter(is_active=True)
            .exclude(id=self.id)
        )

        if self.category_id:
            qs = qs.annotate(
                category_score=Case(
                    When(category=self.category, then=Value(10)),
                    default=Value(0),
                    output_field=IntegerField(),
                )
            )
        else:
            qs = qs.annotate(category_score=Value(0))

        qs = qs.annotate(
            tag_score=Count(
                "tags",
                filter=Q(tags__in=self.tags.all())
            )
        )

        return (
            qs.order_by(
                "-category_score",
                "-tag_score",
                "-published_at",
            )[:limit]
        )
    