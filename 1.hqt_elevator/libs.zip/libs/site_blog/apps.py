from django.apps import AppConfig
from django.utils.translation import gettext_lazy as _


class SiteEngineConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'site_blog'
    verbose_name = _("Blog")
    