import os
import glob

from PIL import Image
from PIL import ImageOps

import pillow_avif  # noqa


class ImagePipeline:

    SIZES = [480, 768, 1200]

    @classmethod
    def cleanup(cls, image_path):

        filename = os.path.basename(image_path)
        name, _ = os.path.splitext(filename)

        generated_dir = os.path.join(
            os.path.dirname(image_path),
            "generated"
        )

        pattern = os.path.join(
            generated_dir,
            f"{name}_*"
        )

        for file in glob.glob(pattern):
            try:
                os.remove(file)
            except FileNotFoundError:
                pass

    @classmethod
    def generate(cls, image_path: str):
        image = Image.open(image_path)
        image = ImageOps.exif_transpose(image)

        if image.mode not in ("RGB", "L"):
            image = image.convert("RGB")

        filename = os.path.basename(image_path)
        name, _ = os.path.splitext(filename)

        generated_dir = os.path.join(
            os.path.dirname(image_path),
            "generated"
        )

        os.makedirs(
            generated_dir,
            exist_ok=True
        )

        for width in cls.SIZES:

            resized = image.copy()

            resized.thumbnail(
                (width, 10000),
                Image.Resampling.LANCZOS
            )

            resized.save(
                os.path.join(
                    generated_dir,
                    f"{name}_{width}.webp"
                ),
                "WEBP",
                quality=82,
                optimize=True
            )

            resized.save(
                os.path.join(
                    generated_dir,
                    f"{name}_{width}.avif"
                ),
                "AVIF",
                quality=60
            )