
import os 
from openai import OpenAI


client = None

def get_client():
    global client

    if client is None:
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("Missing OPENAI_API_KEY")
        client = OpenAI(api_key=api_key)
    return client

def generate_by_openai(prompt):
    client = get_client()
        
    response = client.chat.completions.create(
        model=os.getenv("OPENAI_MODEL_VERSION", "gpt-4.1-mini"),
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ]
    )

    return response.choices[0].message.content
