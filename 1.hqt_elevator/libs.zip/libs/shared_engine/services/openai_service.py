
import os 
from openai import OpenAI

client = OpenAI(
    api_key=os.getenv("OPENAI_API_KEY", "")
)


def generate_by_openai(prompt):
    response = client.chat.completions.create(
        model=os.getenv("OPENAI_MODEL_VERSION", "gpt-4.1-mini"),
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ]
    )

    return response.choices[0].message.content
