import os
from google import genai

client = genai.Client(api_key=os.getenv("GEMINI_API_KEY", ""))

def generate_by_gemini(prompt):
    
    response = client.models.generate_content(
        model=os.getenv("GEMINI_MODEL_VERSION", "gemini-2.5-flash"),
        contents=prompt
    )

    return response.text