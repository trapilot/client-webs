import os
import google.generativeai as genai

genai.configure(api_key=os.getenv("GEMINI_API_KEY", ""))


def generate_by_gemini(prompt):

    model = genai.GenerativeModel(os.getenv("GEMINI_MODEL_VERSION", "gemini-2.5-flash"))

    response = model.generate_content(prompt)

    return response.text