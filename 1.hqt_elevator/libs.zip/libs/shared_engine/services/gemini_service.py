import os
from google import genai


client = None

def get_client():
    global client

    if client is None:
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("Missing GEMINI_API_KEY")
        client = genai.Client(api_key=api_key)
    return client

def generate_by_gemini(prompt):
    client = get_client()

    response = client.models.generate_content(
        model=os.getenv("GEMINI_MODEL_VERSION", "gemini-2.5-flash"),
        contents=prompt
    )

    return response.text