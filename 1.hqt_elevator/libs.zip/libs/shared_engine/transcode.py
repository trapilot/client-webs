from django.conf import settings
from django.utils import timezone

from PIL import Image
from PIL import ImageOps
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

try:
    import pillow_avif  # noqa
except Exception:
    pass


from shared_engine.utils.file import (
    normalize_filename,
    ensure_generated_dir,
    cleanup_generated_files,
)


DEFAULT_SIZES = [480, 768, 1200]
DEFAULT_OUTPUTS = ["avif", "webp"]



executor = ThreadPoolExecutor(
    max_workers=1,
    thread_name_prefix="image"
)


def get_transcode_sizes():
    return getattr(settings, "IMAGE_PIPELINE", {}).get("SIZES", DEFAULT_SIZES)

def get_transcode_outputs():
    return getattr(settings, "IMAGE_PIPELINE", {}).get("SIZES", DEFAULT_OUTPUTS)


class upload_to:
    def __init__(self, path: str, date=False):
        self.path = path
        self.date = date

    def __call__(self, instance, filename):
        now = timezone.now()
        filename = normalize_filename(filename)

        if self.date:
            return (
                f"{self.path}/"
                f"{now.year}_{now.month:02d}/"
                f"{filename}"
            )
        return (
                f"{self.path}/"
                f"{filename}"
            )

    def deconstruct(self):
        return (
            "shared_engine.transcode.upload_to",
            [self.path],
            {"date": self.date},
        )


class ImageTranscoder:
    @classmethod
    def get_sizes(cls):
        return get_transcode_sizes()

    @classmethod
    def get_formats(cls):
        return get_transcode_outputs()

    @classmethod
    def generate(cls, image_path: str):
        image_path = Path(image_path)

        if not image_path.exists():
            return

        image = ImageOps.exif_transpose(Image.open(image_path))

        if image.mode not in ("RGB", "L"):
            image = image.convert("RGB")

        generated_dir = ensure_generated_dir(image_path)
        original_width = image.width

        for width in cls.get_sizes():
            if width > original_width:
                continue

            resized = image.copy()
            resized.thumbnail(
                (width, 10000),
                Image.Resampling.LANCZOS
            )

            for fmt in cls.get_formats():
                output = (
                    generated_dir
                    / f"{image_path.stem}_{width}.{fmt}"
                )

                if fmt == "webp":
                    resized.save(output, "WEBP", quality=85, optimize=True)

                elif fmt == "avif":
                    resized.save(output, "AVIF", quality=75)

    @classmethod
    def cleanup(cls, image_path: str):
        cleanup_generated_files(image_path)
