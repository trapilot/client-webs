from django import template
register = template.Library()


class BrowserNode(template.Node):
    def render(self, context):
        browser = ''
        request = context.get('request')
        if request:
            user_agent = request.META.get('HTTP_USER_AGENT')
            if user_agent:
                if 'Chrome' in user_agent:
                    browser = 'chrome'
                if 'Firefox' in user_agent:
                    browser = 'firefox'
                if 'MSIE 8.0' in user_agent:
                    browser = 'ie8'
                if 'MSIE 7.0' in user_agent:
                    browser = 'ie7'
                if 'MSIE 9.0' in user_agent:
                    browser = 'ie9'

        context['browser'] = browser
        return ''
        
def browser(parser, token):
    '''Returns a string with the browser used. Examples:
        - ie6
        - ie7
        - ie8
        - fx
        - sf
    '''
    return BrowserNode()
register.tag('browser', browser)

class SystemNode(template.Node):
    def render(self, context):
        request = context.get('request')
        user_agent = request.META.get('HTTP_USER_AGENT')
        if user_agent:
            system = ''
            if 'Linux' in user_agent:
                system = 'linux'
            context['system'] = system
        return ''
    
def system(parser, token):
    return SystemNode()
register.tag('system', system)
