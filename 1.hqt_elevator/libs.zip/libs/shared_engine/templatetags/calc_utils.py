from django import template

register = template.Library()

def calculate_percentage(total_amount, percentage):
    percent = (total_amount * percentage / 100.0)
    value = u'%.2f' % round(percent, 2)
    return value

register.simple_tag(calculate_percentage)