# -*- coding: utf-8 -*-
"""
Returns the value of a dictionary based on the provided key
"""
from django import template
register = template.Library()

@register.filter
def dict_value(value, key):
    return value[key]