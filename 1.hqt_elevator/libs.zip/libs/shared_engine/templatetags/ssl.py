# -*- coding: utf-8 -*-
'''
SSL filter. When applied to a URL, it changes from http to https if it is on a secure server.
'''

from django import template
register = template.Library()

@register.filter
def ssl(value, request):
    if request.is_secure():
        value = value.replace('http://','https://')

    return value

def http_secure(request):
    return 'https' if request.is_secure() else 'http'
register.simple_tag(http_secure)
