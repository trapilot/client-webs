from django import template
register = template.Library()

def field_i18n(object, field, language):
    '''We return the value of the field in the specified language. If it does not exist, we return nothing.'''
    
    try:
        return object.__getattribute__('%s_%s' % (field, language))
    except AttributeError:
        return ''
    
register.simple_tag(field_i18n)