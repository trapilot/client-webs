from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from shared_engine.utils import ai

@csrf_exempt
def generate_html(request):
    content = request.POST.get("content", "")
    provider = request.POST.get("provider", "gemini")

    prompt = f"""
    You are an expert frontend developer.

    Filter to take ONLY content and then convert content into clean semantic HTML using TailwindCSS v4 to post it on the website according to SEO/AIO/AEO standards.

    STRICT RULES:
    - Output ONLY HTML (no markdown, no explanation)
    - Do NOT include <html>, <head>, <body>
    - Use semantic HTML
    - Fully responsive
    - Wrap entire output in a single root <div class="w-full">
    - No container constraints (no max-width, no container class)
    - Layout must expand full viewport width
    - Root layout MUST be full width:
      - Do NOT use max-w-* anywhere (e.g., max-w-4xl, max-w-screen-md)
      - Do NOT center with mx-auto unless explicitly required
      - Root container must use: w-full

    LAYOUT RULES:
    - Wrap output in <div class="w-full">
    - Must be full width layout
    - NEVER use: max-w-*, container, mx-auto (unless explicitly required)
    

    TABLE RULES (VERY IMPORTANT):
    - If content contains ANY of the following:
    - list of data items
    - comparisons
    - structured fields (name, price, value, label, etc.)
    - multiple rows of similar information
    → MUST use <table> with Tailwind styling
    - Table must use:
    - <table class="w-full border-collapse">
    - <thead>
    - <tbody>
    - proper <th>, <td>
    - striped or bordered rows using Tailwind

    DO NOT replace table with div/cards when data is structured.

    CONTENT:
    {content}

    OUTPUT:
    """
    print(content)
    try:
        html = ai.generate_html(provider, prompt)
        
        return JsonResponse({
            "success": True,
            "html": html,
            # "usage": response.usage.total_tokens
        })
    except Exception as e:
        return JsonResponse({
            "success": False,
            "error": str(e)
        })
    