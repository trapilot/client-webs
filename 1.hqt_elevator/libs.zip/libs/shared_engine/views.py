import json

from django.conf import settings
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from shared_engine.utils import ai


@csrf_exempt
def generate_html(request):
    content = request.POST.get("content", "")
    provider = request.POST.get("provider", "")
    metadata = request.POST.get("metadata", "")

    if not content or not provider or not metadata:
        raise Exception("Input data invalid!")
    
    metadata = json.loads(metadata)

    prompt = f"""
    You are an elite senior UI/UX engineer and TailwindCSS expert.

    Your task is to add html production-quality to the input content, visually stunning, responsive HTML interfaces using TailwindCSS.

    You specialize in:

    keep EXACTLY the input

    AVOID:

    ugly default Tailwind layouts
    Bootstrap-style appearance
    cramped sections
    giant text blocks
    inconsistent spacing
    random colors
    outdated UI
    poor mobile layouts
    generic placeholder design

    TECHNICAL RULES:

    Return ONLY valid HTML
    No markdown
    No explanations
    Use TailwindCSS CDN
    Single-file output
    Semantic HTML only
    Production-ready code
    Clean indentation
    Accessible structure

    OUTPUT REQUIREMENTS:

    Include Tailwind CDN
    Fully responsive
    Visually polished
    Modern premium quality
    Ready to paste into production

    Always prioritize BEAUTIFUL DESIGN over minimal output.

    CONTENT:
    {content}

    OUTPUT:
    """
    
    if settings.DEBUG:
        print(prompt)
        print(metadata)

    try:
        html = ai.generate_html(provider, prompt)
        
        prompt = f"""
        Improve this HTML to make it:

        more visually premium
        better spacing
        more modern
        cleaner typography
        more responsive
        more polished

        Do not change content structure drastically.
        Return only improved HTML.

        CONTENT:
        {html}

        OUTPUT:
        """
        return JsonResponse({
            "success": True,
            "html": html,
            # "html": ai.generate_html(provider, prompt),
            # "usage": response.usage.total_tokens
        })
    except Exception as e:
        return JsonResponse({
            "success": False,
            "error": str(e)
        })
    