import copy
from collections import OrderedDict

from django.db import models
from django.db.models.fields import NOT_PROVIDED
from django.conf import settings
from django.core.exceptions import ImproperlyConfigured
from django.utils.translation import get_language, gettext_lazy as _

INDEX_LANGUAGE_CODE = 0
INDEX_LANGUAGE_NAME = 1
USE_TRANSMETA = len(settings.LANGUAGES) > 1


def get_languages():
    return getattr(settings, 'TRANSMETA_LANGUAGES', settings.LANGUAGES)


def get_real_language(lang=None):
    if lang is None:
        lang = get_language()
    if lang is None:
        lang = settings.LANGUAGE_CODE
    if '-' in lang:
        lang = lang.split('-')[0]
    return lang # both 'en-US' and 'en' -> 'en'


def get_lable_language(label, lang=None, inline=True):
    if inline and USE_TRANSMETA and lang is not None:        
        return u'%s' %(label) + ' [%s]' % (lang)
    return u'%s' % (label)


def get_real_fieldname(field, lang=None):
    return str('%s_%s' % (field, get_real_language(lang)))


def get_field_language(real_field):
    """ return language for a field. i.e. returns "en" for "name_en" """
    return real_field.split('_')[-1]


def get_fallback_fieldname(field, lang=None):
    return get_real_fieldname(field, lang=fallback_language())


def get_mandatory_fieldname(field, lang=None):
    return get_real_fieldname(field, lang=mandatory_language())


def get_real_fieldname_in_each_language(field):
    return [get_real_fieldname(field, lang[INDEX_LANGUAGE_CODE])
            for lang in get_languages()]


def canonical_fieldname(db_field):
    """ all "description_en", "description_fr", etc. field names will return "description" """
    return getattr(db_field, 'original_fieldname', db_field.name)  # original_fieldname is set by transmeta


def mandatory_language():
    """ returns mandatory language. the language which is required to fill """
    return getattr(settings, 'TRANSMETA_MANDATORY_LANGUAGE', fallback_language())


def fallback_language():
    """ returns fallback language """
    return getattr(settings, 'TRANSMETA_DEFAULT_LANGUAGE', get_real_language(settings.LANGUAGE_CODE))


def get_all_translatable_fields(model, model_trans_fields=None, column_in_current_table=False):
    """ returns all translatable fields in a model (including superclasses ones) """
    if model_trans_fields is None:
        model_trans_fields = set()
    model_trans_fields.update(set(getattr(model._meta, 'translatable_fields', [])))
    for parent in model.__bases__:
        if getattr(parent, '_meta', None) and (not column_in_current_table or parent._meta.abstract):
            get_all_translatable_fields(parent, model_trans_fields, column_in_current_table)
    return tuple(model_trans_fields)


def default_value(field):
    '''
    When accessing to the name of the field itself, the value
    in the current language will be returned. Unless it's set,
    the value in the default language will be returned.
    '''

    def default_value_func(self):
        attname = lambda x: get_real_fieldname(field, x)
        default_language = fallback_language()

        current_language = get_language() or default_language

        if getattr(self, attname(current_language), None):
            result = getattr(self, attname(current_language))
        elif getattr(self, attname(current_language[:2]), None):
            result = getattr(self, attname(current_language[:2]))
        elif getattr(self, attname(default_language), None):
            result = getattr(self, attname(default_language))
        else:
            result = getattr(self, attname(settings.LANGUAGE_CODE), None)

        return result

    return default_value_func


class TransMeta(models.base.ModelBase):
    '''
    Metaclass that allow a django field, to store a value for
    every language. The syntax to us it is next:

        class MyClass(models.Model, metaclass=TransMeta):

            my_field = models.CharField(max_length=20)
            my_i18n_field = models.CharField(max_length=30)

            class Meta:
                translate = ('my_i18n_field',)

    Then we'll be able to access a specific language by
    <field_name>_<language_code>. If just <field_name> is
    accessed, we'll get the value of the current language,
    or if null, the value in the default language.
    '''

    def __new__(cls, name, bases, attrs):
        attrs = OrderedDict(attrs)
        if 'Meta' in attrs and hasattr(attrs['Meta'], 'translate'):
            fields = attrs['Meta'].translate
            delattr(attrs['Meta'], 'translate')
        else:
            new_class = super(TransMeta, cls).__new__(cls, name, bases, attrs)
            # we inherits possible translatable_fields from superclasses
            abstract_model_bases = [base for base in bases if hasattr(base, '_meta') and base._meta.abstract]
            translatable_fields = []
            for base in abstract_model_bases:
                if hasattr(base._meta, 'translatable_fields'):
                    translatable_fields.extend(list(base._meta.translatable_fields))
            new_class._meta.translatable_fields = tuple(translatable_fields)
            return new_class
        
        inline_fields = ()
        if 'Meta' in attrs and hasattr(attrs['Meta'], 'translate_inline'):
            inline_fields = attrs['Meta'].translate_inline
            delattr(attrs['Meta'], 'translate_inline')

        if not isinstance(fields, tuple):
            raise ImproperlyConfigured("Meta's translate attribute must be a tuple")

        for field in fields:
            if not field in attrs or \
               not isinstance(attrs[field], models.fields.Field):
                    raise ImproperlyConfigured(
                        "There is no field %(field)s in model %(name)s, "\
                        "as specified in Meta's translate attribute" % \
                        dict(field=field, name=name))
            original_attr = attrs[field]
            inline_attr = field in inline_fields
            for lang in get_languages():
                lang_code = lang[INDEX_LANGUAGE_CODE]
                lang_name = lang[INDEX_LANGUAGE_NAME]
                lang_attr = copy.copy(original_attr)
                lang_attr.original_fieldname = field
                lang_attr_name = get_real_fieldname(field, lang_code)
                if lang_code != mandatory_language():
                    # only will be required for mandatory language
                    if not lang_attr.null and lang_attr.default is NOT_PROVIDED:
                        lang_attr.null = True
                    if not lang_attr.blank:
                        lang_attr.blank = True
                if hasattr(lang_attr, 'verbose_name'):
                    lang_attr.verbose_name = LazyString(lang_attr.verbose_name, lang_code, inline_attr)
                attrs[lang_attr_name] = lang_attr
            del attrs[field]
            attrs[field] = property(default_value(field))

        new_class = super(TransMeta, cls).__new__(cls, name, bases, attrs)
        if hasattr(new_class, '_meta'):
            new_class._meta.translatable_fields = fields
        return new_class
        
    def append_lang_fields(self, language, ignores=()):
        fields = ()
        if 'title' in self._meta.translatable_fields and 'url' in self._meta.translatable_fields:
            fields += ((get_real_fieldname('title', language), get_real_fieldname('url', language)),)
            ignores += ('title', 'url')
        for field in self._meta.translatable_fields:
            if field not in ignores:
                fields += (get_real_fieldname(field, language),)
        return fields
        
    def append_lang_fields_withstart(self, language, startswith, ignores=()):
        fields = ()
        if 'title' in self._meta.translatable_fields and 'url' in self._meta.translatable_fields:
            fields += ((get_real_fieldname('title', language), get_real_fieldname('url', language)),)
            ignores += ('title', 'url')
        for field in self._meta.translatable_fields:
            if field not in ignores and field.startswith(startswith):
                fields += (get_real_fieldname(field, language),)
        return fields
        
    def append_lang_fields_notwithstart(self, language, startswith, ignores=()):
        fields = ()
        if 'title' in self._meta.translatable_fields and 'url' in self._meta.translatable_fields:
            fields += ((get_real_fieldname('title', language), get_real_fieldname('url', language)),)
            ignores += ('title', 'url')
        for field in self._meta.translatable_fields:
            if field not in ignores and not field.startswith(startswith):
                fields += (get_real_fieldname(field, language),)
        return fields


class LazyString(object):

    def __init__(self, proxy, lang, inline=True):
        self.proxy = proxy
        self.lang = lang
        self.inline = inline

    def __str__(self):
        return get_lable_language(self.proxy, self.lang, self.inline)
