from django.utils import timezone

from shared_engine.utils.file import normalize_filename

class upload_to:
    def __init__(self, path: str, date=False):
        self.path = path
        self.date = date

    def __call__(self, instance, filename):
        now = timezone.now()
        filename = normalize_filename(filename)

        if self.date:
            return (
                f"{self.path}/"
                f"{now.year}_{now.month:02d}/"
                f"{filename}"
            )
        return (
                f"{self.path}/"
                f"{filename}"
            )

    def deconstruct(self):
        return (
            "shared_engine.upload.upload_to",
            [self.path],
            {"date": self.date},
        )
