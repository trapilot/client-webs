from django.db import models
from django.utils.translation import gettext_lazy as _

from sorl.thumbnail import ImageField
from smart_selects.db_fields import ChainedForeignKey

from cms_engine import defaults
from shared_engine.transmeta import TransMeta
from shared_engine.managers import GeneralManager


class ImageBase(models.Model, metaclass=TransMeta):
    objects = GeneralManager()

    title = models.CharField(_(u'Title'), max_length=150)
    image = ImageField(_(u'Image'), max_length=200, upload_to='uploads/cms/images/')
    sorted_as = models.PositiveIntegerField(_(u'Order'), default=0)
    is_active = models.BooleanField(_(u'Active'), default=True)

    class Meta:
        abstract = True
        translate = ('title', 'image',)
        ordering = ('is_active', 'sorted_as')

    def __str__(self):
        return self.title


class ArchiveBase(models.Model, metaclass=TransMeta):
    objects = GeneralManager()

    name = models.CharField(_(u'Name'), blank=True, null=True, max_length=75)
    file = models.FileField(
        _(u'File'),
       upload_to='uploads/cms/files',
       help_text=_(u'The file name must not contain spaces or accents.'),
   )
    sorted_as = models.PositiveIntegerField(_(u'Order'), default=0)
    is_active = models.BooleanField(_(u'Active'), default=True)

    class Meta:
        abstract = True
        translate = ('name', 'file',)
        ordering = ('is_active', 'sorted_as',)

    def __str__(self):
        return self.name
