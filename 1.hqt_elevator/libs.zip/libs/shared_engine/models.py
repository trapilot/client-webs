from django.db import models
from django.utils.translation import gettext_lazy as _

from sorl.thumbnail import ImageField
from smart_selects.db_fields import ChainedForeignKey

from cms_engine import defaults
from shared_engine.transmeta import TransMeta
# from cms_engine.utils import default_project_code
from shared_engine.managers import ArchiveManager, ImageManager


class ImageBase(models.Model, metaclass=TransMeta):
    objects = ImageManager()

    title = models.CharField(_(u'Title'), max_length=150)
    image = ImageField(_(u'Image'), max_length=200, upload_to='uploads/cms/images/')
    sorted_as = models.PositiveIntegerField(_(u'Order'), default=0)
    is_active = models.BooleanField(_(u'Active'), default=True)

    class Meta:
        abstract = True
        translate = ('title', 'image',)
        ordering = ('is_active', 'sorted_as')

    def __str__(self):
        return self.title


class ArchiveBase(models.Model, metaclass=TransMeta):
    objects = ArchiveManager()

    name = models.CharField(_(u'Name'), blank=True, null=True, max_length=75)
    file = models.FileField(
        _(u'File'),
       upload_to='uploads/cms/files',
       help_text=_(u'The file name must not contain spaces or accents.'),
   )
    sorted_as = models.PositiveIntegerField(_(u'Order'), default=0)
    is_active = models.BooleanField(_(u'Active'), default=True)

    class Meta:
        abstract = True
        translate = ('name', 'file',)
        ordering = ('is_active', 'sorted_as',)

    def __str__(self):
        return self.name
        




# class ModelWithExtras(models.Model):
    # """Object with an init that loads the extras of a model, if it has"""

    # def __init__(self, *args, **kwargs):
        # super(ModelWithExtras, self).__init__(*args, **kwargs)

        # """We load all the extras. Let's detect if you have a
        # extras related model"""

        # name_rel = self.__class__.__name__.lower() + '_extra_set'
        # try:
            # extras = self.__getattribute__(name_rel)

            # """TODO: Cache this query so it doesn't have to be done every time.

            # Now, the extra fields have included an 'image' field that will be
            # accessible through the field name with the suffix '_image' """
            # for extra in extras.all():
                # self.__dict__[extra.field] = extra.content
                # self.__dict__['%s_image' % extra.field] = extra.image
        # except AttributeError:
            # return
        # except:
            # pass

    # class Meta:
        # abstract = True


# class ExtraObjectBase(models.Model, metaclass=TransMeta):
    # u"""Base model to create extra fields"""

    # field = models.CharField(_(u'Field'),
                        # max_length=30,
                        # help_text=_(u'Identification field of the extra. It will be accessed as: land.field'))
    # content = RichTextField(_(u'Content'), blank=True, null=True, default='')
    # image = ImageField(_(u'Image'),
                    # upload_to='uploads/cms/extras/',
                    # blank=True, null=True)

    # class Meta:
        # abstract = True
        # translate = ('content', )

    # def __str__(self):
        # return self.field


# class ModelBase(ModelWithExtras, models.Model, metaclass=TransMeta):

    # objects = BackgroundManager()

    # name = models.CharField(_(u'Name'), max_length=75)
    # description = models.TextField(_(u'Description'), blank=True, null=True)
    # sorted_as = models.PositiveIntegerField(_(u'Order'), default=0)
    # is_active = models.BooleanField(_(u'Active'), default=True)

    # class Meta:
        # abstract = True
        # translate = ('name', 'description')
        # ordering = ['is_active', 'sorted_as',]

    # def __str__(self):
        # return self.name


# class ImageBase(models.Model, metaclass=TransMeta):

    # objects = GeneralManager()

    # title = models.CharField(_(u'Title'), max_length=150)
    # image = ImageField(_(u'Image'),
                    # upload_to='uploads/cms/images/',
                    # max_length=200)
    # sorted_as = models.PositiveIntegerField(_(u'Order'), default=0)
    # is_active = models.BooleanField(_(u'Active'), default=True)

    # class Meta:
        # abstract = True
        # translate = ('title', 'image',)
        # ordering = ('is_active', 'sorted_as')

    # def __str__(self):
        # return self.title


# class ArchiveBase(models.Model, metaclass=TransMeta):

    # objects = GeneralManager()

    # name = models.CharField(_(u'Name'), blank=True, null=True, max_length=75)
    # file = models.FileField(_(u'File'),
                           # upload_to='uploads/cms/files',
                           # help_text=_(u'The file name must not contain spaces or accents.'))
    # sorted_as = models.PositiveIntegerField(_(u'Order'), default=0)
    # is_active = models.BooleanField(_(u'Active'), default=True)

    # class Meta:
        # abstract = True
        # translate = ('name', 'file')
        # ordering = ('is_active', 'sorted_as',)

    # def __str__(self):
        # return self.name
