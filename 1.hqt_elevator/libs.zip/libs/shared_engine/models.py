from django.db import models
from django.utils.translation import gettext_lazy as _

from shared_engine.managers import GeneralManager
from shared_engine.transmeta import TransMeta


class TargetType(models.TextChoices):
    PRODUCT = "products", "Product"
    PROJECT = "projects", "Project"
    SOLUTION = "solutions", "Solution"


class FieldType(models.TextChoices):
    TEXT = 'text', 'Text'
    NUMBER = 'number', 'Number'
    DECIMAL = 'decimal', 'Decimal'
    DATE = 'date', 'Date'
    BOOLEAN = 'boolean', 'Boolean'
    SELECT = 'select', 'Select'
    


class FieldAttribute(models.Model, metaclass=TransMeta):
    objects = GeneralManager()

    name = models.SlugField(max_length=100)
    label = models.CharField(max_length=255)
    unit = models.CharField(max_length=255, blank=True, null=True)
    default_value = models.TextField(blank=True, null=True)
    value_choices = models.TextField(blank=True, default="", help_text="""
        One choice per line.
        Format:
        value, Label
        """
    )

    type = models.CharField(max_length=20, choices=FieldType.choices, default=FieldType.TEXT)
    required = models.BooleanField(default=False)
    
    is_active = models.BooleanField(_(u'Active'), default=True)
    sorted_as = models.PositiveIntegerField(_(u'Sorting'), default=0)

    class Meta:
        abstract = True
        
    def __str__(self):
        return f'{self.site} - {self.label}'
    
    @property
    def choices(self):
        if not self.value_choices:
            return []
        
        result = []
        for line in self.value_choices.splitlines():
            line = line.strip()
            if not line:
                continue
            parts = [p.strip() for p in line.split("|", 1)]
            if len(parts) == 2:
                value, label = parts
            else:
                value = label = parts[0]
            result.append((value, label))
        return result

    def clean_value(self, value: str):
        if value is None:
            value = ""

        value = str(value)

        if self.field_type == FieldType.TEXT:
            return value

        if self.field_type == FieldType.NUMBER:
            if value == "":
                return value
            try:
                int(value)
            except ValueError:
                # raise ValidationError(f"{self.label} must be an integer")
                raise ValueError(_(f"{self.label} must be an integer"))
            return value

        if self.field_type == FieldType.DECIMAL:
            if value == "":
                return value
            try:
                float(value)
            except ValueError:
                # raise ValidationError(f"{self.label} must be an integer")
                raise ValueError(_(f"{self.label} must be a decimal"))
            return value

        if self.field_type == FieldType.BOOLEAN:
            if value.lower() not in ["true", "false", "1", "0", "yes", "no", ""]:
                # raise ValidationError(f"{self.label} must be boolean string")
                raise ValueError(_(f"{self.label} must be boolean string"))
            return value
        if self.type == FieldType.SELECT:
            if self.default_value:
                if self.default_value not in self.choices:
                    # raise ValidationError({
                    #     "default_value": _("Default value must exist in choices")
                    # })
                    raise ValueError( _("Default value must exist in choices"))

        return value
    