import datetime

from django.conf import settings
from django.core.management.base import NoArgsCommand
from django_mailer.models import QueuedMessage

from shared_engine.utils.email import html_email
from site_engine.models import Site


class Command(NoArgsCommand):
    help_text = u"""Check if there are emails in queue without sending"""

    def handle_noargs(self, **options):
        yesterday = datetime.datetime.today() - datetime.timedelta(1)
        n = QueuedMessage.objects.filter(date_queued__lt=yesterday).count()
        if n:
            site = Site.objects.all()[:1][0]
            url = "http://%s/admin/django_mailer/queuedmessage/" % \
                site.domain_en
            msg = """
            There are %(n)d emails in queue.
            %(url)s
            """ % {
                "n": n,
                "url": url,
                "base": settings.BASE,
                "site_code": site.code,
            }

            if settings.DEFAULT_NOTIFY_EMAIL:
                html_email(
                    '[Warning] Emails in queue %s' % site.domain_en,
                    msg,
                    settings.DEFAULT_FROM_EMAIL,
                    settings.DEFAULT_NOTIFY_EMAIL.split(',')
                )
            else:
                html_email(
                    '[Warning] Emails in queue %s' % site.domain_en,
                    msg,
                    settings.DEFAULT_FROM_EMAIL
                )
