import datetime

from django.conf import settings
from django.core.management.base import NoArgsCommand
from django_mailer.models import QueuedMessage

from cms_engine.models import Project
from shared_engine.utils.email import html_email


class Command(NoArgsCommand):
    help_text = u"""Check if there are emails in queue without sending"""

    def handle_noargs(self, **options):
        yesterday = datetime.datetime.today() - datetime.timedelta(1)
        n = QueuedMessage.objects.filter(date_queued__lt=yesterday).count()
        if n:
            project = Project.objects.all()[:1][0]
            url = "http://%s/admin/django_mailer/queuedmessage/" % \
                project.domain_en
            msg = """
            There are %(n)d emails in queue.
            %(url)s
            """ % {
                "n": n,
                "url": url,
                "base": settings.BASE,
                "cod_proyecto": project.code,
            }

            if settings.DEFAULT_NOTIFY_EMAIL:
                html_email(
                    '[Warning] Emails in queue %s' % project.domain_en,
                    msg,
                    settings.DEFAULT_FROM_EMAIL,
                    settings.DEFAULT_NOTIFY_EMAIL.split(',')
                )
            else:
                html_email(
                    '[Warning] Emails in queue %s' % project.domain_en,
                    msg,
                    settings.DEFAULT_FROM_EMAIL
                )
