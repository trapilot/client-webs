import os
import commands

from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Perform a mysqldump of the database and place it in the site's backup folder.."

    def handle_noargs(self, **options):
        from django.conf import settings

        cmd = "mysqldump -u'%s' -p'%s' -h'%s' '%s' > backups/%s.sql" % (
            settings.DATABASES['default']['USER'],
            settings.DATABASES['default']['PASSWORD'],
            settings.DATABASES['default']['HOST'],
            settings.DATABASES['default']['NAME'],
            settings.DATABASES['default']['NAME']
        )
        print(commands.getoutput(cmd))
