from django.core.management import BaseCommand
from django.core.management import call_command
from django.db import connection
from django.conf import settings
import os
import shutil
import re
import time
import tempfile

def delete_line(filename, pattern, stdout):
    pattern_compiled = re.compile(pattern)
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as tmp_file:
        with open(filename) as src_file:
            for line in src_file:
                if pattern_compiled.findall(line):
                    stdout.write('Deleting line in %s' % filename)
                    continue
                tmp_file.write(line)

    # Overwrite the original file with the munged temporary file in a
    # manner preserving file attributes (e.g., permissions).
    shutil.copystat(filename, tmp_file.name)
    shutil.move(tmp_file.name, filename)


class Command(BaseCommand):
    help = "Delete all migrations from one app, reset database and create one new migration"

    def __init__(self, *args, **kwargs):
        self.cursor = connection.cursor()
        return super(Command, self).__init__(*args, **kwargs)

    def add_arguments(self, parser):
        # parser.add_argument('apps', nargs='+', type=str, default=None,)

        # Named (optional) arguments
        parser.add_argument('--cached',
                            action='store_true',
                            dest='cached',
                            default=False,
                            help='Dont delete the migrations files')

    def delete_database_app(self, app):
        self.stdout.write("Deleting APP (%s) in database" % app)
        self.cursor.execute("DELETE from django_migrations WHERE app = %s", [app])

    def delete_files_app(self, app):
        self.stdout.write("Deleting APP (%s) migrations files" % app)
        migrations_dir = os.path.join(os.getcwd(), app, 'migrations')

        if app == 'site_engine' or app == 'site_blog':
            migrations_dir = migrations_dir.replace('src/app', 'libs')
        else:
            migrations_dir = migrations_dir.replace('src/app', 'libs/site_content')

        if os.path.exists(migrations_dir):
            shutil.rmtree(migrations_dir)

    def delete_dependence_app(self, app):
        self.stdout.write("Deleting dependences in migrations for (%s)" % app)
        for root, dirs, files in os.walk(".", topdown=False):
            for name in dirs:
                if name == 'migrations':
                    migration_dir = os.path.join(root, name)
                    for r, d, f in os.walk(migration_dir):
                        for n in f:
                            file_name = os.path.join(r, n)
                            if '.pyc' in file_name:
                                continue
                            if '.py' in file_name:
                                regex = r'\(\'%s\'' % app
                                delete_line(file_name, regex, self.stdout)

    def handle(self, *args, **options):
        from site_engine.models import Site
        Site.objects.all().delete()

        time.sleep(5)

        site_blog = None
        site_engine = None

        # apps = options['apps']
        apps = []
        for app in settings.INSTALLED_APPS:
            if app == 'site_engine':
                site_engine = app
            elif app == 'site_blog':
                site_blog = app
            elif 'engine' in app and 'shared' not in app:
                apps.append(app)

        if site_blog is not None:
            apps.append('site_blog')
        if site_engine is not None:
            apps.append('site_engine')

        self.stdout.write("Reseting APP %s" % apps)
        try:
            for app in apps:
                self.delete_database_app(app)
                if not options['cached']:
                    self.delete_files_app(app)
                    self.delete_dependence_app(app)
                self.stdout.write("APP (%s) deleted with success" % app)

            if not options['cached']:
                call_command('makemigrations', *apps)

            for app in apps:
                call_command('migrate', app, '--fake')
                # call_command('migrate', app)
        except Exception as ex:
            print(ex)
