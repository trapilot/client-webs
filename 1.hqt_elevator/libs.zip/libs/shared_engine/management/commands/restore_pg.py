import gzip
import subprocess, os

from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "It restore the postgres database and places it in the backup folder of the project."

    def handle(self, *args, **options):
        from django.conf import settings

        #cmd = 'export PGPASSWORD=%s; pg_dump --host %s --port 5432 --username "%s" --role "%s" --format tar --blobs --verbose --file "backups/%s.sql" "%s"' % (
        cmd = "PGPASSWORD='%s' psql -Fc -h '%s' -U '%s' -d '%s' < 'db_backup/%s.dump'" % (
            settings.DATABASES['default']['PASSWORD'],
            settings.DATABASES['default']['HOST'],
            settings.DATABASES['default']['USER'],
            settings.DATABASES['default']['NAME'],
            settings.DATABASES['default']['NAME']
        )
        
        try:
            # print(cmd)
            # print(settings.DATABASES)
            print(subprocess.getoutput(cmd))
            self.stdout.write(self.style.SUCCESS('Successful!'))
        except Exception as e:
            self.stdout.write(self.style.SUCCESS('Error: %s' % str(e)))

