
from django import forms
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _


class AdminImageRequireForm(forms.ModelForm):
    def clean_image(self):
        image = self.cleaned_data['image']
        if not image:
            raise ValidationError(_(u'The image field is required'))
        if not image.name.isascii():
            raise ValidationError(_('Wrong filename'))
        return self.cleaned_data['image']


class AdminImageOptionalForm(forms.ModelForm):
    def clean_image(self):
        image = self.cleaned_data['image']
        if image:
            if not image.name.isascii():
                raise ValidationError(_('Wrong filename'))
        return self.cleaned_data['image']


class AdminFileRequireForm(forms.ModelForm):
    def clean_file(self):
        file =  self.cleaned_data['file']
        if not file:
            raise ValidationError(_(u'The file field is required'))
        if not file.name.isascii():
            raise ValidationError(_('Wrong filename'))
        return self.cleaned_data['file']


class AdminFileOptionalForm(forms.ModelForm):
    def clean_image(self):
        file = self.cleaned_data['file']
        if file:
            if not file.name.isascii():
                raise ValidationError(_('Wrong filename'))
        return self.cleaned_data['file']