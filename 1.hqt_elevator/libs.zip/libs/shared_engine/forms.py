
from django import forms
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _


class AdminImageForm(forms.ModelForm):
    def clean_image(self):
        image = self.cleaned_data['image']
        if not image:
            raise ValidationError(_(u'The image field is required'))
        else:
            try:
                image.name.encode('ascii')
            except UnicodeEncodeError:
                raise ValidationError(_(u'Wrong filename'))
        return self.cleaned_data['image']


class AdminImageExtraForm(forms.ModelForm):
    def clean_image(self):
        image = self.cleaned_data['image']
        if image:
            try:
                image.name.encode('ascii')
            except UnicodeEncodeError:
                raise ValidationError(_(u'Wrong filename'))
        return self.cleaned_data['image']


class AdminArchiveForm(forms.ModelForm):
    def clean_file(self):
        file =  self.cleaned_data['file']
        if not file:
            raise ValidationError(_(u'The image field is required'))
        else:
            try:
                file.name.encode('ascii')
            except UnicodeEncodeError:
                raise ValidationError(_(u'Wrong filename'))
        return self.cleaned_data['file']
