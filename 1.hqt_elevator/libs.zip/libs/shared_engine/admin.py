from django.contrib import admin
from django.conf import settings
from django.utils.html import format_html
from django.utils.translation import gettext_lazy as _

from shared_engine.transmeta import get_real_fieldname as __


class AdminBase(admin.ModelAdmin):
    class Media:
        js = ("admin/js/urlify_vi.js",)
        
    def get_readonly_fields(self, request, obj=None):
        fields = []
        if obj is not None:
            if hasattr(obj, 'code') and getattr(obj, 'code', None) is not None:
                fields.append('code')
            if not settings.DEBUG and hasattr(obj, 'site') and getattr(obj, 'site', None) is not None:
                fields.append('site')
        return fields

    def save_model(self, request, obj, form, change):
        if hasattr(obj, 'created_by'):
            if getattr(obj, 'created_by', None) is None:
                obj.created_by = request.user
        if hasattr(obj, 'updated_by'):
            obj.updated_by = request.user
        if hasattr(obj, 'author'):
            if getattr(obj, 'author', None) is None:
                obj.author = request.user.username
        if hasattr(obj, 'created_by'):
            if getattr(obj, 'author', None) is None:
                obj.author = request.user.username
        obj.save()


class AdminLocked(AdminBase):
    def has_add_permission(self, request):
        return False
    def has_change_permission(self, request, obj=None):
        return False
    def has_delete_permission(self, request, obj=None):
        return False
    

class AdminFeature(AdminBase):
    feature_key = None  # override in subclass
    def _check_feature_flag(self, request):
        try:
            site = request.site
            if self.feature_key:
                return site.has_feature(self.feature_key)
            return True
        except Exception as ex:
            if settings.DEBUG:
                print(f"[E] Wrong Feature {self.feature_key}: {ex}")
            return False
        
    def has_module_permission(self, request):
        enabled = self._check_feature_flag(request)
        if not enabled:
            return False
        return super().has_module_permission(request)

    def has_add_permission(self, request):
        enabled = self._check_feature_flag(request)
        if not enabled:
            return False
        return super().has_add_permission(request)
    
    def has_change_permission(self, request, obj=None):
        enabled = self._check_feature_flag(request)
        if not enabled:
            return False
        return super().has_change_permission(request, obj)
    
    def has_delete_permission(self, request, obj=None):
        enabled = self._check_feature_flag(request)
        if not enabled:
            return False
        return super().has_delete_permission(request, obj)

    def has_view_permission(self, request, obj=None):
        enabled = self._check_feature_flag(request)
        if not enabled:
            return False
        return super().has_view_permission(request, obj)


class AdminStackedInline(admin.StackedInline):
    extra = 1


class AdminTabularInline(admin.TabularInline):
    extra = 1


class AdminAnchorMixin():
    def anchor(self, obj):
        anchors = ""
        for code, name in settings.LANGUAGES:
            url = getattr(obj.site, 'domain_%s' % code, "")
            # We make sure that the domain only has one http
            url = "http://" + url.replace("http://", "")
            file =  getattr(obj, __('file', code), None)
            text = getattr(obj, __('name', code), None)
            if file:
                anchors += "%s : <xmp><a href='%s/%s' target='_blank'>%s</a></xmp><br>" % (_(name), url, file, text)
        return anchors
    anchor.allow_tags = True
    anchor.short_description = 'Links'


class AdminCollectionMixin():
    def collection(self, obj):
        try:
            return format_html('<br>'.join([c.code for c in obj.collections.all()]))
        except:
            return ''
    collection.short_description = 'Collections'
    collection.allow_tags = True


class AdminCategoryMixin():
    def category(self, obj):
        try:
            return format_html('<br>'.join([c.code for c in obj.category_set.all()]))
        except:
            return ''
    category.short_description = 'Categories'
    category.allow_tags = True


class AdminTagMixin():
    def tag(self, obj):
        try:
            return format_html('<br>'.join([c.code for c in obj.tags.all()]))
        except:
            return ''
    tag.short_description = 'Tags'
    tag.allow_tags = True
