from django.contrib import admin
from django.conf import settings
from django.contrib.staticfiles import finders
from django.utils.html import format_html
from django.utils.translation import gettext_lazy as _
from django.utils.safestring import mark_safe
from django.forms import ValidationError

from sorl.thumbnail import get_thumbnail
from sorl.thumbnail.admin import AdminImageMixin as AdminSorlImageMixin

from shared_engine.forms import AdminImageRequireForm, AdminImageOptionalForm, AdminFileRequireForm, AdminFileOptionalForm
from shared_engine.transmeta import get_real_fieldname as __

class AdminBase(admin.ModelAdmin):
    
    def save_model(self, request, obj, form, change):
        if hasattr(obj, 'created_by'):
            if getattr(obj, 'created_by', None) is None:
                obj.created_by = request.user
        if hasattr(obj, 'updated_by'):
            obj.updated_by = request.user
        if hasattr(obj, 'author'):
            if getattr(obj, 'author', None) is None:
                obj.author = request.user.username
        if hasattr(obj, 'created_by'):
            if getattr(obj, 'author', None) is None:
                obj.author = request.user.username
        obj.save()

    def get_readonly_fields(self, request, obj=None):
        fields = []
        if obj is not None:
            if hasattr(obj, 'code') and getattr(obj, 'code', None) is not None:
                fields.append('code')
            if not settings.DEBUG and hasattr(obj, 'site') and getattr(obj, 'site', None) is not None:
                fields.append('site')
        return fields

class AdminModelBase(AdminBase):
    def get_object(self, request, object_id, obj):
        queryset = self.model._default_manager.get_queryset()
        model = self.model
        try:
            object_id = model._meta.pk.to_python(object_id)
            return queryset.get(pk=object_id)
        except (model.DoesNotExist, ValidationError):
            return None

    def queryset(self, request):
        queryset = super(AdminBase, self).queryset(request)
        return queryset


class AdminStackedInline(admin.StackedInline):
    extra = 1


class AdminTabularInline(admin.TabularInline):
    extra = 1


class AdminTinyMCEMixin():
    class Media:
        tiny_mce_css_file = 'css/tinymce_setup.css'
        tiny_mce_js_file = 'js/tinymce_setup.js'

        # if finders.find(tiny_mce_css_file):
            # css = {
                # 'all': (tiny_mce_css_file,)
            # }

        if not finders.find(tiny_mce_js_file):
            tiny_mce_js_file = '/static/grappelli/tinymce_setup/tinymce_setup.js'

        js = [
            '/static/grappelli/tinymce/jscripts/tiny_mce/tiny_mce.js',
            tiny_mce_js_file,
        ]


class AdminImageMixin(AdminSorlImageMixin):
    form = AdminImageRequireForm

    def thumbnail(self, obj):
        try:
            img = get_thumbnail(obj.image, '50x30', crop='center').url
            txt = getattr(obj, __('title'), '')
            tag = "<img src='%s' width='50' height='30' all='%s' title='%s'>" % (img, txt, txt)
            return format_html(tag)
        except:
            return ''
    thumbnail.allow_tags = True

    def thumbnail_header(self, obj):
        try:
            img = get_thumbnail(obj.background_header, '50x30', crop='center').url
            txt = getattr(obj, __('title'), '')
            tag = "<img src='%s' width='50' height='30' all='%s' title='%s'>" % (img, txt, txt)
            return format_html(tag)
        except:
            return ''
    thumbnail.allow_tags = True

    def thumbnail_footer(self, obj):
        try:
            img = get_thumbnail(obj.background_footer, '50x30', crop='center').url
            txt = getattr(obj, __('title'), '')
            tag = "<img src='%s' width='50' height='30' all='%s' title='%s'>" % (img, txt, txt)
            return format_html(tag)
        except:
            return ''
    thumbnail.allow_tags = True


class AdminImageExtraMixin(AdminImageMixin):
    form = AdminImageOptionalForm


class AdminFileMixin():
    form = AdminFileRequireForm


class AdminFileExtraMixin():
    form = AdminFileOptionalForm

class AdminReadOnlyMixin():
    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


class AdminAnchorMixin():
    def anchor(self, obj):
        anchors = ""
        for code, name in settings.LANGUAGES:
            url = getattr(obj.site, 'domain_%s' % code, "")
            # We make sure that the domain only has one http
            url = "http://" + url.replace("http://", "")
            file =  getattr(obj, __('file', code), None)
            text = getattr(obj, __('name', code), None)
            if file:
                anchors += "%s : <xmp><a href='%s/%s' target='_blank'>%s</a></xmp><br>" % (_(name), url, file, text)
        return anchors
    anchor.allow_tags = True
    anchor.short_description = 'Links'


class AdminCollectionMixin():
    def collection(self, obj):
        try:
            return format_html('<br>'.join([c.code for c in obj.collections.all()]))
        except:
            return ''
    collection.short_description = 'Collections'
    collection.allow_tags = True


class AdminCategoryMixin():
    def category(self, obj):
        try:
            return format_html('<br>'.join([c.code for c in obj.categories.all()]))
        except:
            return ''
    category.short_description = 'Categories'
    category.allow_tags = True


class AdminTagMixin():
    def tag(self, obj):
        try:
            return format_html('<br>'.join([c.code for c in obj.tags.all()]))
        except:
            return ''
    tag.short_description = 'Tags'
    tag.allow_tags = True

