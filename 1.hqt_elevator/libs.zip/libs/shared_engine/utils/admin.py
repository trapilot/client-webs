from django.apps import apps
from django.contrib.admin import AdminSite

_original_get_app_list = AdminSite.get_app_list


def sort_models(*model_paths):
    return tuple(
        sorted(
            model_paths,
            key=lambda path: getattr(
                apps.get_model(
                    path.split(".models.")[0],
                    path.split(".models.")[1],
                ),
                "ADMIN_ORDER",
                9999,
            ),
        )
    )


def get_sorted_models_of_app(app_label):
    models = list(apps.get_app_config(app_label).get_models())

    models.sort(
        key=lambda m: getattr(m, "ADMIN_ORDER", 9999)
    )

    return tuple(
        f"{m._meta.app_label}.models.{m.__name__}"
        for m in models
    )


def custom_get_app_list(self, request, app_label=None):
    app_list = _original_get_app_list(self, request, app_label)

    for app in app_list:
        for model in app["models"]:
            try:
                model_class = apps.get_model(
                    app["app_label"],
                    model["object_name"],
                )

                model["_admin_order"] = getattr(
                    model_class,
                    "ADMIN_ORDER",
                    9999,
                )
            except LookupError:
                model["_admin_order"] = 9999

        app["models"].sort(
            key=lambda m: m["_admin_order"]
        )

    return app_list


AdminSite.get_app_list = custom_get_app_list