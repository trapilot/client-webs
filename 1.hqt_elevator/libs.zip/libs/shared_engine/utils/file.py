import os
import uuid
import unicodedata
import shutil

from pathlib import Path

from django.conf import settings
from django.utils.text import slugify


def normalize_filename(filename: str):
    name, ext = os.path.splitext(filename)
    name = unicodedata.normalize("NFKD", name)

    name = slugify(name)
    uid = uuid.uuid4().hex[:8]

    return f"{name}-{uid}{ext.lower()}"


def get_generated_dir(image_path: str):
    image_path = Path(image_path)
    
    return [image_path, image_path.parent / "generated"]


def ensure_generated_dir(image_path: str) -> Path:
    [image_path, generated_dir] = get_generated_dir(image_path)
    
    generated_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    return [image_path, generated_dir]


def cleanup_generated_dir(image_path: str) -> None:
    [_image_path, generated_dir] = get_generated_dir(image_path)

    if not generated_dir.is_dir():
        return

    for file in generated_dir.iterdir():
        if file.is_file():
            file.unlink()


def cleanup_generated_files(image_path: str) -> None:
    [image_path, generated_dir] = get_generated_dir(image_path)

    if not generated_dir.is_dir():
        return

    for file in generated_dir.glob(f"{image_path.stem}_*"):
        file.unlink(missing_ok=True)


def file_exists(media_url: str):
    if not media_url:
        return False

    path = media_url.replace(settings.MEDIA_URL, "")
    return os.path.exists(settings.MEDIA_ROOT / path)


def build_fs_path(file_path: str, base_path=None):
    if not file_path:
        return None

    if isinstance(file_path, Path):
        file_path = str(file_path)

    return Path(settings.MEDIA_ROOT) / file_path

def build_file_path(file_path: str, base_path=None):
    if not file_path:
        return None

    if isinstance(file_path, Path):
        file_path = str(file_path)

    return f"{settings.MEDIA_URL}{file_path.lstrip('/')}"


def delete_file(file):
    try:
        delete_path(file.url)
    except OSError:
        pass


def delete_path(path):
    try:
        os.remove(path)
    except OSError:
        pass