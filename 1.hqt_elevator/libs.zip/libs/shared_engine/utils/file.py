import os
import uuid
import unicodedata

from django.utils.text import slugify


def normalize_filename(filename: str):
    name, ext = os.path.splitext(filename)

    name = unicodedata.normalize(
        "NFKD",
        name
    )

    name = slugify(name)
    uid = uuid.uuid4().hex[:8]

    return f"{name}-{uid}{ext.lower()}"