import os
import uuid
import unicodedata
import shutil

from pathlib import Path

from django.utils.text import slugify


def normalize_filename(filename: str):
    name, ext = os.path.splitext(filename)
    name = unicodedata.normalize("NFKD", name)

    name = slugify(name)
    uid = uuid.uuid4().hex[:8]

    return f"{name}-{uid}{ext.lower()}"


def get_generated_dir(image_path: str) -> Path:
    image_path = Path(image_path)
    
    return image_path.parent / "generated"


def ensure_generated_dir(image_path: str) -> Path:
    generated_dir = get_generated_dir(image_path)
    
    generated_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    return generated_dir


def cleanup_generated_dir(image_path: str) -> None:
    generated_dir = get_generated_dir(image_path)

    if not generated_dir.is_dir():
        return

    for file in generated_dir.iterdir():
        if file.is_file():
            file.unlink()


def cleanup_generated_files(image_path: str) -> None:
    generated_dir = get_generated_dir(image_path)

    if not generated_dir.is_dir():
        return

    for file in generated_dir.glob(f"{image_path.stem}_*"):
        file.unlink(missing_ok=True)