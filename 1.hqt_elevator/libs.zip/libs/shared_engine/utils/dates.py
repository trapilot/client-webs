# coding: utf-8
from django.utils.formats import get_format_modules
import datetime

def date_range(start_date, end_date, only_nights = False):
    u"""
    This loop calculates a range between two dates. It's useful for later use in a loop. For example:
    for single_date in daterange(season.start_date, season.end_date):
    print single_date.timetuple()
    If we set only_nights to True, it will count one less day. To count only the nights within the range.
    """
    import datetime

    if only_nights == False:
        increase = 1
    else:
        increase = 0

    for n in range((end_date - start_date).days + increase):
        yield start_date + datetime.timedelta(n)

def convert_date(date_string, alternative_format = 0):
    u"""
    Receiving a date in dd/mm/yyyy format, we return a datetime.date object.
    In case of error, we return False.
    """
    if alternative_format == 0:
        split_date = date_string.split('/')
        try:
            return datetime.date(int(split_date[2]),int(split_date[1]),int(split_date[0]))
        except:
            return False
    elif alternative_format == 1:
        split_date = date_string.split('-')
        try:
            return datetime.date(int(split_date[0]),int(split_date[1]),int(split_date[2]))
        except:
            return False
