# coding: utf-8
from django.core.mail import EmailMessage

def html_email(subject, body, from_email, to_email, bcc=None):
    u"""
    Method for sending emails in HTML format
    """
    
    email = EmailMessage(subject, body, from_email, to_email, bcc)
    email.content_subtype = 'html'
    email.send()
