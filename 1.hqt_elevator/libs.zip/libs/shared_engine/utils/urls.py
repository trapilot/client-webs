from django.conf import settings
from django.urls import include, re_path


def autodiscover():
    u'''
    We go through all the applications and check
    if the ones from the app_engine have any
    urls. If so, we add them to the installe apps.
    '''
    discover_patterns = []
    for app in settings.INSTALLED_APPS:
        if not app.startswith('cms_') and not app.endswith('_engine'):
            continue
        try:
            exec('from %s.urls import urlpatterns' % app)
        except ImportError as ex:
            if settings.DEBUG:
                print(app, ex)
            continue

        discover_patterns += [re_path(r'^%s/' % app, include('%s.urls' % app)),]
    
    # We added some common and required urls.
    if 'bookcore_engine' in settings.INSTALLED_APPS:
        from bookcore_engine.crs import urls as urls_crs
        discover_patterns += [
            re_path('^crs/', include(urls_crs)),
        ]
    return discover_patterns
