from django.conf import settings
from django.urls import include, re_path


def autodiscover():
    u'''
    We go through all the applications and check
    if the ones from the site_content have any
    urls. If so, we add them to the installe apps.
    '''
    discover_patterns = []
    for app in settings.INSTALLED_APPS:
        if app.endswith('_engine') or app.startswith('site_'):
            try:
                exec('from %s.urls import urlpatterns' % app)

                discover_patterns += re_path(r'^', include('%s.urls' % app)),
            except ImportError as ex:
                if settings.DEBUG:
                    print(app, ex)
    return discover_patterns


def parse(request, https=False):
    schema = 'https://' if https or request.is_secure() else 'http://'  

    return {
        "schema": schema,
        "http_host": schema + request.get_host(),
        "http_server": schema + request.META['SERVER_NAME']
    }