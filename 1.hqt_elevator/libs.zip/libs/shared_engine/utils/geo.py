# coding: utf-8
import math
import json
import requests


def calculate_distance(long1, lat1, long2, lat2):
    u"""We return the difference between the two points in kilometers."""

    if long1 == 0.0 or lat1 == 0.0 or long2 == 0.0 or lat2 == 0.0:
        return None

    degtorad = 0.01745329
    radtodeg = 57.29577951

    dlong = long1 - long2
    dvalue = (math.sin(lat1 * degtorad) * math.sin(lat2 * degtorad)) + (math.cos(lat1 * degtorad) * math.cos(lat2 * degtorad) * math.cos(dlong * degtorad))
    dd = math.acos(dvalue) * radtodeg
    km = (dd * 111.302)
    km = (km * 100)/100
    return km


def distances_google(lat1, long1, lat2, long2, mode='driving', lang='es'):
    params = {
        'origins': "%s,%s" % (lat1, long1),
        'destinations': "%s,%s" % (lat2, long2),
        'mode': mode,
        'language': lang,
    }

    r = requests.get(
        "https://maps.googleapis.com/maps/api/distancematrix/json",
        params=params)

    data = json.loads(r.content)
    rows = data.get('rows', [])
    for r in rows:
        for a in r.get('elements', []):
            if a.get('status', 'ZERO_RESULTS') == 'OK':
                distance = a.get('distance', {})
                cm = distance.get('value')
                km = round((float(cm)/float(1000000)), 3)
                distance.update({'value': km})
                return distance

    return None
