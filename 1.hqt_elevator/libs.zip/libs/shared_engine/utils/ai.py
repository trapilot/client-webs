from shared_engine.services.gemini_service import generate_by_gemini
from shared_engine.services.openai_service import generate_by_openai


PROVIDERS = {
    "gemini": generate_by_gemini,
    "openai": generate_by_openai,
}


def generate_html(provider, content):
    if provider not in PROVIDERS:
        raise Exception("Unsupported provider")

    return PROVIDERS[provider](content)