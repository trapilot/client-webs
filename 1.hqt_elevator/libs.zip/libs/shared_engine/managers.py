#!/usr/bin/env python
import ipaddress

from django.db import models
from django.db.models import Q
from django.utils import timezone
from django.utils.translation import gettext_lazy as _, get_language

from shared_engine.transmeta import get_real_fieldname as __

class EnumActiveChoice(models.IntegerChoices):
    ACTIVE = 1, _(u'Active')
    INACTIVE = 2, _(u'Inactive')

class EnumStatusChoice(models.IntegerChoices):
    DRAFT = 1, _(u'Draft')
    PUBLISHED = 2, _(u'Published')
    ARCHIVED = 3, _(u'Archived')


class GeneralManager(models.Manager):
    def is_activated(self, **kwargs):
        return self.filter(is_active=True, **kwargs)


class ArticleManager(models.Manager):
    def is_activated(self, **kwargs):
        now = timezone.now()
        return self.filter(is_active=True, **kwargs).exclude(published_at__gt=now)


class BackgroundManager(models.Manager):
    def is_activated(self, **kwargs):
        now = timezone.now()
        return self.filter(
                **{ __('status'): True, **kwargs }
            ).exclude(
                Q(since_date__isnull=False) & Q(since_date__gt=now)
            ).exclude(
                Q(until_date__isnull=False) & Q(until_date__lte=now)
            )


class PopupManager(models.Manager):
    def is_activated(self, **kwargs):
        kwargs = {'is_active_%s' % get_language() : True}
        return self.filter(**kwargs)


class UserManager(models.Manager):
    def search(self, uuid, ip):
        try:
            ip = ipaddress.ip_address(ip.strip())
            user = self.get(is_active=True, code=uuid)
            if ip in user.validated_ips():
                return user
        except (models.ObjectDoesNotExist, ValueError):
            return None