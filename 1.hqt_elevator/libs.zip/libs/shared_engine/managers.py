import ipaddress

from django.db import models
from django.db.models import Q
from django.utils import timezone
from django.utils.translation import gettext_lazy as _, get_language

from shared_engine.transmeta import get_real_fieldname as __


class GeneralManager(models.Manager):
    def is_activated(self, **kwargs):
        return self.filter(is_active=True, **kwargs)
    
    def is_featured(self, **kwargs):
        return self.filter(is_active=True, is_homepage=True, **kwargs)


class PostManager(models.Manager):
    def is_activated(self, **kwargs):
        now = timezone.now()
        return self.filter(is_active=True, **kwargs).exclude(published_at__gt=now)
    
    def is_featured(self, **kwargs):
        now = timezone.now()
        return self.filter(is_active=True, is_homepage=True, **kwargs).exclude(published_at__gt=now)


class AvailabilityManager(models.Manager):
    def is_activated(self, check_status=False, **kwargs):
        now = timezone.now()
        filters = {
            "is_active": True,
            **kwargs,
        }
        if check_status and hasattr(self.model, "status"):
            filters[__('status')] = True

        return self.filter(
                **filters
            ).exclude(
                Q(since_date__isnull=False) & Q(since_date__gt=now)
            ).exclude(
                Q(until_date__isnull=False) & Q(until_date__lte=now)
            )
    
    def is_featured(self, check_status=False, **kwargs):
        now = timezone.now()
        filters = {
            "is_homepage": True,
            "is_active": True,
            **kwargs,
        }
        if check_status and hasattr(self.model, "status"):
            filters[__('status')] = True
            
        return self.filter(
                **filters
            ).exclude(
                Q(since_date__isnull=False) & Q(since_date__gt=now)
            ).exclude(
                Q(until_date__isnull=False) & Q(until_date__lte=now)
            )


class UserManager(models.Manager):
    def search(self, uuid, ip):
        try:
            ip = ipaddress.ip_address(ip.strip())
            user = self.get(is_active=True, code=uuid)
            if ip in user.validated_ips():
                return user
        except (models.ObjectDoesNotExist, ValueError):
            return None