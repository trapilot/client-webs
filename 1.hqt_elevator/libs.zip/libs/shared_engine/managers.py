#!/usr/bin/env python
import datetime
import ipaddress

from django.db import models
from django.db.models import Q
from django.utils import translation


class GeneralManager(models.Manager):

    def is_activated(self, **kwargs):
        return self.filter(is_active=True, **kwargs)
    
    def is_published(self, **kwargs):
        now = datetime.datetime.now()
        return self.filter(
            is_active=True, **kwargs
        ).exclude(
            Q(published_at__isnull=False) & Q(published_at__gt=now)
        ).exclude(
            Q(unpublished_at__isnull=False) & Q(unpublished_at__lte=now)
        )


class UserManager(models.Manager):
    def search(self, uuid, ip):
        try:
            ip = ipaddress.ip_address(ip.strip())
            user = self.get(is_active=True, code=uuid)
            if ip in user.validated_ips():
                return user
        except (models.ObjectDoesNotExist, ValueError):
            return None