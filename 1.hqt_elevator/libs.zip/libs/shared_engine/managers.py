#!/usr/bin/env python
import datetime
import ipaddress

from django.db import models
from django.db.models import Q
from django.utils.translation import gettext_lazy as _, get_language

from shared_engine.transmeta import get_real_fieldname as __

class EnumActiveChoice(models.IntegerChoices):
    ACTIVE = 1, _(u'Active')
    INACTIVE = 2, _(u'Inactive')

class EnumStatusChoice(models.IntegerChoices):
    DRAFT = 1, _(u'Draft')
    PUBLISHED = 2, _(u'Published')
    ARCHIVED = 3, _(u'Archived')


class GeneralManager(models.Manager):
    def is_activated(self, **kwargs):
        return self.filter(is_active=True, **kwargs)


class ArticleManager(models.Manager):
    def is_activated(self, **kwargs):
        now = datetime.datetime.now()
        return self.filter(is_active=True, **kwargs).exclude(published_at__gt=now)


class BackgroundManager(models.Manager):
    def is_activated(self, **kwargs):
        now = datetime.datetime.now()
        return self.filter(
                **{ __('status'): True, **kwargs }
            ).exclude(
                Q(published_at__isnull=False) & Q(published_at__gt=now)
            ).exclude(
                Q(unpublished_at__isnull=False) & Q(unpublished_at__lte=now)
            )


class PopupManager(models.Manager):
    def is_activated(self, **kwargs):
        kwargs = {'is_active_%s' % get_language() : True}
        return self.filter(**kwargs)


class UserManager(models.Manager):
    def search(self, uuid, ip):
        try:
            ip = ipaddress.ip_address(ip.strip())
            user = self.get(is_active=True, code=uuid)
            if ip in user.validated_ips():
                return user
        except (models.ObjectDoesNotExist, ValueError):
            return None