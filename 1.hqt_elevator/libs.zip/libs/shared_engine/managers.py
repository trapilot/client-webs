#!/usr/bin/env python
from django.db import models
from django.db.models import Q
from django.utils import translation


class ImageManager(models.Manager):
    
    def is_activated(self, **kwargs):
        return self.filter(is_active=True, **kwargs)


class ArchiveManager(models.Manager):
    
    def is_activated(self, **kwargs):
        return self.filter(is_active=True, **kwargs)
