import os

from django.conf import settings
from django.db import transaction
from django.db.models import ImageField
from django.db.models.signals import pre_save, post_save, post_delete
from django.dispatch import receiver

from shared_engine.transcode import (
    executor,
    ImageTranscoder,
)


def has_image_field(sender):
    return any(isinstance(field, ImageField) for field in sender._meta.fields)


@receiver(pre_save)
def image_pre_save(sender, instance, **kwargs):
    if not hasattr(sender, "_meta"):
        return

    if not has_image_field(sender):
        return

    if not instance.pk:
        return

    try:
        old = sender.objects.get(pk=instance.pk)
    except sender.DoesNotExist:
        return

    instance._old_images = {}
    for field in sender._meta.fields:
        if not isinstance(field, ImageField):
            continue
        instance._old_images[field.name] = getattr(old, field.name)


@receiver(post_save)
def image_post_save(sender, instance, created, **kwargs):
    if not hasattr(sender, "_meta"):
        return

    if not has_image_field(sender):
        return

    for field in sender._meta.fields:
        if not isinstance(field, ImageField):
            continue

        image = getattr(instance, field.name)
        if not image:
            continue

        changed = created

        old_image = None
        if not created:
            old_image = getattr(instance, "_old_images", {}).get(field.name)

            old_name = (old_image.name if old_image else None)

            changed = (old_name != image.name)

        if not changed:
            continue

        if old_image:
            try:
                ImageTranscoder.cleanup(old_image.path)

                if os.path.exists(old_image.path):
                    os.remove(old_image.path)
            except Exception as ex:
                if settings.DEBUG:
                    print(f"[E] Wrong image_post_save: {ex}")
                pass

        transaction.on_commit(lambda path=image.path: executor.submit(ImageTranscoder.generate, path))


@receiver(post_delete)
def image_post_delete(sender, instance, **kwargs):
    if not hasattr(sender, "_meta"):
        return

    if not has_image_field(sender):
        return

    for field in sender._meta.fields:
        if not isinstance(field, ImageField):
            continue

        image = getattr(instance, field.name)
        if not image:
            continue

        try:
            ImageTranscoder.cleanup(image.path)

            if os.path.exists(image.path):
                os.remove(image.path)
        except Exception:
            pass