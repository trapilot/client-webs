import os

from django.db.models.signals import pre_save, post_save, post_delete
from django.dispatch import receiver
from django.db.models import ImageField

from shared_engine.services.image_pipeline import ImagePipeline


@receiver(pre_save)
def cache_old_images(sender, instance, **kwargs):
    if not instance.pk:
        return

    try:
        old = sender.objects.get(pk=instance.pk)
    except sender.DoesNotExist:
        return

    instance._old_images = {}
    for field in instance._meta.fields:
        if not isinstance(field, ImageField):
            continue
        instance._old_images[field.name] = getattr(
            old,
            field.name
        )

@receiver(post_save)
def image_post_save(sender, instance, created, **kwargs):
    for field in instance._meta.fields:
        if not isinstance(field, ImageField):
            continue

        image = getattr(instance, field.name)
        if not image:
            continue

        should_generate = created

        old_image = None

        if not created:
            old_image = (instance._old_images.get(field.name))

            old_name = (old_image.name if old_image else None)
            new_name = image.name

            should_generate = (
                old_name != new_name
            )

        if not should_generate:
            continue
        
        if old_image:
            try:
                ImagePipeline.cleanup(old_image.path)

                if os.path.exists(old_image.path):
                    os.remove(old_image.path)
            except Exception:
                pass

        try:
            ImagePipeline.generate(image.path)
        except Exception:
            pass


@receiver(post_delete)
def image_post_delete(sender, instance, **kwargs):
    if not hasattr(sender, "_meta"):
        return

    for field in sender._meta.fields:
        if not isinstance(field, ImageField):
            continue

        image = getattr(instance, field.name)
        if not image:
            continue

        try:
            ImagePipeline.cleanup(image.path)

            if os.path.exists(image.path):
                os.remove(image.path)
        except Exception:
            pass